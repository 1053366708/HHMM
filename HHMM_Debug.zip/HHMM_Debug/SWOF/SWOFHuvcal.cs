﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HHMM
{
    public class Huvclass
    {
        public static void Huvcal(int startcol, int endcol, int EnvPro, int verif, int ORDER, int NXCELL, int NYCELL, int fricmethod, double dt, double DX, double DY, double dt_first, double Demmax, double[][] z, int[] LBcscheme, int[] RBcscheme, int[] TBcscheme, int[] BBcscheme, double[][] Fric_tab, double[][] he, double[][] ve1, double[][] ve2, double[][] hes, double[][] ves1, double[][] ves2, double[][] delzc1, double[][] h1l, double[][] h1r, double[][] h1left, double[][] h1right, double[][] delzc2, double[][] h2l, double[][] h2r, double[][] h2left, double[][] h2right, double[][] f1, double[][] f2, double[][] f3, double[][] g1, double[][] g2, double[][] g3, double Rain, double[][] Vinfil, double[][] qes1, double[][] qes2, ref double fluxy0_cum_T, ref double fluxNycell_cum_T, ref double fluxx0_cum_T, ref double fluxNxcell_cum_T, out double Step_outflow)
        {
            double tx = dt / DX;
            double ty = dt / DY;
            Step_outflow = 0.0;

            if (verif == 1)
            {
                dt_first = dt;
            }
            Parallel.For(1, NXCELL + 1, new ParallelOptions() { MaxDegreeOfParallelism = EnvPro }, i =>
            //  for (int i = 1; i < NXCELL + 1; i++)
            {
                for (int j = 1; j < NYCELL + 1; j++)
                {

                    if (z[i][j] > Demmax + 10)
                    {
                        hes[i][j] = he[i][j] - tx * (f1[i + 1][j] - f1[i][j]) - ty * (g1[i][j + 1] - g1[i][j]);
                    }
                    else
                    {
                        hes[i][j] = he[i][j] - tx * (f1[i + 1][j] - f1[i][j]) - ty * (g1[i][j + 1] - g1[i][j]) + Rain * dt;
                    }
                }
            }
            );
            //计算
            //   Infilcal(NXCELL, NYCELL, dt, ref hes, ref Vinfil);
            Parallel.For(1, NXCELL + 1, new ParallelOptions() { MaxDegreeOfParallelism = EnvPro }, i =>
            //for (int i = 1; i < NXCELL + 1; i++)
            {
                for (int j = 1; j < NYCELL + 1; j++)
                {
                    qes1[i][j] = (he[i][j] * ve1[i][j] - tx * (f2[i + 1][j] - f2[i][j] + SVCSconst.GRAV / 2.0 * ((h1left[i][j] - h1l[i][j]) * (h1left[i][j] + h1l[i][j]) + (h1r[i][j] - h1right[i][j]) * (h1r[i][j] + h1right[i][j]) + (h1l[i][j] + h1r[i][j]) * delzc1[i][j])) - ty * (g2[i][j + 1] - g2[i][j]));
                    qes2[i][j] = (he[i][j] * ve2[i][j] - tx * (f3[i + 1][j] - f3[i][j]) - ty * (g3[i][j + 1] - g3[i][j] + SVCSconst.GRAV / 2.0 * ((h2left[i][j] - h2l[i][j]) * (h2left[i][j] + h2l[i][j]) + (h2r[i][j] - h2right[i][j]) * (h2r[i][j] + h2right[i][j]) + (h2l[i][j] + h2r[i][j]) * delzc2[i][j])));
                }
            }
            );
            friccal(fricmethod, NXCELL, NYCELL, dt, Fric_tab, ve1, ve2, hes, qes1, qes2);
            Parallel.For(1, NXCELL + 1, new ParallelOptions() { MaxDegreeOfParallelism = EnvPro }, i =>
            // for (int i = 1; i < NXCELL + 1; i++)
            {
                for (int j = 1; j < NYCELL + 1; j++)
                {
                    if (hes[i][j] > SVCSconst.HE_CA)
                    {
                        ves1[i][j] = qes1[i][j] / hes[i][j];
                        ves2[i][j] = qes2[i][j] / hes[i][j];
                    }
                    else
                    { // Case of height of water is zero.
                        ves1[i][j] = 0.0;
                        ves2[i][j] = 0.0;
                    }
                } //end for j
            }
            );


            Step_outflow = boundflux(startcol, endcol, NXCELL, NYCELL, ORDER, verif, dt, dt_first, DX, DY, LBcscheme, RBcscheme, TBcscheme, BBcscheme, f1, g1, ref fluxy0_cum_T, ref fluxNycell_cum_T, ref fluxx0_cum_T, ref fluxNxcell_cum_T);
        }

        public static void Infilcal(int NXCELL, int NYCELL, double dt, ref double[][] hes, ref double[][] Vinfil)
        {
            for (int i = 1; i <= NXCELL; i++)
            {
                for (int j = 1; j <= NYCELL; j++)
                {
                    Vinfil[i - 1][j - 1] = Math.Min(Vinfil[i - 1][j - 1], hes[i][j]);
                    hes[i][j] = hes[i][j] - Vinfil[i - 1][j - 1];
                    Vinfil[i - 1][j - 1] /= dt;
                }
            }
        }
        /// <summary>
        /// 摩阻计算
        /// </summary>
        /// <param name="fricmethod">摩阻计算方法</param>
        /// <param name="NXCELL">横向网格数</param>
        /// <param name="NYCELL">纵向网格数</param>
        /// <param name="dt">时间步长</param>
        /// <param name="Fric_tab">摩阻系数</param>
        /// <param name="uold">法向速度</param>
        /// <param name="vold">切向速度</param>
        /// <param name="hnew">水位</param>
        /// <param name="q1new">法向流量</param>
        /// <param name="q2new">切向流量</param>
        public static void friccal(int fricmethod, int NXCELL, int NYCELL, double dt, double[][] Fric_tab, double[][] uold, double[][] vold, double[][] hnew, double[][] q1new, double[][] q2new)
        {
            switch (fricmethod)
            {
                case 1:
                    fricmanning(NXCELL, NYCELL, dt, Fric_tab, uold, vold, hnew, q1new, q2new);
                    break;
                case 2:
                    friclaminar(NXCELL, NYCELL, dt, Fric_tab, uold, vold, hnew, q1new, q2new);
                    break;
                case 3:
                    fricdarcy(NXCELL, NYCELL, dt, Fric_tab, uold, vold, hnew, q1new, q2new);
                    break;
                case 4:
                    fricno(NXCELL, NYCELL, dt, Fric_tab, uold, vold, hnew, q1new, q2new);
                    break;
            }

        }

        public static void fricmanning(int NXCELL, int NYCELL, double dt, double[][] Fric_tab, double[][] uold, double[][] vold, double[][] hnew, double[][] q1new, double[][] q2new)
        {
            for (int i = 1; i < NXCELL + 1; i++)
            {
                for (int j = 1; j < NYCELL + 1; j++)
                {
                    if (hnew[i][j] <= 0.0)
                    {
                        q1new[i][j] = 0.0;
                        q2new[i][j] = 0.0;
                    }
                    else
                    {
                        q1new[i][j] = q1new[i][j] / (1.0 + Fric_tab[i][j] * Fric_tab[i][j] * SVCSconst.GRAV * Math.Sqrt(uold[i][j] * uold[i][j] + vold[i][j] * vold[i][j]) * dt / Math.Pow(hnew[i][j], 4.0 / 3.0));
                        q2new[i][j] = q2new[i][j] / (1.0 + Fric_tab[i][j] * Fric_tab[i][j] * SVCSconst.GRAV * Math.Sqrt(uold[i][j] * uold[i][j] + vold[i][j] * vold[i][j]) * dt / Math.Pow(hnew[i][j], 4.0 / 3.0));
                    }

                }
            }
        }
        public static void fricno(int NXCELL, int NYCELL, double dt, double[][] Fric_tab, double[][] uold, double[][] vold, double[][] hnew, double[][] q1new, double[][] q2new)
        {
            for (int i = 1; i < NXCELL + 1; i++)
            {
                for (int j = 1; j < NYCELL + 1; j++)
                {
                    q1new[i][j] = q1new[i][j];
                    q2new[i][j] = q2new[i][j];
                }
            }
        }
        public static void fricdarcy(int NXCELL, int NYCELL, double dt, double[][] Fric_tab, double[][] uold, double[][] vold, double[][] hnew, double[][] q1new, double[][] q2new)
        {
            for (int i = 1; i < NXCELL + 1; i++)
            {
                for (int j = 1; j < NYCELL + 1; j++)
                {
                    q1new[i][j] = q1new[i][j] / (1.0 + Fric_tab[i][j] * Math.Sqrt(uold[i][j] * uold[i][j] + vold[i][j] * vold[i][j]) * dt / (8.0 * hnew[i][j]));
                    q2new[i][j] = q2new[i][j] / (1.0 + Fric_tab[i][j] * Math.Sqrt(uold[i][j] * uold[i][j] + vold[i][j] * vold[i][j]) * dt / (8.0 * hnew[i][j]));
                }
            }
        }
        public static void friclaminar(int NXCELL, int NYCELL, double dt, double[][] Fric_tab, double[][] uold, double[][] vold, double[][] hnew, double[][] q1new, double[][] q2new)
        {
            for (int i = 1; i < NXCELL + 1; i++)
            {
                for (int j = 1; j < NYCELL + 1; j++)
                {
                    q1new[i][j] = q1new[i][j] / (1.0 + Fric_tab[i][j] * Fric_tab[i][j] * dt / Math.Pow(hnew[i][j], 2));
                    q2new[i][j] = q2new[i][j] / (1.0 + Fric_tab[i][j] * Fric_tab[i][j] * dt / Math.Pow(hnew[i][j], 2));
                }
            }
        }

        public static double boundflux(int startcol, int endcol, int NXCELL, int NYCELL, int ORDER, int verif, double dt, double dt_first, double DX, double DY, int[] LBcscheme, int[] RBcscheme, int[] TBcscheme, int[] BBcscheme, double[][] flux_u, double[][] flux_v, ref double fluxy0_cum_T, ref double fluxNycell_cum_T, ref double fluxx0_cum_T, ref double fluxNxcell_cum_T)
        {
            /*
            fluxy0_cum_T = 0.0;
            fluxNycell_cum_T = 0.0;
            fluxx0_cum_T = 0.0;
            fluxNxcell_cum_T = 0.0;
             * */
            double fluxNycell = 0.0, fluxNxcell = 0.0, fluxy0 = 0.0, fluxx0 = 0.0;
            if (verif == 1)
            {
                for (int i = startcol + 1; i < endcol + 1; i++)
                {
                    if (TBcscheme[i] == 2)
                    {
                        fluxy0 += flux_v[i][1];
                    }
                    if (BBcscheme[i] == 2)
                    {
                        fluxNycell += flux_v[i][NYCELL + 1];
                    }
                }
                for (int j = 1; j < NYCELL + 1; j++)
                {
                    if (LBcscheme[j] == 2)
                    {
                        fluxx0 += flux_u[startcol + 1][j];
                    }
                    if (RBcscheme[j] == 2)
                    {
                        fluxNxcell += flux_u[endcol + 1][j];
                    }
                }
            }
            fluxy0_cum_T = fluxy0_cum_T + (fluxy0 * (dt - dt_first * (1 - verif)) * (1.0 / ORDER));
            fluxNycell_cum_T = fluxNycell_cum_T + (fluxNycell * (dt - dt_first * (1 - verif)) * (1.0 / ORDER));
            fluxx0_cum_T = fluxx0_cum_T + (fluxx0 * (dt - dt_first * (1 - verif)) * (1.0 / ORDER));
            fluxNxcell_cum_T = fluxNxcell_cum_T + (fluxNxcell * (dt - dt_first * (1 - verif)) * (1.0 / ORDER));
            return (DY * (fluxNxcell_cum_T - fluxx0_cum_T) + (fluxNycell_cum_T - fluxy0_cum_T) * DX);
        }
    }
}
