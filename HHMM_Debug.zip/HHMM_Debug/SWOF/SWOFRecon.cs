﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HHMM
{
    public class Recon
    {
        /// <summary>
        /// 变量重构
        /// </summary>
        /// <param name="reconstrumethod">重构方法，1：MUSCL，2：ENO_mod方法，3：ENO方法</param>
        /// <param name="AMORTENO">重构ARMOTENO值</param>
        /// <param name="MODIFENO">重构MODIFENO值</param>
        /// <param name="Limitermethod">限制器方法，1，Minmod，2，VanAlbada，3.Vanleer</param>
        /// <param name="z">地形</param>
        /// <param name="h">水位</param>
        /// <param name="u">法向速度</param>
        /// <param name="v">切向速度</param>
        /// <param name="delta_z1">i横方向地形变化</param>
        /// <param name="delta_z2">j纵方向地形变化</param>
        /// <param name="som_z1">横方向中间高程变化</param>
        /// <param name="som_z2">纵方向中间高程变化</param>
        /// <param name="z1r">i横右侧方向地形重构</param>
        /// <param name="z1l">i横左侧方向地形重构</param>
        /// <param name="h1r">i横右侧方向水深重构</param>
        /// <param name="h1l">i横左侧方向水深重构</param>
        /// <param name="u1r">i横右侧方向法向速度重构</param>
        /// <param name="u1l">i横左侧方向法向速度重构</param>
        /// <param name="v1r">i横右侧方向切向速度重构</param>
        /// <param name="v1l">i横左侧方向切向速度重构</param>
        /// <param name="z2r">j纵右侧方向地形重构</param>
        /// <param name="z2l">j纵左侧方向地形重构</param>
        /// <param name="h2r">j纵右侧方向水深重构</param>
        /// <param name="h2l">j纵左侧方向水深重构</param>
        /// <param name="u2r">j纵右侧方向法向速度重构</param>
        /// <param name="u2l">j纵左侧方向法向速度重构</param>
        /// <param name="v2r">j纵右侧方向切向速度重构</param>
        /// <param name="v2l">j纵左侧方向切向速度重构</param>
        /// <param name="delz1">相邻网格i横方向重构地形变化</param>
        /// <param name="delz2">相邻网格j纵方向重构地形变化</param>
        /// <param name="delzc1">同一网格i横方向重构地形变化</param>
        /// <param name="delzc2">同一网格j纵方向重构地形变化</param>
        public static void Reconstrution(int EnvPro, int NXCELL, int NYCELL, int reconstrumethod, double AMORTENO, double MODIFENO, int Limitermethod, double[][] z, double[][] h, double[][] u, double[][] v, double[][] delta_z1, double[][] delta_z2, double[][] som_z1, double[][] som_z2, double[][] z1r, double[][] z1l, double[][] h1r, double[][] h1l, double[][] u1r, double[][] u1l, double[][] v1r, double[][] v1l, double[][] z2r, double[][] z2l, double[][] h2r, double[][] h2l, double[][] u2r, double[][] u2l, double[][] v2r, double[][] v2l, double[][] delz1, double[][] delz2, double[][] delzc1, double[][] delzc2)
        {
            double hh1 = 0, uu1 = 0, vv1 = 0;
            double hh2 = 0, uu2 = 0, vv2 = 0;

            double ddz1 = 0, ddh1 = 0, ddu1 = 0, ddv1 = 0;
            double ddz2 = 0, ddh2 = 0, ddu2 = 0, ddv2 = 0;

            double a1, a2, a3, a4;
            double dh, du, dv, dz_h;

            switch (reconstrumethod)
            {
                case 1:
                    double delta_h1 = 0, delta_u1 = 0, delta_v1 = 0;
                    double delta_h2 = 0, delta_u2 = 0, delta_v2 = 0;
                    Parallel.For(1, NYCELL + 1, new ParallelOptions() { MaxDegreeOfParallelism = EnvPro }, j =>
                    //for (int j = 1; j < NYCELL + 1; j++)
                    {
                        delta_h1 = h[1][j] - h[0][j];
                        delta_u1 = u[1][j] - u[0][j];
                        delta_v1 = v[1][j] - v[0][j]; //各分量梯度
                        for (int i = 1; i < NXCELL + 1; i++)
                        {
                            delta_h2 = h[i + 1][j] - h[i][j];
                            delta_u2 = u[i + 1][j] - u[i][j];
                            delta_v2 = v[i + 1][j] - v[i][j];  //各分量梯度
                            a2 = Limitercal(Limitermethod, delta_h1, delta_h2);
                            a4 = Limitercal(Limitermethod, delta_h1 + delta_z1[i - 1][j], delta_h2 + delta_z1[i][j]);
                            dh = a2;
                            dz_h = a4;
                            du = Limitercal(Limitermethod, delta_u1, delta_u2);
                            dv = Limitercal(Limitermethod, delta_v1, delta_v2);
                            h1r[i][j] = h[i][j] + dh * 0.5;
                            h1l[i][j] = h[i][j] - dh * 0.5;
                            z1r[i][j] = z[i][j] + 0.5 * (dz_h - dh);
                            z1l[i][j] = z[i][j] + 0.5 * (dh - dz_h);
                            delzc1[i][j] = (z1r[i][j] - z1l[i][j]);
                            delz1[i - 1][j] = z1l[i][j] - z1r[i - 1][j];
                            if (h[i][j] > 0.0)
                            {
                                u1r[i][j] = u[i][j] + h1l[i][j] * du * 0.5 / h[i][j];
                                u1l[i][j] = u[i][j] - h1r[i][j] * du * 0.5 / h[i][j];
                                v1r[i][j] = v[i][j] + h1l[i][j] * dv * 0.5 / h[i][j];
                                v1l[i][j] = v[i][j] - h1r[i][j] * dv * 0.5 / h[i][j];
                            }
                            else
                            {
                                u1r[i][j] = u[i][j] + du * 0.5;
                                u1l[i][j] = u[i][j] - du * 0.5;
                                v1r[i][j] = v[i][j] + dv * 0.5;
                                v1l[i][j] = v[i][j] - dv * 0.5;
                            }
                            delta_h1 = delta_h2;
                            delta_u1 = delta_u2;
                            delta_v1 = delta_v2;
                        }

                        h1r[0][j] = h[0][j];
                        u1r[0][j] = u[0][j];
                        v1r[0][j] = v[0][j];

                        h1l[NXCELL + 1][j] = h[NXCELL + 1][j];
                        u1l[NXCELL + 1][j] = u[NXCELL + 1][j];
                        v1l[NXCELL + 1][j] = v[NXCELL + 1][j];

                        delz1[NXCELL][j] = z1l[NXCELL + 1][j] - z1r[NXCELL][j];
                    }
                    );
                    Parallel.For(1, NXCELL + 1, new ParallelOptions() { MaxDegreeOfParallelism = EnvPro }, i =>
                    // for (int i = 1; i < NXCELL + 1; i++)
                    {

                        delta_h1 = h[i][1] - h[i][0];
                        delta_u1 = u[i][1] - u[i][0];
                        delta_v1 = v[i][1] - v[i][0];

                        for (int j = 1; j < NYCELL + 1; j++)
                        {
                            delta_h2 = h[i][j + 1] - h[i][j];
                            delta_u2 = u[i][j + 1] - u[i][j];
                            delta_v2 = v[i][j + 1] - v[i][j];

                            a2 = Limitercal(Limitermethod, delta_h1, delta_h2);
                            a4 = Limitercal(Limitermethod, delta_h1 + delta_z2[i][j - 1], delta_h2 + delta_z2[i][j]);

                            dh = a2;
                            dz_h = a4;

                            du = Limitercal(Limitermethod, delta_u1, delta_u2);
                            dv = Limitercal(Limitermethod, delta_v1, delta_v2);

                            h2r[i][j] = h[i][j] + dh * 0.5;
                            h2l[i][j] = h[i][j] - dh * 0.5;

                            z2r[i][j] = z[i][j] + 0.5 * (dz_h - dh);
                            z2l[i][j] = z[i][j] + 0.5 * (dh - dz_h);

                            delzc2[i][j] = (z2r[i][j] - z2l[i][j]);
                            delz2[i][j - 1] = z2l[i][j] - z2r[i][j - 1];

                            if (h[i][j] > 0.0)
                            {
                                u2r[i][j] = u[i][j] + h2l[i][j] * du * 0.5 / h[i][j];
                                u2l[i][j] = u[i][j] - h2r[i][j] * du * 0.5 / h[i][j];
                                v2r[i][j] = v[i][j] + h2l[i][j] * dv * 0.5 / h[i][j];
                                v2l[i][j] = v[i][j] - h2r[i][j] * dv * 0.5 / h[i][j];
                            }
                            else
                            {
                                u2r[i][j] = u[i][j] + du * 0.5;
                                u2l[i][j] = u[i][j] - du * 0.5;
                                v2r[i][j] = v[i][j] + dv * 0.5;
                                v2l[i][j] = v[i][j] - dv * 0.5;
                            } //end if

                            delta_h1 = delta_h2;
                            delta_u1 = delta_u2;
                            delta_v1 = delta_v2;

                        } //end for j

                        h2r[i][0] = h[i][0];
                        u2r[i][0] = u[i][0];
                        v2r[i][0] = v[i][0];
                        h2l[i][NYCELL + 1] = h[i][NYCELL + 1];
                        u2l[i][NYCELL + 1] = u[i][NYCELL + 1];
                        v2l[i][NYCELL + 1] = v[i][NYCELL + 1];

                        delz2[i][NYCELL] = z2l[i][NYCELL + 1] - z2r[i][NYCELL];
                    }
                    );
                    break;

                case 2:
                    //for (int j = 1; j < NYCELL + 1; j++)
                    Parallel.For(1, NYCELL + 1, new ParallelOptions() { MaxDegreeOfParallelism = EnvPro }, j =>
                    {
                        ddh1 = 0.0;
                        ddz1 = 0.0;
                        ddu1 = 0.0;
                        ddv1 = 0.0;

                        hh1 = h[0][j] - 2.0 * h[1][j] + h[2][j];
                        uu1 = u[0][j] - 2.0 * u[1][j] + u[2][j];
                        vv1 = v[0][j] - 2.0 * v[1][j] + v[2][j];

                        delta_h1 = h[1][j] - h[0][j];
                        delta_u1 = u[1][j] - u[0][j];
                        delta_v1 = v[1][j] - v[0][j];

                        for (int i = 1; i < NXCELL; i++)
                        {
                            hh2 = h[i][j] - 2.0 * h[i + 1][j] + h[i + 2][j];
                            uu2 = u[i][j] - 2.0 * u[i + 1][j] + u[i + 2][j];
                            vv2 = v[i][j] - 2.0 * v[i + 1][j] + v[i + 2][j];

                            ddh2 = AMORTENO * Limitercal(Limitermethod, hh1, hh2);
                            ddu2 = AMORTENO * Limitercal(Limitermethod, uu1, uu2);
                            ddz2 = AMORTENO * Limitercal(Limitermethod, hh1 + som_z1[i][j], hh2 + som_z1[i + 1][j]);
                            ddv2 = AMORTENO * Limitercal(Limitermethod, vv1, vv2);

                            hh1 = hh2;
                            uu1 = uu2;
                            vv1 = vv2;

                            delta_h2 = h[i + 1][j] - h[i][j];
                            delta_u2 = u[i + 1][j] - u[i][j];
                            delta_v2 = v[i + 1][j] - v[i][j];

                            a2 = Limitercal(Limitermethod, delta_h1 + ddh1 * 0.5, delta_h2 - ddh2 * 0.5);
                            a4 = Limitercal(Limitermethod, delta_h1 + delta_z1[i - 1][j] + ddz1 * 0.5, delta_h2 + delta_z1[i][j] - ddz2 * 0.5);

                            a1 = Limitercal(Limitermethod, delta_h1, delta_h2);
                            dh = Limitercal(Limitermethod, 2 * MODIFENO * a1, a2);

                            a3 = Limitercal(Limitermethod, delta_h1 + delta_z1[i - 1][j], delta_h2 + delta_z1[i][j]);
                            dz_h = Limitercal(Limitermethod, 2 * MODIFENO * a3, a4);


                            du = Limitercal(Limitermethod, delta_u1 + ddu1 * 0.5, delta_u2 - ddu2 * 0.5);
                            dv = Limitercal(Limitermethod, delta_v1 + ddv1 * 0.5, delta_v2 - ddv2 * 0.5);

                            delta_h1 = delta_h2;
                            delta_u1 = delta_u2;
                            delta_v1 = delta_v2;

                            h1r[i][j] = h[i][j] + dh * 0.5;
                            h1l[i][j] = h[i][j] - dh * 0.5;

                            z1r[i][j] = z[i][j] + 0.5 * (dz_h - dh);
                            z1l[i][j] = z[i][j] + 0.5 * (dh - dz_h);
                            delzc1[i][j] = z1r[i][j] - z1l[i][j];
                            delz1[i - 1][j] = z1l[i][j] - z1r[i - 1][j];

                            if (h[i][j] > 0.0)
                            {
                                u1r[i][j] = u[i][j] + h1l[i][j] * du * 0.5 / h[i][j];
                                u1l[i][j] = u[i][j] - h1r[i][j] * du * 0.5 / h[i][j];
                                v1r[i][j] = v[i][j] + h1l[i][j] * dv * 0.5 / h[i][j];
                                v1l[i][j] = v[i][j] - h1r[i][j] * dv * 0.5 / h[i][j];
                            }
                            else
                            {
                                u1r[i][j] = u[i][j] + du * 0.5;
                                u1l[i][j] = u[i][j] - du * 0.5;
                                v1r[i][j] = v[i][j] + dv * 0.5;
                                v1l[i][j] = v[i][j] - dv * 0.5;
                            } //end if
                            ddh1 = ddh2;
                            ddz1 = ddz2;
                            ddu1 = ddu2;
                            ddv1 = ddv2;
                        } //end for


                        a2 = Limitercal(Limitermethod, delta_h1 + ddh1 * 0.5, h[NXCELL + 1][j] - h[NXCELL][j]);
                        a4 = Limitercal(Limitermethod, delta_h1 + delta_z1[NXCELL - 1][j] + ddz1 * 0.5, h[NXCELL + 1][j] - h[NXCELL][j] + delta_z1[NXCELL][j]);

                        a1 = Limitercal(Limitermethod, delta_h1, h[NXCELL + 1][j] - h[NXCELL][j]);
                        dh = Limitercal(Limitermethod, 2 * MODIFENO * a1, a2);

                        a3 = Limitercal(Limitermethod, delta_h1 + delta_z1[NXCELL - 1][j], h[NXCELL + 1][j] - h[NXCELL][j] + delta_z1[NXCELL][j]);
                        dz_h = Limitercal(Limitermethod, 2 * MODIFENO * a3, a4);

                        du = Limitercal(Limitermethod, delta_u1 + ddu1 * 0.5, u[NXCELL + 1][j] - u[NXCELL][j]);
                        dv = Limitercal(Limitermethod, delta_v1 + ddv1 * 0.5, v[NXCELL + 1][j] - v[NXCELL][j]);
                        h1r[NXCELL][j] = h[NXCELL][j] + dh * 0.5;
                        h1l[NXCELL][j] = h[NXCELL][j] - dh * 0.5;

                        z1r[NXCELL][j] = z[NXCELL][j] + 0.5 * (dz_h - dh);
                        z1l[NXCELL][j] = z[NXCELL][j] + 0.5 * (dh - dz_h);
                        delzc1[NXCELL][j] = z1r[NXCELL][j] - z1l[NXCELL][j];
                        delz1[NXCELL - 1][j] = z1l[NXCELL][j] - z1r[NXCELL - 1][j];
                        delz1[NXCELL][j] = z1l[NXCELL + 1][j] - z1r[NXCELL][j];

                        if (h[NXCELL][j] > 0.0)
                        {
                            u1r[NXCELL][j] = u[NXCELL][j] + h1l[NXCELL][j] * du * 0.5 / h[NXCELL][j];
                            u1l[NXCELL][j] = u[NXCELL][j] - h1r[NXCELL][j] * du * 0.5 / h[NXCELL][j];
                            v1r[NXCELL][j] = v[NXCELL][j] + h1l[NXCELL][j] * dv * 0.5 / h[NXCELL][j];
                            v1l[NXCELL][j] = v[NXCELL][j] - h1r[NXCELL][j] * dv * 0.5 / h[NXCELL][j];
                        }
                        else
                        {
                            u1r[NXCELL][j] = u[NXCELL][j] + du * 0.5;
                            u1l[NXCELL][j] = u[NXCELL][j] - du * 0.5;
                            v1r[NXCELL][j] = v[NXCELL][j] + dv * 0.5;
                            v1l[NXCELL][j] = v[NXCELL][j] - dv * 0.5;
                        } //end if
                        h1r[0][j] = h[0][j];
                        u1r[0][j] = u[0][j];
                        v1r[0][j] = v[0][j];
                        h1l[NXCELL + 1][j] = h[NXCELL + 1][j];
                        u1l[NXCELL + 1][j] = u[NXCELL + 1][j];
                        v1l[NXCELL + 1][j] = v[NXCELL + 1][j];
                    } //end for
                    );

                    Parallel.For(1, NXCELL + 1, new ParallelOptions() { MaxDegreeOfParallelism = EnvPro }, i =>
                    // for (int i = 1; i < NXCELL + 1; i++)
                    {

                        ddh1 = 0.0;
                        ddz1 = 0.0;
                        ddu1 = 0.0;
                        ddv1 = 0.0;

                        hh1 = h[i][0] - 2.0 * h[i][1] + h[i][2];
                        uu1 = u[i][0] - 2.0 * u[i][1] + u[i][2];
                        vv1 = v[i][0] - 2.0 * v[i][1] + v[i][2];

                        delta_h1 = h[i][1] - h[i][0];
                        delta_u1 = u[i][1] - u[i][0];
                        delta_v1 = v[i][1] - v[i][0];

                        for (int j = 1; j < NYCELL; j++)
                        {
                            hh2 = h[i][j] - 2.0 * h[i][j + 1] + h[i][j + 2];
                            uu2 = u[i][j] - 2.0 * u[i][j + 1] + u[i][j + 2];
                            vv2 = v[i][j] - 2.0 * v[i][j + 1] + v[i][j + 2];

                            ddh2 = AMORTENO * Limitercal(Limitermethod, hh1, hh2);
                            ddu2 = AMORTENO * Limitercal(Limitermethod, uu1, uu2);
                            ddz2 = AMORTENO * Limitercal(Limitermethod, hh1 + som_z2[i][j], hh2 + som_z2[i][j + 1]);
                            ddv2 = AMORTENO * Limitercal(Limitermethod, vv1, vv2);

                            hh1 = hh2;
                            uu1 = uu2;
                            vv1 = vv2;

                            delta_h2 = h[i][j + 1] - h[i][j];
                            delta_u2 = u[i][j + 1] - u[i][j];
                            delta_v2 = v[i][j + 1] - v[i][j];

                            a2 = Limitercal(Limitermethod, delta_h1 + ddh1 * 0.5, delta_h2 - ddh2 * 0.5);
                            a4 = Limitercal(Limitermethod, delta_h1 + delta_z2[i][j - 1] + ddz1 * 0.5, delta_h2 + delta_z2[i][j] - ddz2 * 0.5);

                            a1 = Limitercal(Limitermethod, delta_h1, delta_h2);
                            dh = Limitercal(Limitermethod, 2 * MODIFENO * a1, a2);

                            a3 = Limitercal(Limitermethod, delta_h1 + delta_z2[i][j - 1], delta_h2 + delta_z2[i][j]);
                            dz_h = Limitercal(Limitermethod, 2 * MODIFENO * a3, a4);

                            du = Limitercal(Limitermethod, delta_u1 + ddu1 * 0.5, delta_u2 - ddu2 * 0.5);
                            dv = Limitercal(Limitermethod, delta_v1 + ddv1 * 0.5, delta_v2 - ddv2 * 0.5);
                            delta_h1 = delta_h2;
                            delta_u1 = delta_u2;
                            delta_v1 = delta_v2;

                            h2r[i][j] = h[i][j] + dh * 0.5;
                            h2l[i][j] = h[i][j] - dh * 0.5;

                            z2r[i][j] = z[i][j] + 0.5 * (dz_h - dh);
                            z2l[i][j] = z[i][j] + 0.5 * (dh - dz_h);
                            delzc2[i][j] = z2r[i][j] - z2l[i][j];
                            delz2[i][j - 1] = z2l[i][j] - z2r[i][j - 1];

                            if (h[i][j] > 0.0)
                            {
                                u2r[i][j] = u[i][j] + h2l[i][j] * du * 0.5 / h[i][j];
                                u2l[i][j] = u[i][j] - h2r[i][j] * du * 0.5 / h[i][j];
                                v2r[i][j] = v[i][j] + h2l[i][j] * dv * 0.5 / h[i][j];
                                v2l[i][j] = v[i][j] - h2r[i][j] * dv * 0.5 / h[i][j];
                            }
                            else
                            {
                                u2r[i][j] = u[i][j] + du * 0.5;
                                u2l[i][j] = u[i][j] - du * 0.5;
                                v2r[i][j] = v[i][j] + dv * 0.5;
                                v2l[i][j] = v[i][j] - dv * 0.5;
                            } //end if

                            ddh1 = ddh2;
                            ddz1 = ddz2;
                            ddu1 = ddu2;
                            ddv1 = ddv2;

                        } //end for

                        a2 = Limitercal(Limitermethod, delta_h1 + ddh1 * 0.5, (h[i][NYCELL + 1] - h[i][NYCELL]));
                        a4 = Limitercal(Limitermethod, delta_h1 + delta_z2[i][NYCELL - 1] + ddz1 * 0.5, h[i][NYCELL + 1] - h[i][NYCELL] + delta_z2[i][NYCELL]);

                        a1 = Limitercal(Limitermethod, delta_h1, h[i][NYCELL + 1] - h[i][NYCELL]);
                        dh = Limitercal(Limitermethod, 2 * MODIFENO * a1, a2);

                        a3 = Limitercal(Limitermethod, delta_h1 + delta_z2[i][NYCELL - 1], h[i][NYCELL + 1] - h[i][NYCELL] + delta_z2[i][NYCELL]);
                        dz_h = Limitercal(Limitermethod, 2 * MODIFENO * a3, a4);

                        du = Limitercal(Limitermethod, delta_u1 + ddu1 * 0.5, u[i][NYCELL + 1] - u[i][NYCELL]);
                        dv = Limitercal(Limitermethod, delta_v1 + ddv1 * 0.5, v[i][NYCELL + 1] - v[i][NYCELL]);

                        h2r[i][NYCELL] = h[i][NYCELL] + dh * 0.5;
                        h2l[i][NYCELL] = h[i][NYCELL] - dh * 0.5;

                        z2r[i][NYCELL] = z[i][NYCELL] + 0.5 * (dz_h - dh);
                        z2l[i][NYCELL] = z[i][NYCELL] + 0.5 * (dh - dz_h);
                        delzc2[i][NYCELL] = z2r[i][NYCELL] - z2l[i][NYCELL];
                        delz2[i][NYCELL - 1] = z2l[i][NYCELL] - z2r[i][NYCELL - 1];
                        delz2[i][NYCELL] = z2l[i][NYCELL + 1] - z2r[i][NYCELL];

                        if (h[i][NYCELL] > 0.0)
                        {
                            u2r[i][NYCELL] = u[i][NYCELL] + h2l[i][NYCELL] * du * 0.5 / h[i][NYCELL];
                            u2l[i][NYCELL] = u[i][NYCELL] - h2r[i][NYCELL] * du * 0.5 / h[i][NYCELL];
                            v2r[i][NYCELL] = v[i][NYCELL] + h2l[i][NYCELL] * dv * 0.5 / h[i][NYCELL];
                            v2l[i][NYCELL] = v[i][NYCELL] - h2r[i][NYCELL] * dv * 0.5 / h[i][NYCELL];
                        }
                        else
                        {
                            u2r[i][NYCELL] = u[i][NYCELL] + du * 0.5;
                            u2l[i][NYCELL] = u[i][NYCELL] - du * 0.5;
                            v2r[i][NYCELL] = v[i][NYCELL] + dv * 0.5;
                            v2l[i][NYCELL] = v[i][NYCELL] - dv * 0.5;
                        } //end if

                        h2r[i][0] = h[i][0];
                        u2r[i][0] = u[i][0];
                        v2r[i][0] = v[i][0];
                        h2l[i][NYCELL + 1] = h[i][NYCELL + 1];
                        u2l[i][NYCELL + 1] = u[i][NYCELL + 1];
                        v2l[i][NYCELL + 1] = v[i][NYCELL + 1];

                    }
                    );
                    //end for
                    break;
                case 3:
                    Parallel.For(1, NYCELL + 1, new ParallelOptions() { MaxDegreeOfParallelism = EnvPro }, j =>
                    //for (int j = 1; j < NYCELL + 1; j++)
                    {

                        ddh1 = 0.0;
                        ddz1 = 0.0;
                        ddu1 = 0.0;
                        ddv1 = 0.0;

                        hh1 = h[0][j] - 2.0 * h[1][j] + h[2][j];
                        uu1 = u[0][j] - 2.0 * u[1][j] + u[2][j];
                        vv1 = v[0][j] - 2.0 * v[1][j] + v[2][j];

                        delta_h1 = h[1][j] - h[0][j];
                        delta_u1 = u[1][j] - u[0][j];
                        delta_v1 = v[1][j] - v[0][j];

                        for (int i = 1; i < NXCELL; i++)
                        {

                            hh2 = h[i][j] - 2.0 * h[i + 1][j] + h[i + 2][j];
                            uu2 = u[i][j] - 2.0 * u[i + 1][j] + u[i + 2][j];
                            vv2 = v[i][j] - 2.0 * v[i + 1][j] + v[i + 2][j];

                            ddh2 = AMORTENO * Limitercal(Limitermethod, hh1, hh2);
                            ddu2 = AMORTENO * Limitercal(Limitermethod, uu1, uu2);
                            ddz2 = AMORTENO * Limitercal(Limitermethod, hh1 + som_z1[i][j], hh2 + som_z1[i + 1][j]);
                            ddv2 = AMORTENO * Limitercal(Limitermethod, vv1, vv2);

                            hh1 = hh2;
                            uu1 = uu2;
                            vv1 = vv2;

                            delta_h2 = h[i + 1][j] - h[i][j];
                            delta_u2 = u[i + 1][j] - u[i][j];
                            delta_v2 = v[i + 1][j] - v[i][j];

                            a2 = Limitercal(Limitermethod, delta_h1 + ddh1 * 0.5, delta_h2 - ddh2 * 0.5);
                            a4 = Limitercal(Limitermethod, delta_h1 + delta_z1[i - 1][j] + ddz1 * 0.5, delta_h2 + delta_z1[i][j] - ddz2 * 0.5);
                            dh = a2;
                            dz_h = a4;

                            du = Limitercal(Limitermethod, delta_u1 + ddu1 * 0.5, delta_u2 - ddu2 * 0.5);
                            dv = Limitercal(Limitermethod, delta_v1 + ddv1 * 0.5, delta_v2 - ddv2 * 0.5);

                            delta_h1 = delta_h2;
                            delta_u1 = delta_u2;
                            delta_v1 = delta_v2;

                            h1r[i][j] = h[i][j] + dh * 0.5;
                            h1l[i][j] = h[i][j] - dh * 0.5;

                            z1r[i][j] = z[i][j] + 0.5 * (dz_h - dh);
                            z1l[i][j] = z[i][j] + 0.5 * (dh - dz_h);
                            delzc1[i][j] = z1r[i][j] - z1l[i][j];
                            delz1[i - 1][j] = z1l[i][j] - z1r[i - 1][j];

                            if (h[i][j] > 0.0)
                            {
                                u1r[i][j] = u[i][j] + h1l[i][j] * du * 0.5 / h[i][j];
                                u1l[i][j] = u[i][j] - h1r[i][j] * du * 0.5 / h[i][j];
                                v1r[i][j] = v[i][j] + h1l[i][j] * dv * 0.5 / h[i][j];
                                v1l[i][j] = v[i][j] - h1r[i][j] * dv * 0.5 / h[i][j];
                            }
                            else
                            {
                                u1r[i][j] = u[i][j] + du * 0.5;
                                u1l[i][j] = u[i][j] - du * 0.5;
                                v1r[i][j] = v[i][j] + dv * 0.5;
                                v1l[i][j] = v[i][j] - dv * 0.5;
                            } //end if

                            ddh1 = ddh2;
                            ddz1 = ddz2;
                            ddu1 = ddu2;
                            ddv1 = ddv2;

                        } //end for


                        a2 = Limitercal(Limitermethod, delta_h1 + ddh1 * 0.5, h[NXCELL + 1][j] - h[NXCELL][j]);
                        a4 = Limitercal(Limitermethod, delta_h1 + delta_z1[NXCELL - 1][j] + ddz1 * 0.5, h[NXCELL + 1][j] - h[NXCELL][j] + delta_z1[NXCELL][j]);

                        dh = a2;
                        dz_h = a4;

                        du = Limitercal(Limitermethod, delta_u1 + ddu1 * 0.5, u[NXCELL + 1][j] - u[NXCELL][j]);
                        dv = Limitercal(Limitermethod, delta_v1 + ddv1 * 0.5, v[NXCELL + 1][j] - v[NXCELL][j]);

                        h1r[NXCELL][j] = h[NXCELL][j] + dh * 0.5;
                        h1l[NXCELL][j] = h[NXCELL][j] - dh * 0.5;

                        z1r[NXCELL][j] = z[NXCELL][j] + 0.5 * (dz_h - dh);
                        z1l[NXCELL][j] = z[NXCELL][j] + 0.5 * (dh - dz_h);
                        delzc1[NXCELL][j] = z1r[NXCELL][j] - z1l[NXCELL][j];
                        delz1[NXCELL - 1][j] = z1l[NXCELL][j] - z1r[NXCELL - 1][j];
                        delz1[NXCELL][j] = z1l[NXCELL + 1][j] - z1r[NXCELL][j];

                        if (h[NXCELL][j] > 0.0)
                        {
                            u1r[NXCELL][j] = u[NXCELL][j] + h1l[NXCELL][j] * du * 0.5 / h[NXCELL][j];
                            u1l[NXCELL][j] = u[NXCELL][j] - h1r[NXCELL][j] * du * 0.5 / h[NXCELL][j];
                            v1r[NXCELL][j] = v[NXCELL][j] + h1l[NXCELL][j] * dv * 0.5 / h[NXCELL][j];
                            v1l[NXCELL][j] = v[NXCELL][j] - h1r[NXCELL][j] * dv * 0.5 / h[NXCELL][j];
                        }
                        else
                        {
                            u1r[NXCELL][j] = u[NXCELL][j] + du * 0.5;
                            u1l[NXCELL][j] = u[NXCELL][j] - du * 0.5;
                            v1r[NXCELL][j] = v[NXCELL][j] + dv * 0.5;
                            v1l[NXCELL][j] = v[NXCELL][j] - dv * 0.5;
                        } //end if

                        h1r[0][j] = h[0][j];
                        u1r[0][j] = u[0][j];
                        v1r[0][j] = v[0][j];
                        h1l[NXCELL + 1][j] = h[NXCELL + 1][j];
                        u1l[NXCELL + 1][j] = u[NXCELL + 1][j];
                        v1l[NXCELL + 1][j] = v[NXCELL + 1][j];

                    }
                    );//end for

                    Parallel.For(1, NXCELL + 1, new ParallelOptions() { MaxDegreeOfParallelism = EnvPro }, i =>
                    //for (int i = 1; i < NXCELL + 1; i++)
                    {

                        ddh1 = 0.0;
                        ddz1 = 0.0;
                        ddu1 = 0.0;
                        ddv1 = 0.0;

                        hh1 = h[i][0] - 2.0 * h[i][1] + h[i][2];
                        uu1 = u[i][0] - 2.0 * u[i][1] + u[i][2];
                        vv1 = v[i][0] - 2.0 * v[i][1] + v[i][2];

                        delta_h1 = h[i][1] - h[i][0];
                        delta_u1 = u[i][1] - u[i][0];
                        delta_v1 = v[i][1] - v[i][0];

                        for (int j = 1; j < NYCELL; j++)
                        {
                            hh2 = h[i][j] - 2.0 * h[i][j + 1] + h[i][j + 2];
                            uu2 = u[i][j] - 2.0 * u[i][j + 1] + u[i][j + 2];
                            vv2 = v[i][j] - 2.0 * v[i][j + 1] + v[i][j + 2];

                            ddh2 = AMORTENO * Limitercal(Limitermethod, hh1, hh2);
                            ddu2 = AMORTENO * Limitercal(Limitermethod, uu1, uu2);
                            ddz2 = AMORTENO * Limitercal(Limitermethod, hh1 + som_z2[i][j], hh2 + som_z2[i][j + 1]);
                            ddv2 = AMORTENO * Limitercal(Limitermethod, vv1, vv2);


                            hh1 = hh2;
                            uu1 = uu2;
                            vv1 = vv2;

                            delta_h2 = h[i][j + 1] - h[i][j];
                            delta_u2 = u[i][j + 1] - u[i][j];
                            delta_v2 = v[i][j + 1] - v[i][j];

                            a2 = Limitercal(Limitermethod, delta_h1 + ddh1 * 0.5, delta_h2 - ddh2 * 0.5);
                            a4 = Limitercal(Limitermethod, delta_h1 + delta_z2[i][j - 1] + ddz1 * 0.5, delta_h2 + delta_z2[i][j] - ddz2 * 0.5);

                            dh = a2;
                            dz_h = a4;

                            du = Limitercal(Limitermethod, delta_u1 + ddu1 * 0.5, delta_u2 - ddu2 * 0.5);
                            dv = Limitercal(Limitermethod, delta_v1 + ddv1 * 0.5, delta_v2 - ddv2 * 0.5);

                            delta_h1 = delta_h2;
                            delta_u1 = delta_u2;
                            delta_v1 = delta_v2;

                            h2r[i][j] = h[i][j] + dh * 0.5;
                            h2l[i][j] = h[i][j] - dh * 0.5;

                            z2r[i][j] = z[i][j] + 0.5 * (dz_h - dh);
                            z2l[i][j] = z[i][j] + 0.5 * (dh - dz_h);
                            delzc2[i][j] = z2r[i][j] - z2l[i][j];
                            delz2[i][j - 1] = z2l[i][j] - z2r[i][j - 1];

                            if (h[i][j] > 0.0)
                            {
                                u2r[i][j] = u[i][j] + h2l[i][j] * du * 0.5 / h[i][j];
                                u2l[i][j] = u[i][j] - h2r[i][j] * du * 0.5 / h[i][j];
                                v2r[i][j] = v[i][j] + h2l[i][j] * dv * 0.5 / h[i][j];
                                v2l[i][j] = v[i][j] - h2r[i][j] * dv * 0.5 / h[i][j];
                            }
                            else
                            {
                                u2r[i][j] = u[i][j] + du * 0.5;
                                u2l[i][j] = u[i][j] - du * 0.5;
                                v2r[i][j] = v[i][j] + dv * 0.5;
                                v2l[i][j] = v[i][j] - dv * 0.5;
                            } //end if

                            ddh1 = ddh2;
                            ddz1 = ddz2;
                            ddu1 = ddu2;
                            ddv1 = ddv2;

                        } //end for

                        a2 = Limitercal(Limitermethod, delta_h1 + ddh1 * 0.5, (h[i][NYCELL + 1] - h[i][NYCELL]));
                        a4 = Limitercal(Limitermethod, delta_h1 + delta_z2[i][NYCELL - 1] + ddz1 * 0.5, h[i][NYCELL + 1] - h[i][NYCELL] + delta_z2[i][NYCELL]);

                        dh = a2;
                        dz_h = a4;

                        du = Limitercal(Limitermethod, delta_u1 + ddu1 * 0.5, u[i][NYCELL + 1] - u[i][NYCELL]);
                        dv = Limitercal(Limitermethod, delta_v1 + ddv1 * 0.5, v[i][NYCELL + 1] - v[i][NYCELL]);

                        h2r[i][NYCELL] = h[i][NYCELL] + dh * 0.5;
                        h2l[i][NYCELL] = h[i][NYCELL] - dh * 0.5;

                        z2r[i][NYCELL] = z[i][NYCELL] + 0.5 * (dz_h - dh);
                        z2l[i][NYCELL] = z[i][NYCELL] + 0.5 * (dh - dz_h);
                        delzc2[i][NYCELL] = z2r[i][NYCELL] - z2l[i][NYCELL];
                        delz2[i][NYCELL - 1] = z2l[i][NYCELL] - z2r[i][NYCELL - 1];
                        delz2[i][NYCELL] = z2l[i][NYCELL + 1] - z2r[i][NYCELL];

                        if (h[i][NYCELL] > 0.0)
                        {
                            u2r[i][NYCELL] = u[i][NYCELL] + h2l[i][NYCELL] * du * 0.5 / h[i][NYCELL];
                            u2l[i][NYCELL] = u[i][NYCELL] - h2r[i][NYCELL] * du * 0.5 / h[i][NYCELL];
                            v2r[i][NYCELL] = v[i][NYCELL] + h2l[i][NYCELL] * dv * 0.5 / h[i][NYCELL];
                            v2l[i][NYCELL] = v[i][NYCELL] - h2r[i][NYCELL] * dv * 0.5 / h[i][NYCELL];
                        }
                        else
                        {
                            u2r[i][NYCELL] = u[i][NYCELL] + du * 0.5;
                            u2l[i][NYCELL] = u[i][NYCELL] - du * 0.5;
                            v2r[i][NYCELL] = v[i][NYCELL] + dv * 0.5;
                            v2l[i][NYCELL] = v[i][NYCELL] - dv * 0.5;
                        } //end if

                        h2r[i][0] = h[i][0];
                        u2r[i][0] = u[i][0];
                        v2r[i][0] = v[i][0];
                        h2l[i][NYCELL + 1] = h[i][NYCELL + 1];
                        u2l[i][NYCELL + 1] = u[i][NYCELL + 1];
                        v2l[i][NYCELL + 1] = v[i][NYCELL + 1];

                    }
                    );//end for
                    break;
            }
        }

        /// <summary>
        /// 计算限制器
        /// </summary>
        /// <param name="method">1: Minmod方法；2：VanAlbada；3.VanLeer</param>
        /// <param name="a">数据1</param>
        /// <param name="b">数据2</param>
        /// <returns></returns>
        public static double Limitercal(int method, double a, double b)
        {
            double rec = 0;
            switch (method)
            {
                case 1:
                    if ((a >= 0) && (b >= 0))
                        rec = Math.Min(a, b);
                    else if ((a <= 0) && (b <= 0))
                        rec = Math.Max(a, b);
                    else
                        rec = 0;
                    break;
                case 2:
                    if (a * b < 0)
                        rec = 0.0;
                    else
                        rec = (a * (b * b + SVCSconst.EPSILON) + b * (a * a + SVCSconst.EPSILON)) / (a * a + b * b + 2.0 * SVCSconst.EPSILON);
                    break;
                case 3:
                    if ((a > 0.0 && b > 0.0) || (a < 0.0 && b < 0.0))
                        rec = 2.0 * a * b / (a + b);
                    else
                        rec = 0.0;
                    break;
            }
            return rec;
        }

        /// <summary>
        /// 基于地形计算边界地形重构值
        /// </summary>
        /// <param name="NXCELL">实际横方向网格数量</param>
        /// <param name="NYCELL">实际纵方向网格数据</param>
        /// <param name="z">地形高程</param>
        /// <param name="delta_z1">i横方向高程变化</param>
        /// <param name="delta_z2">j纵方向高程变化</param>
        /// <param name="z1r">i横右侧方向地形重构</param>
        /// <param name="z1l">i横左侧方向地形重构</param>
        /// <param name="z2r">j纵右侧方向地形重构</param>
        /// <param name="z2l">j纵左侧方向地形重构</param>
        public static void deltazcalT(int NXCELL, int NYCELL, double[][] z, double[][] delta_z1, double[][] delta_z2, double[][] z1r, double[][] z1l, double[][] z2r, double[][] z2l, double[][] som_z1, double[][] som_z2)
        {
            for (int j = 1; j < NYCELL + 1; j++)
            {
                z1r[0][j] = z[0][j];
                z1l[NXCELL + 1][j] = z[NXCELL + 1][j];
                delta_z1[0][j] = z[1][j] - z[0][j];
            } //end for j

            for (int i = 1; i < NXCELL + 1; i++)
            {
                z2r[i][0] = z[i][0];
                z2l[i][NYCELL + 1] = z[i][NYCELL + 1];
                delta_z2[i][0] = z[i][1] - z[i][0];
                for (int j = 1; j < NYCELL + 1; j++)
                {
                    delta_z1[i][j] = z[i + 1][j] - z[i][j];                    //u方向斜率
                    delta_z2[i][j] = z[i][j + 1] - z[i][j];                    //v方向斜率
                    som_z1[i][j] = z[i - 1][j] - 2.0 * z[i][j] + z[i + 1][j];    //u方向中间斜率
                    som_z2[i][j] = z[i][j - 1] - 2.0 * z[i][j] + z[i][j + 1];    //v方向中间斜率
                }
            }
        }

        public static void deltazcalO(int NXCELL, int NYCELL, double[][] z, double[][] delta_z1, double[][] delta_z2, double[][] delzc1, double[][] delzc2)
        {
            for (int i = 1; i <= NXCELL + 1; i++)
            {
                for (int j = 1; j <= NYCELL; j++)
                {
                    delta_z1[i - 1][j] = z[i][j] - z[i - 1][j];
                } //end for j
            } //end for i

            for (int i = 1; i <= NXCELL; i++)
            {
                for (int j = 1; j <= NYCELL + 1; j++)
                {
                    delta_z2[i][j - 1] = z[i][j] - z[i][j - 1];
                } //end for j
            } //end for i

            for (int i = 1; i <= NXCELL; i++)
            {
                for (int j = 1; j <= NYCELL; j++)
                {
                    delzc2[i][j] = 0.0;
                    delzc1[i][j] = 0.0;
                }
            }
        }

    }
}

