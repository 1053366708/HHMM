﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHMM
{
    public class Bccal
    {
        /// <summary>
        /// 边界条件计算,边界类型1：固壁，2：通量，3：定水位，4：定流量
        /// </summary>
        /// <param name="LBcscheme">左边界类型</param>
        /// <param name="RBcscheme">右边界类型</param>
        /// <param name="TBcscheme">上边界类型</param>
        /// <param name="BBcscheme">下边界类型</param>
        /// <param name="Lqfix">左边界给定流量</param>
        /// <param name="Rqfix">右边界给定流量</param>
        /// <param name="Tqfix">上边界给定流量</param>
        /// <param name="Bqfix">下边界给定流量</param>
        /// <param name="Lhfix">左边界给定水位</param>
        /// <param name="Rhfix">右边界给定水位</param>
        /// <param name="Thfix">上边界给定水位</param>
        /// <param name="Bhfix">下边界给定水位</param>
        /// <param name="h">水位</param>
        /// <param name="u">法向流速</param>
        /// <param name="v">切向流速</param>
        public static void Boundarycal(int NXCELL, int NYCELL, int[] LBcscheme, int[] RBcscheme, int[] TBcscheme, int[] BBcscheme, double[] Lqfix, double[] Rqfix, double[] Tqfix, double[] Bqfix, double[] Lhfix, double[] Rhfix, double[] Thfix, double[] Bhfix, double[][] h, double[][] u, double[][] v)
        {
            for (int j = 1; j < NYCELL + 1; j++)
            {
                Bcschemecal(LBcscheme[j], Lqfix[j], Lhfix[j], -1, 0, u[1][j], v[1][j], h[1][j], ref u[0][j], ref v[0][j], ref h[0][j]);
                Bcschemecal(RBcscheme[j], Rqfix[j], Rhfix[j], 1, 0, u[NXCELL][j], v[NXCELL][j], h[NXCELL][j], ref u[NXCELL + 1][j], ref v[NXCELL + 1][j], ref h[NXCELL + 1][j]);
            }
            for (int i = 1; i < NXCELL + 1; i++)
            {
                Bcschemecal(TBcscheme[i], Bqfix[i], Bhfix[i], 0, -1, v[i][1], u[i][1], h[i][1], ref v[i][0], ref u[i][0], ref h[i][0]);
                Bcschemecal(BBcscheme[i], Tqfix[i], Thfix[i], 0, 1, v[i][NYCELL], u[i][NYCELL], h[i][NYCELL], ref v[i][NYCELL + 1], ref u[i][NYCELL + 1], ref h[i][NYCELL + 1]);

            }
        }

        /// <summary>
        /// 基于不同边界类型，进行计算
        /// </summary>
        /// <param name="Bcscheme">边界类型，边界类型1：固壁，2：通量，3：定水位，4：定流量</param>
        /// <param name="qfix">网格流量</param>
        /// <param name="hfix">网格水位</param>
        /// <param name="n1">设定是否为左（-1）或右（1）边界</param>
        /// <param name="n2">设定是否为下（-1）或上（1）边界</param>
        /// <param name="unorm_in">内网格法向量速度</param>
        /// <param name="utan_in">内网格切向量速度</param>
        /// <param name="hin">内网格法向量速度</param>
        /// <param name="unormbound">边界法向量速度</param>
        /// <param name="utanbound">边界切向量速度</param>
        /// <param name="hbound">边界水深</param>
        public static void Bcschemecal(int Bcscheme, double qfix, double hfix, int n1, int n2, double unorm_in, double utan_in, double hin, ref double unormbound, ref double utanbound, ref double hbound)
        {
            switch (Bcscheme)
            {
                case 1:
                    Bcwall(unorm_in, utan_in, hin, ref unormbound, ref utanbound, ref hbound);
                    break;
                case 2:
                    Bcneuman(unorm_in, utan_in, hin, ref unormbound, ref utanbound, ref hbound);
                    break;
                case 3:
                    Bcimpheigh(qfix, hfix, n1, n2, unorm_in, utan_in, hin, ref unormbound, ref utanbound, ref hbound);
                    break;
                case 4:
                    Bcimpdischarge(qfix, hfix, n1, n2, unorm_in, utan_in, hin, ref unormbound, ref utanbound, ref hbound);
                    break;
            }
        }

        /// <summary>
        /// 固壁边界
        /// </summary>
        /// <param name="unorm_in">内网格法向量速度</param>
        /// <param name="utan_in">内网格切向量速度</param>
        /// <param name="hin">内网格水深</param>
        /// <param name="unormbound">边界法向量速度</param>
        /// <param name="utanbound">边界切向量速度</param>
        /// <param name="hbound">边界水深</param>
        public static void Bcwall(double unorm_in, double utan_in, double hin, ref double unormbound, ref double utanbound, ref double hbound)
        {
            unormbound = -unorm_in;
            utanbound = utan_in;
            hbound = hin;
        }

        /// <summary>
        /// 自由边界
        /// </summary>
        /// <param name="unorm_in">内网格法向量速度</param>
        /// <param name="utan_in">内网格切向量速度</param>
        /// <param name="hin">内网格水深</param>
        /// <param name="unormbound">边界法向量速度</param>
        /// <param name="utanbound">边界切向量速度</param>
        /// <param name="hbound">边界水深</param>
        public static void Bcneuman(double unorm_in, double utan_in, double hin, ref double unormbound, ref double utanbound, ref double hbound)
        {
            unormbound = unorm_in;
            utanbound = utan_in;
            hbound = hin;
        }

        /// <summary>
        /// 水位边界
        /// </summary>
        /// <param name="qfix">流量</param>
        /// <param name="hfix">水位</param>
        /// <param name="n1">n1 integer to specify whether it is the left (-1) or the right (1) boundary </param>
        /// <param name="n2">n2 integer to specify whether it is the bottom (-1) or the top (1) boundary (unused)</param>
        /// <param name="unorm_in">内网格法向量速度</param>
        /// <param name="utan_in">内网格切向量速度</param>
        /// <param name="hin">内网个水深</param>
        /// <param name="unormbound">边界法向量速度</param>
        /// <param name="utanbound">边界切向量速度</param>
        /// <param name="hbound">边界水深</param>
        public static void Bcimpheigh(double qfix, double hfix, int n1, int n2, double unorm_in, double utan_in, double hin, ref double unormbound, ref double utanbound, ref double hbound)
        {
            double unormfix;
            if (hfix < SVCSconst.HE_CA)
            {
                unormfix = 0;
                utanbound = 0;
            }
            else
            {
                unormfix = qfix / hfix;
            }

            if (Math.Abs(unorm_in) - Math.Sqrt(SVCSconst.GRAV * hin) <= 0)
            { // subcritical (fluvial) on the first cell inside the domain
                hbound = hfix;
                unormbound = unorm_in + (n1 + n2) * 2.0 * Math.Sqrt(SVCSconst.GRAV) * (Math.Sqrt(hin) - Math.Sqrt(hbound));
                // This value of unormbound is obtained thanks to the Riemann invariants
                // (see Annexe A O. Delestre Ph.D thesis, 2010)
                utanbound = 0.00;
                if (Math.Abs(unormbound) - Math.Sqrt(SVCSconst.GRAV * hbound) > 0.00)
                { // if the flow is supercritical on the fictive cell
                    if ((n1 + n2) * unorm_in <= 0.00)
                    {              // if we have inflow
                        unormbound = unormfix;              // we have to impose unorm too
                        utanbound = 0.00;
                    }
                    else
                    {                                   // if we have outflow
                        hbound = hin;                       // we do not impose any value
                        unormbound = unorm_in;
                        utanbound = utan_in;
                    }
                }
            }
            else
            { // supercritical (torrential)
                if ((n1 + n2) * unorm_in <= 0.00)
                {                 // if we have inflow
                    hbound = hfix;                          // we have to impose h
                    unormbound = unormfix;                  // and unorm,
                    utanbound = 0.00;
                }
                else
                {                                       // if we have outflow
                    hbound = hin;                           // we do not impose any value
                    unormbound = unorm_in;
                    utanbound = utan_in;
                }
            }
        }

        /// <summary>
        /// 流量边界
        /// </summary>
        /// <param name="qfix">流量</param>
        /// <param name="hfix">水位</param>
        /// <param name="n1">n1 integer to specify whether it is the left (-1) or the right (1) boundary </param>
        /// <param name="n2">n2 integer to specify whether it is the bottom (-1) or the top (1) boundary </param>
        /// <param name="unorm_in">内网格法向量速度</param>
        /// <param name="utan_in">内网格切向量速度</param>
        /// <param name="hin">内网个水深</param>
        /// <param name="unormbound">边界法向量速度</param>
        /// <param name="utanbound">边界切向量速度</param>
        /// <param name="hbound">边界水深</param>
        public static void Bcimpdischarge(double qfix, double hfix, int n1, int n2, double unorm_in, double utan_in, double hin, ref double unormbound, ref double utanbound, ref double hbound)
        {
            double h_init, h, unormfix;
            if (Math.Abs(unorm_in) - Math.Sqrt(SVCSconst.GRAV * hin) <= 0.0)
            { // sub critical (fluvial)
                h_init = 2.0 * Math.Pow(Math.Abs(qfix) / Math.Sqrt(SVCSconst.GRAV), 2.0 / 3.0) + 1.0;
                // we initialize the water height with h_init > h_critical = (|qfix|/sqrt(g))^2/3
                // in order to converge to the root we want
                h = Ntsolver(h_init, qfix, n1, n2, unorm_in, hin);
                if (h <= SVCSconst.HE_CA)
                {
                    unormbound = 0.0;
                    utanbound = 0.0;
                    hbound = 0.0;
                }// end if
                else
                {
                    unormbound = qfix / h;
                    utanbound = 0;
                    hbound = h;
                }// end else
            }
            else
            { // super critical (torrential)
                if (hfix < SVCSconst.HE_CA)
                {
                    unormfix = 0.0;
                    hfix = 0.0;
                }
                else
                {
                    unormfix = qfix / hfix;
                }
                hbound = hfix;
                unormbound = unormfix;
                utanbound = 0.0;
            }
        }

        /// <summary>
        /// 基于牛顿迭代，根据流量求解水位
        /// </summary>
        /// <param name="h_init">初始水位</param>
        /// <param name="qfix">定流量</param>
        /// <param name="n1">n1 integer to specify whether it is the left (-1) or the right (1) boundary</param>
        /// <param name="n2">n2 integer to specify whether it is the bottom (-1) or the top (1) boundary</param>
        /// <param name="unorm_in">法向量速度</param>
        /// <param name="hin">水位</param>
        /// <returns></returns>
        public static double Ntsolver(double h_init, double qfix, int n1, int n2, double unorm_in, double hin)
        {
            double norm, F, gradF, h, sigma;
            int iter = 0;
            // initialization
            h = h_init;
            F = Getpolynom(hin, unorm_in, qfix, h, n1, n2);
            norm = Math.Abs(F);
            while ((norm > SVCSconst.TOL) && (iter <= SVCSconst.Maxiter))
            {
                gradF = Getderivate(hin, unorm_in, h, n1, n2);
                sigma = -F / gradF;
                h += sigma;
                F = Getpolynom(hin, unorm_in, qfix, h, n1, n2);
                norm = Math.Abs(F);
                iter += 1;
            }
            return h;
        }

        /// <summary>
        /// 牛顿迭代公式
        /// </summary>
        /// <param name="hin"></param>
        /// <param name="unorm_in"></param>
        /// <param name="qfix"></param>
        /// <param name="H"></param>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns></returns>
        public static double Getpolynom(double hin, double unorm_in, double qfix, double H, int n1, int n2)
        {
            return 2 * Math.Sqrt(SVCSconst.GRAV * H) * H - (n1 + n2) * (unorm_in + (n1 + n2) * 2 * Math.Sqrt(SVCSconst.GRAV * hin)) * H - Math.Abs(qfix);
        }

        /// <summary>
        /// 牛顿迭代求导
        /// </summary>
        /// <param name="hin"></param>
        /// <param name="unorm_in"></param>
        /// <param name="H"></param>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns></returns>
        public static double Getderivate(double hin, double unorm_in, double H, int n1, int n2)
        {
            return 3 * Math.Sqrt(SVCSconst.GRAV * H) - (n1 + n2) * (unorm_in + (n1 + n2) * 2 * Math.Sqrt(SVCSconst.GRAV * hin));
        }

        /// <summary>
        /// 基于边界条件，确定边界网格高程值，边界类型1：固壁，2：通量，3：定水位，4：定流量
        /// </summary>
        /// <param name="NXCELL">i横方向网格数</param>
        /// <param name="NYCELL">j纵方向网格数</param>
        /// <param name="LBcscheme">左边界类型</param>
        /// <param name="RBcscheme">右边界类型</param>
        /// <param name="TBcscheme">上边界类型</param>
        /// <param name="BBcscheme">下边界类型</param>
        /// <param name="z">高程值</param>
        public static void boundzcal(int NXCELL, int NYCELL, int[] LBcscheme, int[] RBcscheme, int[] TBcscheme, int[] BBcscheme, double[][] z)
        {
            for (int j = 1; j < NYCELL + 1; j++)
            {
                switch (LBcscheme[j])
                {
                    case 1:
                        z[0][j] = z[1][j];
                        break;
                    case 2:
                        z[0][j] = z[1][j] - ((z[NXCELL][j] - z[1][j]) / (NXCELL - 1));
                        break;
                    case 3:
                        z[0][j] = 2 * z[1][j] - z[2][j];
                        break;
                    case 4:
                        z[0][j] = 2 * z[1][j] - z[2][j];
                        break;
                }
                switch (RBcscheme[j])
                {
                    case 1:
                        z[NXCELL + 1][j] = z[NXCELL][j];
                        break;
                    case 2:
                        z[NXCELL + 1][j] = z[NXCELL][j] + ((z[NXCELL][j] - z[1][j]) / (NXCELL - 1));
                        break;
                    case 3:
                        z[NXCELL + 1][j] = 2 * z[NXCELL][j] - z[NXCELL - 1][j];
                        break;
                    case 4:
                        z[NXCELL + 1][j] = 2 * z[NXCELL][j] - z[NXCELL - 1][j];
                        break;
                }
            }

            for (int i = 1; i < NXCELL + 1; i++)
            {
                switch (BBcscheme[i])
                {
                    case 1:
                        z[i][NYCELL + 1] = z[i][NYCELL];
                        break;
                    case 2:
                        z[i][NYCELL + 1] = z[i][NYCELL] + ((z[i][NYCELL] - z[i][1]) / (NYCELL - 1));
                        break;
                    case 3:
                        z[i][NYCELL + 1] = 2 * z[i][NYCELL] - z[i][NYCELL - 1];
                        break;
                    case 4:
                        z[i][NYCELL + 1] = 2 * z[i][NYCELL] - z[i][NYCELL - 1];
                        break;
                }
                switch (TBcscheme[i])
                {
                    case 1:
                        z[i][0] = z[i][1];
                        break;
                    case 2:
                        z[i][0] = z[i][1] - ((z[i][NYCELL] - z[i][1]) / (NYCELL - 1));
                        break;
                    case 3:
                        z[i][0] = 2 * z[i][1] - z[i][2];
                        break;
                    case 4:
                        z[i][0] = 2 * z[i][1] - z[i][2];
                        break;
                }

            }
        }
    }
}
