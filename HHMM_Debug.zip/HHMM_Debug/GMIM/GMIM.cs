﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//模块用于开展垂向土壤入渗，基于一维化的三维网格，需要判断网格的上下逻辑，进而开展基于Green-Ampt的垂向入渗。
namespace HHMM
{
    public class GMIM
    {
        /// <summary>
        /// 运行土壤入渗模块
        /// </summary>
        /// <param name="HHvar"></param>
        /// <param name="SVvar"></param>
        /// <param name="TVvar"></param>
        /// <param name="GMvar"></param>
        public static void GMIMrun(HHMMvar HHvar, SVCSvar SVvar, SWHSvar TVvar, GMIMvar GMvar)
        {
            double PSATK = 0.90;

            for (int i = 0; i < HHvar.NXCELL; i++)
            {
                for (int j = 0; j < HHvar.NYCELL; j++)
                {
                    double Cellinfill = 0.0;
                    double bottomflow = 0.0;


                    if ((HHvar.upfaceid[i][j] >= 0) & (SVvar.h[i + 1][j + 1] > SVCSconst.HE_CA))
                    {
                        CellGMinf(i, j, PSATK, HHvar, SVvar, TVvar, out Cellinfill, out bottomflow);

                        GMvar.surfaceinfil[i][j] += Cellinfill;//入渗量
                        GMvar.bottomflow[i][j] += bottomflow;//渗漏量
                    }
                }
            }
            //SVCSout.WaEnbalance(SVvar, GMvar, HHvar);

        }
        /// <summary>
        /// 单个平面网格的分层垂向入渗计算
        /// </summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <param name="PSATK"></param>
        /// <param name="HHvar"></param>
        /// <param name="SVvar"></param>
        /// <param name="TVvar"></param>
        /// <param name="Cellinfill"></param>
        /// <param name="botflow"></param>
        public static void CellGMinf(int i, int j, double PSATK, HHMMvar HHvar, SVCSvar SVvar, SWHSvar TVvar, out double Cellinfill, out double botflow)
        {
            int layernum = HHvar.downfaceid[i][j] - HHvar.upfaceid[i][j] + 1;//土壤层数
            int li = 0;
            double[] K = new double[layernum];
            double[] PSAT = new double[layernum];
            double INFMAX = 0.0;
            double ZSTAR = 0.0;//无量纲z*
            double DTSTAR = 0.0;//无量纲t*
            double SATINF = 0.0;
            double SUMZ = 0.0;//层深度z，sum z
            double SUMZK = 0.0;//sum z/k
            double DTIME = SVvar.dt1;//每层的入渗时间
            double POTINF = 0.0;//无量纲F*
            double TIME = 0;
            double DIMINF = 0;
            double Verinfill = 0.0;
            double Wh = SVvar.h[i + 1][j + 1];
            int coni, ct;
            botflow = 0.0;
            coni = HHvar.conupfaceid[i][j];//连续网格的层数
            if (layernum <= 0)
            {
                Verinfill = 0;
                goto Infilend; //裸岩不渗透
            }
            for (int lli = 0; lli < layernum; lli++)
            {
                PSAT[lli] = PSATK;
                K[lli] = TVvar.waterphas.K[coni + lli];//导水率
            }

            K[layernum - 1] = 0.0;//深层渗漏过程放入三维土壤水分运动中
            li = 0; //逐层入渗 
            ct = HHvar.cellsoiltype[coni];  //那一类型的土壤  

            if (K[li] <= 0)
            {
                Verinfill = 0;
                goto Infilend; //如果表层渗透为零，则不能渗透
            }
            INFMAX = (PSAT[li] * HHvar.soilwaterpara.soilwas[ct] - TVvar.waterphas.VLC[coni] - TVvar.icephas.VIC[coni]) * TVvar.Cellz;  //判断表层蓄水能力，如果饱和，则进入下一层。该层蓄水的最大入渗量
            if (INFMAX <= 0.0)
            {
                goto Parupdate;
            }
        Infilcal:       //计算层入渗
            if (ZSTAR <= 1.0) //湿锋后的饱和流假设是有效的
            {
                DTSTAR = K[li] * DTIME / (PSAT[li] * HHvar.soilwaterpara.soilwas[ct] - TVvar.waterphas.VLC[coni] - TVvar.icephas.VIC[coni]) / (-1 * TVvar.waterphas.MAT[coni] + SUMZ);//无量纲t*=(𝐾_𝑛 𝑡′)/(∆𝜃 (𝐻_𝑛+∑▒𝑧_𝑖 ))
                POTINF = (DTSTAR - 2 * ZSTAR + Math.Sqrt((DTSTAR - 2 * ZSTAR) * (DTSTAR - 2 * ZSTAR) + 8 * DTSTAR)) / 2;//无量纲F*=𝐹′/(∆𝜃 (𝐻_𝑛+∑▒𝑧_𝑖 ))
                POTINF = POTINF * Math.Max(0.01, (PSAT[li] * HHvar.soilwaterpara.soilwas[ct] - TVvar.waterphas.VLC[coni] - TVvar.icephas.VIC[coni])) * (-1 * TVvar.waterphas.MAT[coni] + SUMZ);//转换成层的累计入渗量，即在li层的入渗量
            }
            else //入渗流变得不饱和--通过饱和介质
            {
                POTINF = SATINF * DTIME;//饱和入渗率*每层入渗时间=该层入渗量
            }

            if (INFMAX >= (Wh - Verinfill)) //入渗（蓄水）能力>=降雨-下渗,层可以容纳剩余的水--检查是否所有水都可以下渗
            {
                if (POTINF >= (Wh - Verinfill))
                {
                    POTINF = Wh - Verinfill;//当前层可以渗入剩余的雨水
                    Verinfill += POTINF;
                }
                else
                {
                    Verinfill = Verinfill + POTINF; //不能渗入所有的雨水
                }
                goto Infilend;
            }

            if (POTINF < INFMAX)//层不能容纳剩余的雨水 
            {
                Verinfill = Verinfill + POTINF;
                goto Infilend;
            }
            //蓄水能力小于降雨-下渗，计算的累计入渗量（表征渗透能力）大于蓄水能力(实际上，累计入渗量最多等于蓄水能力，以下调整)
            if (ZSTAR <= 1.0) //渗透能力和降雨足以填充层--计算填充层所需的时间并调整时间
            {
                DIMINF = INFMAX / (PSAT[li] * HHvar.soilwaterpara.soilwas[ct] - TVvar.waterphas.VLC[coni] - TVvar.icephas.VIC[coni]) / (-1 * TVvar.waterphas.MAT[coni] + SUMZ);
                if (DIMINF > 0.01)
                {
                    DTSTAR = (ZSTAR - 1) * Math.Log(1.0 + DIMINF) + DIMINF;
                }
                else
                {
                    // 如果diminf很小，使用另一种计算log的方法，因为在数字非常接近1.0时，可能会发生严重的错误，即（1 + 10 ^ -5）
                    DTSTAR = (ZSTAR - 1) * 2 * DIMINF / (2 + DIMINF) + DIMINF;
                }
                TIME = DTSTAR * (PSAT[li] * HHvar.soilwaterpara.soilwas[ct] - TVvar.waterphas.VLC[coni] - TVvar.icephas.VIC[coni]) * (-1 * TVvar.waterphas.MAT[coni] + SUMZ) / K[li];//转换成时间
            }
            else
            {
                TIME = INFMAX / SATINF;//渗透流已变得不饱和——通过饱和介质的使用流  
            }
            DTIME = DTIME - TIME;
            Verinfill = Verinfill + INFMAX;
            if (DTIME <= 0.0)
            {
                goto Infilend; //渗透计算完成——计算积水
            }

        Parupdate:

            //新加代码适应一层土壤
            if (li >= layernum - 1)
            {
                goto Infilend;
            }


            li = li + 1;   //下一层入渗
            if (K[li] <= 0)
            {
                goto Infilend;
            }
            SUMZ = li * TVvar.Cellz;
            SUMZK += TVvar.Cellz / K[li - 1];
            coni++;
            ct = HHvar.cellsoiltype[coni];
            if (li < layernum - 1)//没到最底层
            {
                if (ZSTAR <= 1.0)
                {
                    //饱和流仍然存在——为下一层设置zstar
                    ZSTAR = K[li] * SUMZK / (-1 * TVvar.waterphas.MAT[coni] + SUMZ);
                    PSAT[li] = PSATK;
                    if (ZSTAR > 1.0)
                    {
                        //该层的导水率足够高，以至于不再存在饱和条件—-假设重力流，利用当前层后的饱和关系计算渗透
                        SATINF = Math.Max(0.00000001, (-TVvar.waterphas.MAT[coni] + SUMZ) / SUMZK);
                        //计算用于插值的最大水含量的PSATK（当前设置为0.90）处所有层的导水率
                        //确定层的含水量，以使导水率与流入层的流量相匹配 - 使用VLC已知点和导水率之间的对数插值
                        PSAT[li] = Math.Pow(10.0, (Math.Log10(PSATK) * Math.Log10(SATINF / K[li]) / Math.Log10(HHvar.soilwaterpara.Ks9[ct] / K[li])));
                        PSAT[li] = Math.Min(PSAT[li], PSATK);
                        //定义当前层的最大饱和导水率
                        K[li] = SUMZ / SUMZK;
                    }
                }
                else
                {
                    //湿锋处不再存在饱和条件
                    //COMPARE FLUX TO SATURATED CONDUCTIVITY OF CURRENT LAYER
                    //比较FLUX和当前层的饱和导水率
                    SATINF = Math.Max(0.00000001, (-TVvar.waterphas.MAT[coni] + SUMZ) / SUMZK);
                    if (K[li] < SATINF)
                    {
                        SATINF = K[li];
                    }
                    //确定层的含水量，以使导水率与流入层的流量相匹配 - 使用VLC已知点和导水率之间的对数插值
                    PSAT[li] = Math.Pow(10.0, (Math.Log10(PSATK) * Math.Log10(SATINF / K[li]) / Math.Log10(PSATK * HHvar.soilwaterpara.Ks9[ct] / K[li])));
                    PSAT[li] = Math.Min(PSAT[li], PSATK);
                    //DEFINE MAXIMUM SATURATED CONDUCTIVITY FOR CURRENT LAYER
                    //定义当前层的最大饱和导水率
                    K[li] = SUMZ / SUMZK;
                }
                INFMAX = (PSAT[li] * HHvar.soilwaterpara.soilwas[ct] - TVvar.waterphas.VLC[coni] - TVvar.icephas.VIC[coni]) * TVvar.Cellz;//计算该层的最大入渗量                
                if (INFMAX <= 0.0)//如果层不能容纳额外的水，则转到下一层。
                {
                    goto Parupdate;
                }
                goto Infilcal;
            }
            else
            {
                if (ZSTAR <= 1.0)//渗透到达剖面底部
                {
                    //COMPUTE FLOW THROUGH SATURATED PROFILE
                    //计算通过饱和剖面的流量
                    Verinfill = Verinfill + DTIME * SUMZ / SUMZK;
                }
                else
                {
                    //比较通量和当前层饱和导水率
                    if (K[li] < SATINF)
                    {
                        SATINF = K[li];
                    }
                    Verinfill = Verinfill + DTIME * SATINF;
                }

                if (Verinfill > Wh)
                {
                    Verinfill = Wh;
                }
            }

        Infilend://渗透计算完成——计算积水

            Wh = Wh - Verinfill;   //剩余水深(m)            
            Cellinfill = Verinfill; //累积入渗(m)           
            SVvar.h[i + 1][j + 1] = Wh;  //后面考虑不要 

            coni = HHvar.conupfaceid[i][j];//三维网格在一维中的排序
            for (li = 0; li < layernum; li++)
            {
                if (Verinfill <= 0)
                {
                    break;
                }
                else
                {
                    ct = HHvar.cellsoiltype[coni];//土壤类型编号

                    double Layinfmax = Math.Max(0.0, (PSATK * HHvar.soilwaterpara.soilwas[ct] - TVvar.waterphas.VLC[coni] - TVvar.icephas.VIC[coni])) * TVvar.Cellz;
                    if (Verinfill <= Layinfmax)
                    {
                        Layinfmax = Verinfill;
                    }
                    //double SoilWaterold = TVvar.waterphas.VLC[coni];
                    TVvar.waterphas.VLC[coni] += Layinfmax / TVvar.Cellz;
                    //double SoilWaternew = TVvar.waterphas.VLC[coni];
                    /*double Soluteall;
                    
                    //TVvar.waterphas.VLC[coni] += Layinfmax / TVvar.Cellz;
                    for (int solui = 0; solui < HHvar.solutenum; solui++)
                    {
                          double deltainfil;//入渗的同位素浓度
                          if ( li==0)//每层入渗浓度的调整
                          {
                              deltainfil=deltain;
                          }
                          else
                          {
                          deltainfil=TVvar.solutephas.soilsolunew[solui][coni-1];
                          }
                        double Soilsoluteold = TVvar.solutephas.soilsolunew[solui][coni];
                        //Soluteall = SoilWaterold * Soilsoluteold + deltain * Verinfill / TVvar.Cellz;
                        Soluteall = SoilWaterold * Soilsoluteold + deltainfil * Cellinfill / TVvar.Cellz;//土壤原来溶质含量+累积渗入的溶质含量
                     //Soluteall = (SoilWaterold + HHvar.soilheatpara.minedensity[ct] * HHvar.soilsolutepara.kcq[ct][solui] / SWHSconst.RHOL) * TVvar.solutephas.soilsolunew[solui][coni] + deltain * SoilWaternew;//其中吸附比设置为0
                     // TVvar.solutephas.soilsolunew[solui][coni] = Soluteall / SoilWaternew;
                        TVvar.solutephas.soilsolunew[solui][coni] = Soluteall / (SoilWaterold+ Cellinfill / TVvar.Cellz);
                          //TVvar.solutephas.soilsolunew[solui][coni] = Soluteall / (SoilWaternew + HHvar.soilheatpara.minedensity[ct] * HHvar.soilsolutepara.kcq[ct][solui] / SWHSconst.RHOL);//包括吸附的溶质
                    }*/

                    SWHSWater.Cellgq2k(HHvar.soilwaterpara.soilwas[ct], HHvar.soilwaterpara.soilwar[ct], HHvar.soilwaterpara.Ks[ct], HHvar.soilwaterpara.l[ct], HHvar.soilwaterpara.m[ct], TVvar.waterphas.VLC[coni], TVvar.icephas.VIC[coni], out TVvar.waterphas.K[coni]);//求解土壤不饱和导水率K
                    if (Layinfmax != 0.0)
                    {
                        SWHSWater.Cellgq2y(HHvar.soilwaterpara.soilwas[ct], HHvar.soilwaterpara.soilwar[ct], HHvar.soilwaterpara.avg[ct], HHvar.soilwaterpara.m[ct], HHvar.soilwaterpara.n[ct], TVvar.waterphas.VLC[coni], TVvar.icephas.VIC[coni], out TVvar.waterphas.MAT[coni]);//求解水势
                    }

                    coni++;
                    Verinfill -= Layinfmax;
                }
            }
            botflow = Verinfill;
        }


    }
}
