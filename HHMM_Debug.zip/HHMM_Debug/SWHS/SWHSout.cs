﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHMM
{
    public class SWHSout
    {
        /// <summary>
        /// 统计SWHS涉及的变量
        /// </summary>
        /// <param name="TVvar"></param>
        /// <param name="HHvar"></param>
        public static void WaEnbalance(SWHSvar TVvar, HHMMvar HHvar)
        {
            TVvar.Totalsoilwatervolume = 0.0;
            TVvar.Totalrockwatervolume = 0.0;
            TVvar.Totalsoilice = 0.0;
            TVvar.Totalsnow = 0.0;
            TVvar.TotalDLW = 0.0;
            for (int soli = 0; soli < HHvar.solutenum; soli++)
            {
                TVvar.Totalsoilsolute[soli] = 0.0;
            }
            for (int ic = HHvar.startcell; ic < HHvar.endcell; ic++)
            {
                int ct0 = HHvar.cellsoiltype[ic];//不同土壤类型编号
                if (ct0 < HHvar.rocknum - 1)
                {
                    TVvar.Totalsoilwatervolume += TVvar.waterphas.VLC[ic] * TVvar.Cellx * TVvar.Celly * TVvar.Cellz;//土壤水体积=含水率*网格体积
                }
                else
                {
                    TVvar.Totalrockwatervolume += TVvar.waterphas.VLC[ic] * TVvar.Cellx * TVvar.Celly * TVvar.Cellz;//土壤水体积=含水率*网格体积
                }

                TVvar.Totalsoilice += TVvar.icephas.VIC[ic] * SWHSconst.RHOI / SWHSconst.RHOL * TVvar.Cellx * TVvar.Celly * TVvar.Cellz;
                for (int soli = 0; soli < HHvar.solutenum; soli++)
                {
                    TVvar.Totalsoilsolute[soli] += (TVvar.waterphas.VLC[ic] * SWHSconst.RHOL + HHvar.soilheatpara.minedensity[ct0] * HHvar.soilsolutepara.kcq[soli][ct0]) * TVvar.solutephas.soilsolunew[soli][ic] * TVvar.Cellx * TVvar.Celly * TVvar.Cellz;//网格总溶质含量（mol)+=溶质体积*溶质浓度=含水率*水密度*网格体积*溶质浓度
                }
            }

            for (int i = HHvar.startcol; i < HHvar.endcol; i++)
            {
                for (int j = 0; j < HHvar.NYCELL; j++)
                {
                    if (HHvar.upfaceid[i][j] >= 0)
                    {
                        if (TVvar.SNMatrix.NSP[i][j] > 0)
                        {
                            for (int l = 0; l < TVvar.SNMatrix.NSP[i][j]; l++)
                            {
                                TVvar.Totalsnow += TVvar.SNMatrix.DZSP[i][j][l] * TVvar.Cellx * TVvar.Celly * TVvar.SNMatrix.RHOSP[i][j][l] / SWHSconst.RHOL;//雪水当量
                                TVvar.TotalDLW += TVvar.SNMatrix.DLWDT[i][j][l] * TVvar.Cellx * TVvar.Celly;//雪层中的液态水//可能需要修改

                            }
                        }

                    }
                }

            }
        }

    }
}
