﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HHMM
{
    public class SWHSSurfcal
    {
        public static double VAP, VAPDT;
        public static double TA, TADT, AVGTA;
        public static double HUM, HUMDT;
        public static double WindDT;
        public static double TRAIN;
        public static double PRESUR;
        public static double Ustar, Stable;

        public static void WeatherHour(int di, int hi, HHMMvar HHvar, SWHSvar TVvar)//
        {
            SWHSSurfcal.Weadatahour(HHvar.NXCELL, HHvar.NYCELL, di, hi, HHvar.regionpara.Latitude, HHvar.regionpara.Elevation, HHvar.regionpara.Hrnoon, HHvar.regionpara.ZMCM, HHvar.regionpara.ZMSPCM, HHvar.regionpara.Insheight, HHvar.regionpara.Vegheight, HHvar.weadata[hi].radi, HHvar.weadata[hi].temper, HHvar.weadata[hi].hum, HHvar.weadata[hi].wind, HHvar.upfaceid, TVvar.SNMatrix.NSP, TVvar.SNMatrix.ZSP, ref HHvar.regionpara.Altitu, ref TVvar.raddata.ABOVE, ref TVvar.raddata.Direct, ref TVvar.raddata.Diffuse, ref TVvar.WaEndata.ZM, ref TVvar.WaEndata.ZH, ref TVvar.WaEndata.ZERO);//太阳高度角，大气长波辐射，直接辐射，散射辐射，随动量分布的表面粗糙参数，随温度分布的表面粗糙参数，零平面位移
            SWHSSnow.TRAINFUN(TA, TADT, HUM, HUMDT, PRESUR, ref AVGTA, ref TRAIN);  //时刻前后平均温度，湿球温度
            HHvar.regionpara.RAIN = HHvar.weadata[hi].rain; //降雨单位：m/h
            HHvar.regionpara.Precipitation = HHvar.weadata[hi].rain; //降雨单位：m/h
            if (HHvar.SPM > 0) SWHSSnow.PRECP(HHMMconst.SecondPerHour, AVGTA, TRAIN, ref HHvar.regionpara.RAIN, HHvar.regionpara.SNOTMP, TVvar, HHvar);//对降水进行雨雪分离，并计算融雪量
            HHvar.regionpara.RAIN /= HHMMconst.SecondPerHour;  //积雪融雪算完之后，将单位改变，
        }

        /// <summary>
        /// 计算能量参数和气象参数
        /// </summary>
        /// <param name="NXCELL"></param>
        /// <param name="NYCELL"></param>
        /// <param name="di"></param>
        /// <param name="hi"></param>
        /// <param name="Latitude"></param>
        /// <param name="ELEV"></param>
        /// <param name="Hrnoon"></param>
        /// <param name="ZMCM"></param>
        /// <param name="ZMSPCM"></param>
        /// <param name="HEIGHT"></param>
        /// <param name="Vegheight"></param>
        /// <param name="Radihour"></param>
        /// <param name="Tahour"></param>
        /// <param name="Humhour"></param>
        /// <param name="Windhour"></param>
        /// <param name="upfaceid"></param>
        /// <param name="NSP"></param>
        /// <param name="ZSP"></param>
        /// <param name="Altitu"></param>
        /// <param name="Above"></param>
        /// <param name="Direct"></param>
        /// <param name="Diffuse"></param>
        /// <param name="ZM"></param>
        /// <param name="ZH"></param>
        /// <param name="ZERO"></param>
        public static void Weadatahour(int NXCELL, int NYCELL, int di, int hi, double Latitude, double ELEV, double Hrnoon, double ZMCM, double ZMSPCM, double HEIGHT, double Vegheight, double Radihour, double Tahour, double Humhour, double Windhour, int[][] upfaceid, int[][] NSP, double[][][] ZSP, ref double Altitu, ref double Above, ref double[][] Direct, ref double[][] Diffuse, ref double[][] ZM, ref double[][] ZH, ref double[][] ZERO)
        {

            SWHSRad.Solar(hi, Latitude, Hrnoon, Radihour, ref Direct, ref Diffuse, ref Altitu);//计算当前时刻的直接辐射、散射辐射和太阳高度角
            if ((di == 0) & (hi == 0))
            {
                PRESUR = SWHSconst.P0 * Math.Exp(-ELEV / 8278.0);//大气压强
                TA = Tahour;
                TADT = Tahour;
            }
            else
            {
                TADT = Tahour;
            }

            SWHSTools.SYSTEM(NXCELL, NYCELL, NSP, ZMCM, ZMSPCM, HEIGHT, Vegheight, upfaceid, ZSP, ref ZM, ref ZH, ref ZERO);

            //计算当前时刻的大气长波辐射，考虑当前时刻两端的大气温度
            Above = SWHSRad.LWRATM(SWHSconst.WT, TA, TADT);
            TA = TADT;

            HUM = Humhour;
            HUMDT = Humhour;
            WindDT = Windhour;
        }

        public static void WESurfcal(int di, int hi, int ITER, double Timestep, SWHSvar TVvar, HHMMvar HHvar)
        {
            double B1 = 0.0, B2 = 0.0, D1 = 0.0, D2 = 0.0;
            double Es = 0.0;//W/m^2
            double Tr = 0.0;//W/m^2
            //soile = 0.0;

            for (int i = 0; i < HHvar.NXCELL; i++)
            {
                for (int j = 0; j < HHvar.NYCELL; j++)
                {
                    if (HHvar.upfaceid[i][j] >= 0)
                    {
                        double SATV, SATVDT, S;
                        int coni = HHvar.conupfaceid[i][j];//连续网格的层数
                        int st = HHvar.cellsoiltype[coni];  //网格对应的土壤类型
                        int layernum = HHvar.downfaceid[i][j] - HHvar.upfaceid[i][j] + 1;//地下层数

                        //计算地表有效网格的短波辐射 
                        SWHSRad.SWRBAL(TVvar.SNMatrix.NSP[i][j], TVvar.waterphas.VLCDT[coni], HHvar.soilheatpara.ALBDRY[st], HHvar.soilheatpara.ALBEXP[st], TVvar.SNMatrix.DZSP[i][j], TVvar.SNMatrix.ZSP[i][j], TVvar.SNMatrix.RHOSP[i][j], TVvar.raddata.Direct[i][j], TVvar.raddata.Diffuse[i][j], ref TVvar.SNMatrix.SWSNOW[i][j], ref TVvar.raddata.SWSOIL[i][j]);//直接辐射，散射辐射，雪接受的短波辐射，土壤地表接受的短波辐射
                        SWHSRad.LWRBAL(TVvar.SNMatrix.NSP[i][j], ref TVvar.raddata.ABOVE, TVvar.heatphas.TS[coni], TVvar.heatphas.TSDT[coni], TVvar.SNMatrix.TSP[i][j], TVvar.SNMatrix.TSPDT[i][j], ref TVvar.SNMatrix.LWSNOW[i][j], ref TVvar.raddata.LWSOIL[i][j]);//大气长波辐射，雪接受的长波辐射，土壤接受的长波辐射
                        SWHSRad.LWRMAT(TVvar.SNMatrix.NSP[i][j], TVvar.SNMatrix.ICESPT[i][j], TVvar.SNMatrix.TSP[i][j], TVvar.heatphas.TS[coni], ref TVvar.SNMatrix.A1[i][j], ref TVvar.SNMatrix.B1[i][j], ref TVvar.SNMatrix.C1[i][j], ref TVvar.SNMatrix.D1[i][j], out TVvar.mumpsSWHS.EMatrixadd[coni]);//长波辐射的能量平衡矩阵贡献

                        SWHSRad.SOURCE(TVvar.SNMatrix.NSP[i][j], TVvar.SNMatrix.SWSNOW[i][j], TVvar.SNMatrix.LWSNOW[i][j], TVvar.raddata.SWSOIL[i][j], TVvar.raddata.LWSOIL[i][j], ref TVvar.SNMatrix.SSP[i][j], ref TVvar.mumpsSWHS.EnergBaadd[coni]);//能量平衡公式中Source项的计算

                        if (TVvar.SNMatrix.NSP[i][j] > 0)
                        {
                            SWHSTools.VSLOPE(TVvar.SNMatrix.TSP[i][j][0], out SATV, out S);//计算日饱和蒸气压和温度梯度
                            SWHSTools.VSLOPE(TVvar.SNMatrix.TSPDT[i][j][0], out SATVDT, out S);//计算日饱和蒸气压和温度梯度
                            double TMP = TVvar.SNMatrix.TSP[i][j][0] + SWHSconst.Tk0;
                            double TMPDT = TVvar.SNMatrix.TSPDT[i][j][0] + SWHSconst.Tk0;
                            VAP = SATV * Math.Exp(0.018 / (SWHSconst.UGAS * (TMP) * TMP / (SWHSconst.LF * TVvar.SNMatrix.TSP[i][j][0])));//参考高度水汽密度
                            VAPDT = SATVDT * Math.Exp(0.018 / (SWHSconst.UGAS * (TMPDT) * TMPDT / (SWHSconst.LF * TVvar.SNMatrix.TSP[i][j][0])));
                            //  VAP = SATV*Math.Exp(0.018/(SWHSconst.UGAS*(TMP)*SWHSconst.LF*TVvar.SNMatrix.TSP[i][j][0]/TMP));//?参考高度水汽密度
                            //VAPDT = SATVDT * Math.Exp(0.018 / (SWHSconst.UGAS * (TMPDT) * SWHSconst.LF * TVvar.SNMatrix.TSP[i][j][0] / TMPDT));
                            SWHSAtstab.ATSTAB(ITER, HHvar.regionpara.Insheight, TVvar.WaEndata.ZH[i][j], TVvar.WaEndata.ZM[i][j], TVvar.WaEndata.ZERO[i][j], TVvar.SNMatrix.NSP[i][j], TA, TADT, HUM, HUMDT, VAP, VAPDT, WindDT, PRESUR, TVvar.SNMatrix.ICESPT[i][j][0], TVvar.SNMatrix.TSP[i][j][0], TVvar.SNMatrix.TSPDT[i][j][0], TVvar.waterphas.MAT[coni], TVvar.waterphas.MATDT[coni], TVvar.waterphas.VLCDT[coni], TVvar.icephas.VICDT[coni], Timestep, TVvar.Cellz, HHvar.soilwaterpara.soilwar[st], HHvar.soilwaterpara.soilwas[st], ref TVvar.WaEndata.HFLUX[i][j], ref TVvar.WaEndata.VFLUX[i][j], ref B1, ref B2, ref D1, ref D2, ref Ustar, ref Stable);//计算感热和潜热，并计算对计算方程的贡献


                        }

                        double TOTPOT = TVvar.waterphas.MAT[coni];
                        double TOTPDT = TVvar.waterphas.MATDT[coni];
                        SWHSTools.VSLOPE(TVvar.heatphas.TS[coni], out SATV, out S); //计算日饱和蒸气压和温度梯度
                        SWHSTools.VSLOPE(TVvar.heatphas.TSDT[coni], out SATVDT, out S);//计算日饱和蒸气压和温度梯度


                        VAP = SATV * Math.Exp(SWHSconst.Mw * SWHSconst.G / (SWHSconst.UGAS * (TVvar.heatphas.TS[coni] + SWHSconst.Tk0)) * TOTPOT / 100);//TOTPOT
                        VAPDT = SATVDT * Math.Exp(SWHSconst.Mw * SWHSconst.G / (SWHSconst.UGAS * (TVvar.heatphas.TSDT[coni] + SWHSconst.Tk0)) * TOTPDT / 100);//TOTPDT
                        if (TVvar.SNMatrix.NSP[i][j] <= 0)
                        {

                            SWHSAtstab.ATSTAB(ITER, HHvar.regionpara.Insheight, TVvar.WaEndata.ZH[i][j], TVvar.WaEndata.ZM[i][j], TVvar.WaEndata.ZERO[i][j], TVvar.SNMatrix.NSP[i][j], TA, TADT, HUM, HUMDT, VAP, VAPDT, WindDT, PRESUR, TVvar.icephas.ICESDT[coni], TVvar.heatphas.TS[coni], TVvar.heatphas.TSDT[coni], TVvar.waterphas.MAT[coni], TVvar.waterphas.MATDT[coni], TVvar.waterphas.VLCDT[coni], TVvar.icephas.VICDT[coni], Timestep, TVvar.Cellz, HHvar.soilwaterpara.soilwar[st], HHvar.soilwaterpara.soilwas[st], ref TVvar.WaEndata.HFLUX[i][j], ref TVvar.WaEndata.VFLUX[i][j], ref B1, ref B2, ref D1, ref D2, ref Ustar, ref Stable);//计算感热和潜热，并计算对计算方程的贡献
                            TVvar.mumpsSWHS.EMatrixadd[coni] += B1;
                            TVvar.mumpsSWHS.EnergBaadd[coni] += D1;//W/m^2
                            TVvar.mumpsSWHS.WMatrixadd[coni] = B2;
                            TVvar.mumpsSWHS.WaterBaadd[coni] = D2; //m / s

                            //double Rn_avg = TVvar.raddata.SWSOIL[i][j] + TVvar.raddata.LWSOIL[i][j];
                            //double Rs_inc_avg = TVvar.raddata.Direct[i][j] + TVvar.raddata.Diffuse[i][j];
                            //double theta_2 = 0.0;
                            //double Gs_avg = 0.0;
                            //double ustar = 0.0;
                            //SWHSSiLSM.SWinput(TVvar.Cellz, coni, layernum, HHvar.rocknum, HHvar.cellsoiltype, TVvar.waterphas.VLCDT, TVvar.heatphas.TSDT, TVvar.heatphas.Kssoil, TVvar.WaEndata.ZM[i][j], TVvar.WaEndata.ZERO[i][j], HHvar.regionpara.Insheight, WindDT, Rn_avg, ref theta_2, ref Gs_avg, ref ustar);

                            //SWHSSiLSM.SiLSM(coni, layernum, HHvar.rocknum, HHvar.cellsoiltype, HHvar.weadata[hi].lai, TADT, HUMDT, Gs_avg, Rn_avg, ustar, HHvar.regionpara.Vegheight, SWHSconst.CO2, Rs_inc_avg, PRESUR * 1000, WindDT, TVvar.waterphas.VLCDT[coni], theta_2, ref TVvar.WaEndata.HFLUX[i][j], ref TVvar.WaEndata.VFLUX[i][j], ref TVvar.mumpsSWHS.EnergBaadd, ref TVvar.mumpsSWHS.WaterBaadd, ref Es, ref Tr);//?s-w模型
                        }

                        if (TVvar.SNMatrix.NSP[i][j] > 0)
                        {
                            double VAPSP = VAP;
                            double VAPSPT = VAPDT;
                            TVvar.SNMatrix.TSP[i][j][TVvar.SNMatrix.NSP[i][j]] = TVvar.heatphas.TS[0];
                            TVvar.SNMatrix.TSPDT[i][j][TVvar.SNMatrix.NSP[i][j]] = TVvar.heatphas.TSDT[0];
                            SWHSSnow.EBSNOW(B1, D1, ITER, 0, TVvar.SNMatrix.NSP[i][j], 0, Timestep, PRESUR, VAPSPT, VAPSPT, TVvar.SNMatrix.SSP[i][j], TVvar.SNMatrix.ZSP[i][j], TVvar.SNMatrix.DZSP[i][j], TVvar.SNMatrix.TSP[i][j], TVvar.SNMatrix.TSPDT[i][j], TVvar.SNMatrix.DLW[i][j], TVvar.SNMatrix.DLWDT[i][j], TVvar.SNMatrix.ICESPT[i][j], TVvar.SNMatrix.RHOSP[i][j], TVvar.waterphas.VLCDT[coni], TVvar.icephas.VICDT[coni], HHvar.soilwaterpara.soilwar[st], HHvar.soilwaterpara.soilwas[st], Timestep, TVvar.Cellz, out TVvar.SNMatrix.QVSP[i][j], ref TVvar.SNMatrix.A1[i][j], ref TVvar.SNMatrix.B1[i][j], ref TVvar.SNMatrix.C1[i][j], ref TVvar.SNMatrix.D1[i][j]); //计算能量平衡Newton - Raphson的雪部分的雅可比矩阵系数
                            SWHSSnow.SNOWBC(TVvar.SNMatrix.NSP[i][j], PRESUR, TVvar.SNMatrix.TSPDT[i][j][TVvar.SNMatrix.NSP[i][j] - 1], TVvar.SNMatrix.ZSP[i][j], TVvar.SNMatrix.ICESPT[i][j][TVvar.SNMatrix.NSP[i][j] - 1], VAPSPT, TVvar.SNMatrix.QVSP[i][j][TVvar.SNMatrix.NSP[i][j] - 1], TVvar.heatphas.TSDT[coni], ref B2, ref D2);//建立了有积雪时土壤系统水量平衡的上边界条件
                            TVvar.mumpsSWHS.WMatrixadd[coni] = B2;
                            TVvar.mumpsSWHS.WaterBaadd[coni] = D2;//m / s
                            TVvar.mumpsSWHS.EnergBaadd[coni] += TVvar.SNMatrix.D1[i][j][TVvar.SNMatrix.NSP[i][j]];

                        }
                        //TVvar.waterphas.OUTEDT[coni] = Es / (SWHSconst.LV * SWHSconst.RHOL) * Timestep * TVvar.Cellx * TVvar.Celly;//m3
                        //TVvar.waterphas.OUTTDT[coni] = Tr / (SWHSconst.LV * SWHSconst.RHOL) * Timestep * TVvar.Cellx * TVvar.Celly;//m3
                        TVvar.waterphas.OUTEDT[coni] = -TVvar.WaEndata.VFLUX[i][j] / SWHSconst.RHOL * Timestep * TVvar.Cellx * TVvar.Celly;//m3
                                                                                                                                           // TVvar.waterphas.OUTEDT[coni] = -D2 / SWHSconst.RHOL * Timestep * TVvar.Cellx * TVvar.Celly;//m3

                    }
                }
            }
        }
    }
}
