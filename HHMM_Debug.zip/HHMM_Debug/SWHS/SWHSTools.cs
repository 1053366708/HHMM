﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HHMM
{
    public class SWHSTools
    {
        /// <summary>
        /// 基于消元方法求解稀疏矩阵
        /// </summary>
        /// <param name="N"></param>
        /// <param name="A"></param>
        /// <param name="B"></param>
        /// <param name="C"></param>
        /// <param name="D"></param>
        /// <param name="X"></param>
        public static void TDMA(int N, double[] A, double[] B, double[] C, double[] D, out double[] X)
        {
            X = new double[N];
            for (int i = 1; i < N; i++)
            {
                C[i - 1] = C[i - 1] / B[i - 1];
                D[i - 1] = D[i - 1] / B[i - 1];
                B[i] -= A[i] * C[i - 1];
                D[i] -= A[i] * D[i - 1];
            }
            X[N - 1] = D[N - 1] / B[N - 1];
            for (int i = N - 2; i >= 0; i--)
            {
                X[i] = D[i] - C[i] * X[i + 1];//Xn-Xn-1，误差
            }
        }

        /// <summary>
        /// 求解几何平均
        /// </summary>
        /// <param name="N">层数</param>
        /// <param name="Z">厚度0</param>
        /// <param name="RK"></param>
        /// <param name="CON"></param>
        public static void CONDUC(int N, double[] Z, double[] RK, ref double[] CON)
        {
            for (int i = 0; i < N - 1; i++)
            {
                CON[i] = Math.Sqrt(RK[i] * RK[i + 1]) / (Z[i + 1] - Z[i]);
            }

        }

        /// <summary>
        /// 计算日饱和蒸气压和温度梯度
        /// </summary>
        /// <param name="Satv">饱和蒸气压</param>
        /// <param name="S">饱和蒸气压曲线坡度</param>
        /// <param name="Temp">大气温度</param>
        public static void VSLOPE(double Ta, out double Satv, out double S)
        {
            double Tempkl = Ta + SWHSconst.Tk0;  //卡尔文温度
            Satv = Math.Exp(52.57633 - 6790.4985 / Tempkl - 5.02808 * Math.Log(Tempkl, Math.E)) * 1000 / (SWHSconst.UGAS * Tempkl / SWHSconst.Mw);//饱和蒸气压
            S = 0.0000165 + 4944.43 * (Satv) / Math.Pow(Tempkl, 2);//饱和蒸气压曲线坡度
        }

        /// <summary>
        /// 算数平均
        /// </summary>
        /// <param name="N"></param>
        /// <param name="AVG"></param>
        /// <param name="BEGIN"></param>
        /// <param name="END"></param>
        public static void WEIGHT(int N, ref double[] AVG, double[] BEGIN, double[] END)
        {
            for (int i = 0; i < N; i++)
            {
                AVG[i] = SWHSconst.WT * BEGIN[i] + SWHSconst.WDT * END[i];
            }
        }

        public static void SYSTEM(int NXCELL, int NYCELL, int[][] NSP, double ZMCM, double ZMSPCM, double HEIGHT, double Vegheight, int[][] upfaceid, double[][][] ZSP, ref double[][] ZM, ref double[][] ZH, ref double[][] ZERO)
        {

            //int NXCELL = 1;
            //int NYCELL = 1;
            //int RegRank = upfaceid.Rank;
            // NXCELL = upfaceid.GetLength(0);
            // if (RegRank == 2)
            //{
            //  NYCELL = upfaceid.GetLength(1);
            //}

            double ZMSRF = ZMCM / 100;
            double ZHSRF = 0.2 * ZMSRF;
            double ZERSRF = 0.0;

            double ZMSP = ZMSPCM / 100.0;
            double ZHSP = 0.2 * ZMSP;
            for (int i = 0; i < NXCELL; i++)
            {
                for (int j = 0; j < NYCELL; j++)
                {
                    if (upfaceid[i][j] >= 0)
                    {
                        //ZM[i][j] = ZMSRF;
                        //ZH[i][j] = ZHSRF;
                        //ZERO[i][j] = ZERSRF;
                        ZM[i][j] = 0.15 * Vegheight;
                        ZH[i][j] = 0.2 * ZM[i][j];
                        ZERO[i][j] = 0.67 * Vegheight;

                        if (NSP[i][j] > 0)
                        {
                            ZM[i][j] = ZMSP;
                            ZH[i][j] = ZHSP;
                            ZERO[i][j] = ZSP[i][j][NSP[i][j]];
                            if ((ZERO[i][j] + ZM[i][j]) > HEIGHT) ZERO[i][j] = HEIGHT / 2;
                        }
                    }
                }
            }

        }

        //计算湿球温度及相关的变量
        public static void WTBULB(double PRESUR, double TA, double HUM, ref double TW)
        {
            double TAV, EAV;
            double PA = 0.01 * PRESUR;
            double EAS = 2.7489E8 * Math.Exp(-4278.63 / (TA + 242.792));
            double EA = HUM * EAS;
            double DELTA = (4278.63 / ((TA + 242.792) * (TA + 242.792))) * EAS;
            for (int i = 0; i < 3; i++)
            {
                TW = DELTA * TA + 6.6E-4 * PA * TA + 7.59E-7 * PA * TA * TA + EA - EAS;
                TW = TW / (DELTA + 6.6E-4 * PA + 7.59E-7 * PA * TA);
                TAV = (TA + TW) * 0.5;
                EAV = 2.7489E8 * Math.Exp(-4278.63 / (TAV + 242.792));
                DELTA = (4278.63 / ((TAV + 242.792) * (TAV + 242.792))) * EAV;
            }
        }

        /// <summary>
        /// 统计定义时段内的变量
        /// </summary>
        /// <param name="Ntimes"></param>
        /// <param name="NX"></param>
        /// <param name="NY"></param>
        /// <param name="upfaceid"></param>
        /// <param name="NSP"></param>
        /// <param name="DT"></param>
        /// <param name="VFLUX"></param>
        /// <param name="QVSP"></param>
        /// <param name="TOPSNO"></param>
        /// <param name="EVAP1"></param>
        /// <param name="TQVSP"></param>
        public static void SUMDT(int Ntimes, int NX, int NY, int[][] upfaceid, int[][] NSP, double DT, double[][] VFLUX, double[][][] QVSP, ref double[][] TOPSNO, ref double[][] EVAP1, ref double[][][] TQVSP)
        {
            if (Ntimes < 1)
            {
                for (int i = 0; i < NX; i++)
                {
                    for (int j = 0; j < NY; j++)
                    {
                        if (upfaceid[i][j] >= 0)
                        {
                            EVAP1[i][j] = 0.0;
                            if (NSP[i][j] > 0)
                            {
                                TOPSNO[i][j] = 0.0;
                                TQVSP[i][j] = new double[NSP[i][j]];
                                for (int l = 0; l < NSP[i][j]; l++)
                                {
                                    TQVSP[i][j][l] = 0.0;
                                }
                            }

                        }
                    }
                }
            }

            if (Ntimes >= 1)
            {
                for (int i = 0; i < NX; i++)
                {
                    for (int j = 0; j < NY; j++)
                    {
                        if (upfaceid[i][j] >= 0)
                        {
                            EVAP1[i][j] += VFLUX[i][j] / SWHSconst.RHOL * DT;//单位是m                            
                            if (NSP[i][j] > 0)
                            {
                                TOPSNO[i][j] += VFLUX[i][j] * DT;//kg m-2 (类似于压强的单位。）
                                for (int l = 0; l < NSP[i][j]; l++)
                                {

                                    TQVSP[i][j][l] += QVSP[i][j][l] * DT;

                                }
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 将时间步结束值设置回时间步开始时的值
        /// </summary>
        /// <param name="Ntimes"></param>
        /// <param name="TVvar"></param>
        /// <param name="HHvar"></param>
        public static void BACKUP(int Ntimes, SWHSvar TVvar, HHMMvar HHvar)
        {
            for (int ic = 0; ic < HHvar.cuboidnum; ic++)
            {
                TVvar.waterphas.VLCDT[ic] = TVvar.waterphas.VLC[ic];
                TVvar.waterphas.OUTWADT[ic] = TVvar.waterphas.OUTWA[ic];
                TVvar.waterphas.OUTWA2DT[ic] = TVvar.waterphas.OUTWA2[ic];
                TVvar.waterphas.OUTEDT[ic] = TVvar.waterphas.OUTE[ic];
                TVvar.waterphas.OUTTDT[ic] = TVvar.waterphas.OUTT[ic];
                TVvar.waterphas.MATDT[ic] = TVvar.waterphas.MAT[ic];
                TVvar.icephas.VICDT[ic] = TVvar.icephas.VIC[ic];
                TVvar.heatphas.TSDT[ic] = TVvar.heatphas.TS[ic];
                TVvar.icephas.ICESDT[ic] = TVvar.icephas.ICES[ic];
            }
            for (int i = 0; i < HHvar.NXCELL; i++)
            {
                for (int j = 0; j < HHvar.NYCELL; j++)
                {
                    if (HHvar.upfaceid[i][j] >= 0)
                    {
                        for (int n = 0; n < 4; n++)
                        {

                            HHvar.soiltosurfaceDT[i][j][n] = HHvar.soiltosurface[i][j][n];

                        }
                    }
                }
            }
            if (Ntimes == 0)
            {
                for (int i = 0; i < HHvar.NXCELL; i++)
                {
                    for (int j = 0; j < HHvar.NYCELL; j++)
                    {
                        if ((HHvar.upfaceid[i][j] >= 0) & (TVvar.SNMatrix.NSP[i][j] > 0))
                        {
                            for (int n = 0; n < TVvar.SNMatrix.NSP[i][j]; n++)
                            {

                                TVvar.SNMatrix.TSP[i][j][n] = TVvar.SNMatrix.TSPDT[i][j][n];
                                TVvar.SNMatrix.DLW[i][j][n] = TVvar.SNMatrix.DLWDT[i][j][n];

                            }
                        }
                    }
                }
            }
        }
    }
}
