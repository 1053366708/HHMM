﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Globalization;

namespace HHMM
{
    public class SWHSinit
    {
        public static void TVinit(SWHSvar TVvar, HHMMvar HHvar, string Tvdatapath)
        {
            SWHSshape(TVvar.NXCELL, TVvar.NYCELL, TVvar.NZCELL, HHvar.Novalue, HHvar.upfaceid, HHvar.downfaceid, HHvar.cellord, ref TVvar.cellsize.celltopo, ref TVvar.mumpsSWHS.irn, ref TVvar.mumpsSWHS.jcn, ref TVvar.nnum, ref TVvar.nznum);
            SWHSparinit(Tvdatapath, TVvar);
            SWHSstateinit(TVvar, HHvar);
            SWHSWater.Gq2k(HHvar, TVvar.waterphas.VLC, TVvar.icephas.VIC, ref TVvar.waterphas.K);//求解土壤不饱和导水率K
            SWHSWater.Gq2y(HHvar, TVvar.waterphas.VLC, TVvar.icephas.VIC, ref TVvar.waterphas.MAT);//求解水势
                                                                                                   //SWHSIce.Soilicecal(HHvar, TVvar);
            SWHSHeat.Cscal(HHvar, TVvar.waterphas.VLC, TVvar.icephas.VIC, ref TVvar.heatphas.Cssoil);//土壤热容量计算
            SWHSHeat.Kscal(HHvar, TVvar.waterphas.VLC, TVvar.icephas.VIC, ref TVvar.heatphas.Kssoil);//土壤热传导计算

            HHvar.cellord = null;
        }

        /// <summary>
        /// SWHSpara.txt文件的读取
        /// </summary>
        /// <param name="datapath"></param>
        /// <param name="TVvar"></param>
        public static void SWHSparinit(string datapath, SWHSvar TVvar)
        {
            char[] spi = new char[] { ' ', ',', '\t' };
            string flName = System.IO.Path.Combine(datapath, "SWHSpara.txt");
            string[] s = File.ReadAllLines(flName);
            double[] fpara = new double[s.Length];
            for (int i = 0; i < s.Length; i++)
            {
                string[] tempS = s[i].Split(spi);
                fpara[i] = double.Parse(tempS[1]);
            }
            //设定参数
            TVvar.Minstep = fpara[0];
            TVvar.Werror = fpara[1];
            TVvar.Hchange = fpara[2];
            TVvar.Terror = fpara[3];
            TVvar.Tchange = fpara[4];
        }

        /// <summary>
        /// 各变量初始值
        /// </summary>
        /// <param name="TVvar"></param>
        /// <param name="HHvar"></param>
        public static void SWHSstateinit(SWHSvar TVvar, HHMMvar HHvar)
        {
            TVvar.Totalsoilwatervolume = 0.0;
            TVvar.Totalrockwatervolume = 0.0;
            for (int soli = 0; soli < HHvar.solutenum; soli++)
            {
                TVvar.Totalsoilsolute[soli] = 0.0;
            }
            for (int ic = HHvar.startcell; ic < HHvar.endcell; ic++)
            {
                int ct = HHvar.cellsoiltype[ic];
                TVvar.waterphas.VLC[ic] = HHvar.soilwaterpara.swinit[ct];//土壤初始含水率
                TVvar.heatphas.TS[ic] = HHvar.soilheatpara.stinit[ct];//土壤初始温度
                TVvar.waterphas.OUTWA[ic] = 0.0;

                for (int soli = 0; soli < HHvar.solutenum; soli++)
                {
                    TVvar.solutephas.soilsolunew[soli][ic] = HHvar.soilsolutepara.soinit[soli][ct];//溶质初始值，浓度
                }
                if (ct < HHvar.rocknum - 1)
                {
                    TVvar.Totalsoilwatervolume += TVvar.waterphas.VLC[ic] * TVvar.Cellx * TVvar.Celly * TVvar.Cellz;//土壤水体积
                }
                else
                {
                    TVvar.Totalrockwatervolume += TVvar.waterphas.VLC[ic] * TVvar.Cellx * TVvar.Celly * TVvar.Cellz;//基岩水体积
                }

                for (int soli = 0; soli < HHvar.solutenum; soli++)
                {
                    TVvar.Totalsoilsolute[soli] += (TVvar.waterphas.VLC[ic] * SWHSconst.RHOL + HHvar.soilheatpara.minedensity[ct] * HHvar.soilsolutepara.kcq[soli][ct]) * TVvar.solutephas.soilsolunew[soli][ic] * TVvar.Cellx * TVvar.Celly * TVvar.Cellz;//该网格的溶质的mol含量
                }
            }
        }

        /// <summary>
        /// 一维化网格的三维空间拓扑结构
        /// </summary>
        /// <param name="NXCELL"></param>
        /// <param name="NYCELL"></param>
        /// <param name="NZCELL"></param>
        /// <param name="Novalue"></param>
        /// <param name="upfaceid"></param>
        /// <param name="downfaceid"></param>
        /// <param name="cellord"></param>
        /// <param name="celltopo"></param>
        /// <param name="irn"></param>
        /// <param name="jcn"></param>
        /// <param name="n"></param>
        /// <param name="nz"></param>
        public static void SWHSshape(int NXCELL, int NYCELL, int NZCELL, double Novalue, int[][] upfaceid, int[][] downfaceid, int[][][] cellord, ref int[][] celltopo, ref int[] irn, ref int[] jcn, ref int n, ref int nz)
        {//创建稀疏矩阵的准备
            int i, j, l;
            n = 0;
            nz = 0;
            for (i = 0; i < NXCELL; i++)
            {
                for (j = 0; j < NYCELL; j++)
                {
                    if (upfaceid[i][j] > Novalue + 10)
                    {
                        for (l = upfaceid[i][j]; l <= downfaceid[i][j]; l++)
                        {
                            celltopo[n][0] = i;//有效网格的x。n是有效网格的序号0\1\2...
                            celltopo[n][1] = j;//有效网格的y
                            celltopo[n][2] = l;//有效网格的z。从上往下，0.1（DZ）为一个单位长度
                            for (int ni = 3; ni < 9; ni++)
                            {
                                celltopo[n][ni] = -9999;
                            }
                            //左右前后上下是否有有效网格
                            if ((i - 1) >= 0)
                            {
                                if (cellord[i - 1][j][l] >= Novalue + 10)
                                {
                                    irn[nz] = cellord[i][j][l];
                                    jcn[nz] = cellord[i - 1][j][l];
                                    nz++;
                                    celltopo[n][3] = cellord[i - 1][j][l];
                                }
                            }

                            if ((j - 1) >= 0)
                            {
                                if (cellord[i][j - 1][l] >= Novalue + 10)
                                {
                                    irn[nz] = cellord[i][j][l];
                                    jcn[nz] = cellord[i][j - 1][l];
                                    nz++;
                                    celltopo[n][4] = cellord[i][j - 1][l];
                                }
                            }

                            if ((l - 1) >= 0)
                            {
                                if (cellord[i][j][l - 1] >= Novalue + 10)
                                {
                                    irn[nz] = cellord[i][j][l];
                                    jcn[nz] = cellord[i][j][l - 1];
                                    nz++;
                                    celltopo[n][5] = cellord[i][j][l - 1];
                                }
                            }

                            irn[nz] = cellord[i][j][l];
                            jcn[nz] = cellord[i][j][l];
                            nz++;

                            if ((l + 1) < NZCELL)
                            {
                                if (cellord[i][j][l + 1] >= Novalue + 10)
                                {
                                    irn[nz] = cellord[i][j][l];
                                    jcn[nz] = cellord[i][j][l + 1];
                                    nz++;
                                    celltopo[n][6] = cellord[i][j][l + 1];
                                }
                            }

                            if ((j + 1) < NYCELL)
                            {
                                if (cellord[i][j + 1][l] >= Novalue + 10)
                                {
                                    irn[nz] = cellord[i][j][l];
                                    jcn[nz] = cellord[i][j + 1][l];
                                    nz++;
                                    celltopo[n][7] = cellord[i][j + 1][l];
                                }
                            }

                            if ((i + 1) < NXCELL)
                            {
                                if (cellord[i + 1][j][l] >= Novalue + 10)
                                {
                                    irn[nz] = cellord[i][j][l];
                                    jcn[nz] = cellord[i + 1][j][l];
                                    nz++;
                                    celltopo[n][8] = cellord[i + 1][j][l];
                                }
                            }
                            n = n + 1;
                        }
                    }
                }
            }
        }

        public static double[][] readDoubleFromFile(string path)
        {
            int k, i;
            double[][] n = new double[2][];
            if (File.Exists(path))
            {
                char[] spi = new char[] { ' ', ',', '\t' };
                string[] st = null;
                st = File.ReadAllLines(path);
                n = new double[st.Length][];
                for (k = 0; k < st.Length; k++)
                {
                    string[] sta = st[k].Split(spi, StringSplitOptions.RemoveEmptyEntries);
                    n[k] = new double[sta.Length];
                    for (i = 0; i < sta.Length; i++)
                    {
                        n[k][i] = double.Parse(sta[i]);
                    }
                }
            }
            else { Console.WriteLine("未找到文件：" + path); }
            return n;
        }
    }
}
