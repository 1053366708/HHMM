﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathNet.Numerics;

namespace HHMM
{
    public class SWHSSiLSM
    {
        /// <summary>
        /// S-W模型
        /// </summary>
        /// <param name="year">年</param>
        /// <param name="LAI">叶面积指数[m2/m2]</param>
        /// <param name="lwc">叶片水含量[g/m2]</param>
        /// <param name="Ta_Avg">大气温度[C]</param>
        /// <param name="Rh_Avg">相对湿度[]</param>
        /// <param name="Gs_Avg">ground heat[W/m2]</param>
        /// <param name="Rn_Avg">净辐射[W/m2]</param>
        /// <param name="H">显热通量[W/m2]</param>
        /// <param name="LE">感热通量[W/m2]</param>
        /// <param name="ustar">摩擦速度[m/s]</param>
        /// <param name="Rain">降水量[m]</param>
        /// <param name="Zh">冠层高度[m]</param>
        /// <param name="CO2">CO2浓度[mg/m3]</param>
        /// <param name="Rs_inc_Avg">输入的太阳辐射?入射短波辐射[W/m2]</param>
        /// <param name="Prss_Avg">大气压[KPa]</param>
        /// <param name="U">风速[m/s]</param>
        /// <param name="theta">Soil moisture at top layer</param>
        /// <param name="theta_2">Soil moisture at root layer,if no data available, set theta_2=theta</param>
        /// <param name="Ts_Avg">土壤表层温度/地表温度[C]</param>
        /// <param name="Soil_DO">土壤水同位素[per mil]</param>
        /// <param name="Vapor_DO">水蒸气同位素[per mil]</param>
        /// <param name="Xylem_DO">根茎水同位素[per mil]</param>
        /// 



        public static void SiLSM(int coni, int laynum, int rocknum, int[] cellsoiltype, double LAI, double Ta_Avg, double Rh_Avg, double Gs_Avg, double Rn_Avg, double ustar, double Zh, double CO2, double Rs_inc_Avg, double Prss_Avg, double U, double theta, double theta_2, ref double HS, ref double LES, ref double[] EnergBaadd, ref double[] WaterBaadd, ref double Es, ref double Tr)
        {

            U = Math.Max(0.01, U);
            //if (SWHSMyConstants.SWC2_measurement == 0 || double.IsNaN(theta_2))
            //{
            //    theta_2 = theta;
            //}
            //if (SWHSMyConstants.G_measurement == 0 || double.IsNaN(Gs_Avg))
            //{
            //    //Gs_Avg =
            //}
            //if (SWHSMyConstants.ustar_measurement == 0 || double.IsNaN(ustar))
            //{
            //    //ustar =
            //}


            ////Rh_Avg = Rh_Avg;
            ////Rain = Rain * 1000;
            ////判断是否计算同位素
            //if (SWHSMyConstants.Isotope == 1 & SWHSMyConstants.lwc_measurement == 0)
            //{
            //    double lwc = LAI * 120 / 18;//因为叶片水分的测量大概率没有，如果有需要修改方法输入
            //}
            //计算气象变量

            double e_Avg = 0.6108 * Math.Exp(17.27 * Ta_Avg / (Ta_Avg + 237.3)) * Rh_Avg;//KPa
            double esat_air = 0.6108 * Math.Exp(17.27 * Ta_Avg / (Ta_Avg + 237.3));//KPa
            double VPD_Avg = esat_air - e_Avg;//饱和水汽压差，若没有输入则需要计算，有输入修改这行代码

            //Calculate ground heat and water storage heat
            double G;
            if (SWHSMyConstants.Flooding == 1)
            {
                //涉及到水深和前后时段的水温差，实际可能可以忽略水体

            }
            else
            {
                G = Gs_Avg;
            }
            /*
            //检查能量闭合
            double imbalance = Math.Abs(1 - (Rn_Avg - G)/ (H + LE));
            double QCflag = 1;//0时不可信
            if(imbalance > 0.2)
            {
                QCflag = 0;
            }
            if(SWHSMyConstants.Flooding == 1)
            {
                if(imbalance > 0.2)
                {
                    G = 0.2 * Rn_Avg;//if flooding,G is more unreliable, force it = 0.2Rn
                }
            }            
            flux_c(G, H, LE, Rn_Avg, out double LE_c, out double H_c);//进行能量闭合矫正
            

            //QCcheck
            if(LE_c > 800 || LE_c < -100 || H_c > 800 || H_c < -100 || Rn_Avg > 1000 || Rn_Avg < -200 || Rh_Avg >= 1 || ustar < 0.06 || Rain > 0)
            {
                QCflag = 0;
            }
            if(SWHSMyConstants.Flooding == 1)
            {
                //QCflag(WaterDepth>0)=0;  注意修改
            }
            */
            double A = Rn_Avg - G;                              // Total available energy[w / m2]
            double Rns = Rn_Avg * Math.Exp(-(SWHSMyConstants.Kr) * LAI); // Radiation reaching the soil surface[w / m2]
            double As = Rns - G;                                // Available energy for the soil surface[w / m2]
            double Tc_temp = Ta_Avg + 2.0;// 假设冠层温度比空气温度高2℃

            //运行S-W模型

            ETestimation(Zh, Ta_Avg, e_Avg, CO2, Rs_inc_Avg, Tc_temp, LAI, Rh_Avg, Prss_Avg, ustar, U, As, A, theta, theta_2, VPD_Avg, out Es, out Tr, out double rsc, out double rss, out double Tem_c);

            Tr = Math.Max(0.0, Tr);
            LES = Es + Tr;
            HS = A - LES;

            //模型耦合
            int slnum = 0;//土壤层数
            for (int li = 0; li < laynum; li++)
            {
                int st = cellsoiltype[coni + li];
                if (st < rocknum - 1)
                {
                    slnum += 1;
                }
            }
            EnergBaadd[coni] = EnergBaadd[coni] - Es - Tr / slnum - HS;
            WaterBaadd[coni] = -(Es + Tr / slnum) / (SWHSconst.LV * SWHSconst.RHOL);
            for (int li = 1; li < slnum; li++)
            {
                //EnergBaadd[coni + li] = EnergBaadd[coni + li] - Tr / slnum;
                WaterBaadd[coni + li] = -(Tr / slnum) / (SWHSconst.LV * SWHSconst.RHOL);
            }


            // double TET_sw = (Tr / LES);

            //计算同位素

            //if (SWHSMyConstants.Isotope == 1)
            //{
            //    DE_nonflooding(Ta_Avg, Ts_Avg, e_Avg, Rh_Avg, Soil_DO, Vapor_DO, out double Delta_E_O);//计算蒸发同位素

            //    double d_T = Xylem_DO;//计算蒸腾同位素
            //}


        }

        /// <summary>
        /// 能量闭合校正
        /// </summary>
        /// <param name="G"></param>
        /// <param name="H"></param>
        /// <param name="LE"></param>
        /// <param name="Rn_Avg"></param>
        /// <param name="LE_f"></param>
        /// <param name="H_f"></param>
        public static void flux_c(double G, double H, double LE, double Rn_Avg, out double LE_f, out double H_f)
        {

            double Br = LE / (LE + H);//calibrated by Bowen Ratio.
            double LE_u = (Rn_Avg - G - H - LE) * Br;
            LE_f = LE_u + LE;// final LE
            H_f = H + (Rn_Avg - G - H - LE) * (1 - Br);
        }

        public static void ETestimation(double Zh, double Ta_Avg, double e_Avg, double co2, double K_d, double T_c_0, double LAI, double Rh_Avg, double Prss_Avg, double ustar, double wnd_spd, double As, double A, double theta, double theta_2, double VPD, out double Es, out double Tr, out double rsc2, out double rss, out double Tc)
        {
            double T_ck_0 = T_c_0 + SWHSconst.Tk0;
            double rho_a = SWHSconst.RHOA;  //air density at sea leve kg / m3
            double lambda = SWHSconst.LV; // latent heat of vaporization J/ kg
            rss = Math.Exp(8.206 - 4.225 * theta) * (SWHSMyConstants.rss_v);// Soil resistance


            //first guess
            //co2 = 620;
            double C_a = co2;// *1.8; // approximate, mg / m3 ? convert ppm to mg/ m3
            double C_s = C_a;
            //double PAR_t = K_d / 4.55;// 1W·m-2 = 4.55μmol·m-2·s-1
            double PAR_t = K_d / 2; // shortwave radiation in PAR waveband, W/ m2 光合有效辐射可能有测量值，考虑输入
            double D_s_0 = 1.15; // kPa
            double C_i_0 = 400; // mg / m3
            Es = 0; Tr = 0; rsc2 = 0; Tc = 0;
            double error = 0.01;
            double C_i = 400;
            double D_s = 1.15;
            int iter = 0;
            //iteration:
            //repeating 40 times to get more precise estimate of C_s, D_s and C_i
            // for(int i = 0; i < 40; i++)
            // {
            do
            {
                iter++;
                C_i_0 = C_i;
                D_s_0 = D_s;
                surface_conductance(T_ck_0, PAR_t, C_s, D_s_0, C_i_0, LAI, theta_2, out double A_g, out double A_n, out double A_m, out double g_m, out double g_cc, out double Gamma, out double R_d);
                double g_cw = g_cc * 1.6; // mm / s
                double rsc = 1 / g_cw;
                rsc2 = rsc * 1000;
                if (rsc2 < 0)
                {
                    rsc2 = 0;
                }
                ETsw(e_Avg, Prss_Avg, Ta_Avg, rsc2, LAI, Zh, rss, ustar, wnd_spd, As, A, VPD, out Es, out Tr);
                if (Tr < 0)
                {
                    Tr = 0;
                }
                double H_1 = A - Es - Tr;
                double w_T = H_1 / rho_a / SWHSconst.CA;//这里的俩常数是啥，猜测是空气密度和空气比热
                double ObukhovLength = Math.Pow(ustar, 3) / (SWHSconst.VONKRM * (SWHSconst.G / Ta_Avg) * w_T);//ObukhovLength长度 m
                aerodynamicresistance(Zh, wnd_spd, ObukhovLength, out double Rav, out double Rag);// aero dynamic resistance
                Tc_Taylor_Expansion_theory(Ta_Avg, Rh_Avg, rsc2, Rav, Tr, Prss_Avg, out Tc);
                T_ck_0 = Tc + SWHSconst.Tk0;

                C_i = C_s - A_n / (g_cc / 1000); // converting g_cc to m / s
                double C_i_min = C_s - A_n / (g_cc / 1000 + A_g / (C_s - Gamma)); // converting g_cc to m / s
                if (C_i_min <= 0)
                {
                    C_i_min = 400;
                }
                if (C_i < C_i_min)
                {
                    C_i = C_i_min;
                }
                D_s = Prss_Avg / 0.622 * Tr / (rho_a * lambda * (g_cw / 1000));
                //D_s(isnan(D_s)==1)=1.15; 这个如果不是代表分母是0就好，因为分母是0在matlab中表示的是Inf     但如果g_cw = 0咋办 
                if (C_s < 200 || C_s > 1000)
                {
                    C_s = 688;
                }
                //   if (Math.Abs((C_i_0 - C_i) / C_i_0) > error || Math.Abs((D_s_0 - D_s) / D_s_0) > error)
                //  {
                //     C_i_0 = C_i;

                //     D_s_0 = D_s;
                //     goto iteration;
                // }
            } while ((Math.Abs((C_i_0 - C_i) / C_i_0) > error || Math.Abs((D_s_0 - D_s) / D_s_0) > error) && iter < 40);



            //}
        }

        public static void aerodynamicresistance(double Zh, double U, double ObukhovLength, out double Rav, out double Rag)
        {
            //do the zero-plane displacement height(m)
            double d0 = 0.666 * Zh;
            //Z0mv is the roughness length govering momentum transfer above vegetation canopy(m)
            double Z0mv = 0.123 * Zh;
            // Z0hv is the roughness length govering heat and vapor transfer above vegetation canopy(m)
            double Z0hv = 0.1 * Z0mv;
            // Z0mg is the roughness length govering momentum transfer above ground surface(m)
            double Z0mg = 0.0001;
            // Z0hg is the roughness length govering heat and vapor transfer above ground surface(m)
            double Z0hg = 0.1 * Z0mg;
            // k von Karman constant
            double k = 0.41;
            double ZL = (4 - Zh) / ObukhovLength;
            if (ZL > 1)
            {
                ZL = 1;
            }
            else if (ZL < -1.5)
            {
                ZL = -1.5;
            }
            // get stability correction function
            brutsaertstability(ZL, out double stab_m, out double stab_h);

            //Rav the aerodynamic resistance for vegetation canopy(s m - 1)
            Rav = (Math.Log((SWHSMyConstants.Zu_m - d0) / Z0mv) - stab_m) * (Math.Log((SWHSMyConstants.Zt_m - d0) / Z0hv) - stab_h) / (Math.Pow(k, 2) * U);

            // Rag the aerodynamic resistance for ground surface(s m - 1)
            Rag = (Math.Log(SWHSMyConstants.Zu_m / Z0mg) - stab_m) * (Math.Log(SWHSMyConstants.Zt_m / Z0hg) - stab_h) / (k * k * U);
        }

        public static void brutsaertstability(double ZL, out double stab_m, out double stab_h)
        {
            if (ZL >= 0)
            {
                stab_m = -6.1 * Math.Log(ZL + Math.Pow(1 + Math.Pow(ZL, 2.5), 1 / 2.5));
                stab_h = stab_m;
            }
            else
            {
                double a = 0.33;
                double b = 0.41;
                double c = 0.33;
                double d = 0.057;
                double n = 0.78;
                double y = -ZL;
                double S0 = (-Math.Log(a) + Math.Pow(3, 0.5) * b * Math.Pow(a, 0.3333) * Math.PI / 6);
                stab_h = ((1 - d) / n) * Math.Log((c + Math.Pow(y, n)) / c);
                if (y > 14.509)
                {
                    y = 14.509;
                }
                double x = Math.Pow(y / a, 1 / 3);

                stab_m = Math.Log(a + y) - 3 * b * Math.Pow(y, 1 / 3) + b * Math.Pow(a, 1 / 3) / 2 * Math.Log(Math.Pow(1 + x, 2) / (1 - x + x * x)) + Math.Pow(3, 0.5) * b * Math.Pow(a, 1 / 3) * Math.Atan((2 * x - 1) / Math.Pow(3, 0.5)) + S0;

            }
        }
        /// <summary>
        /// surface conductance (and gross primary production
        /// </summary>
        /// <param name="T_sk">skin temperature (degK)</param>
        /// <param name="PAR_t">PAR at the top of the canopy (W/m2)</param>
        /// <param name="C_s">CO2 concentrattion at the leaf surface (mg/m3)</param>
        /// <param name="D_s">vapor pressure deficient at the leaf (kPa)</param>
        /// <param name="C_i">internal CO2 concentration (mg/m3)</param>
        /// <param name="LAI">Leaf area index, dimensionless</param>
        /// <param name="theta"></param>
        /// <param name="A_g">gross primary production (mg/m2s)</param>
        /// <param name="A_n">net primary productivity (mg/m2s)</param>
        /// <param name="A_m"></param>
        /// <param name="g_m"></param>
        /// <param name="g_cc">surface conductance for CO2 (mm/s)</param>
        /// <param name="Gamma"></param>
        /// <param name="d1"></param>
        /// <param name="d2"></param>
        /// <param name="R_d"></param>
        public static void surface_conductance(double T_sk, double PAR_t, double C_s, double D_s, double C_i, double LAI, double theta, out double A_g, out double A_n, out double A_m, out double g_m, out double g_cc, out double Gamma, out double R_d)
        {
            double f0;
            if (SWHSMyConstants.C3 == 1)
            {
                f0 = 0.89;// see egea et al. 2011

            }
            else
            {
                f0 = 0.85;
            }
            double a_1 = 1 / (1 - f0);

            //soil moisture stress
            double FC = 0.25; // adjust according to John Baker's suggestion 0.36
            double WP = 0.06; // adjust according to John Baker's suggestion 0.18
            double beta = Math.Max(0, Math.Min(1, (theta - WP) / (FC - WP))); //opt result 0.51679 0.52234 1.1982 *
            double f5 = 2 * beta - beta * beta;
            //f5 = 1;
            mesophyll_conductance(T_sk, out g_m);
            CO2_compensation_point(T_sk, out Gamma);
            light_use_efficiency(Gamma, C_s, out double alpha);
            prim_prod(T_sk, g_m, Gamma, C_i, out A_m);
            R_d = 0.11 * A_m;

            double deltad, b1, b2;
            if (PAR_t <= 0.001)// nighttime
            {
                A_g = 0;
                A_n = A_g - R_d * LAI;
                g_cc = SWHSMyConstants.g_min_c * LAI;
                //d1 = 0;
                //d2 = 0;
            }
            else
            {
                //d1 = expint(alpha * (SWHSMyConstants.Kr) * PAR_t / (A_m + R_d) * Math.Exp(-(SWHSMyConstants.Kr) * LAI));
                //d2 = expint(alpha * (SWHSMyConstants.Kr) * PAR_t / (A_m + R_d));

                //注：因为C#没法直接求指数积分，所以在这个地方用到了Math.Net这个库中的定积分，直接计算了deltad = d1-d2
                b1 = alpha * (SWHSMyConstants.Kr) * PAR_t / (A_m + R_d) * Math.Exp(-(SWHSMyConstants.Kr) * LAI);
                b2 = alpha * (SWHSMyConstants.Kr) * PAR_t / (A_m + R_d);
                deltad = Integrate.OnClosedInterval(x => Math.Exp(-x) / x, b1, b2);
                A_g = (A_m + R_d) * (LAI - (deltad) / (SWHSMyConstants.Kr)) * f5;
                A_n = (A_g - R_d * LAI); //A_n with soil water stress

                g_cc = (SWHSMyConstants.g_min_c * LAI + 1000 * a_1 * (A_m + R_d) * f5 / ((C_s - Gamma) * (1 + D_s / (SWHSMyConstants.D0))) * (LAI - (deltad) / (SWHSMyConstants.Kr)));// g_cc with soil water stress
            }
        }

        /// <summary>
        /// mesophyll conductance
        /// </summary>
        /// <param name="T_sk"></param>
        /// <param name="g_m"></param>
        public static void mesophyll_conductance(double T_sk, out double g_m)
        {
            double g_m_298, Q_10_g_m, T_1_g_m, T_2_g_m;
            if (SWHSMyConstants.C3 == 1)
            {
                g_m_298 = 7; // g_m_298: mesophyll conductance at 298 degK(7.0 mm / s)
                Q_10_g_m = 2.0; // Q_10_g_m: Q10 value(2.0)
                T_1_g_m = 278; // T_1_g_m: lower temperature threshold(278 degK)
                T_2_g_m = 301; // T2_g_m: upper temperature threshold

            }
            else
            {
                g_m_298 = 17.5; // g_m_298: mesophyll conductance at 298 degK
                Q_10_g_m = 2.0; // Q_10_g_m: Q10 value(2.0)
                T_1_g_m = 286; // T_1_g_m: lower temperature threshold
                T_2_g_m = 309; // T2_g_m: upper temperature threshold
            }
            g_m = g_m_298 * Math.Pow(Q_10_g_m, (T_sk - 298) / 10);
            g_m = g_m / ((1 + Math.Exp(0.3 * (T_1_g_m - T_sk))) * (1 + Math.Exp(0.3 * (T_sk - T_2_g_m))));

        }

        /// <summary>
        /// CO2 compensation point
        /// </summary>
        /// <param name="T_sk"></param>
        /// <param name="Gamma"></param>
        public static void CO2_compensation_point(double T_sk, out double Gamma)
        {
            double Gamma_298;
            if (SWHSMyConstants.C3 == 1)
            {
                Gamma_298 = 68.5 * 1.23; // CO2 compensation point at 298 degK(68.5 * rho_a mg / m3; air density in kg / m3)

            }
            else
            {
                Gamma_298 = 4.3 * 1.23;
            }
            double Q_10_Gamma = 1.5;// Q_10_Gamma: Q10 value for Gamma
            Gamma = Gamma_298 * Math.Pow(Q_10_Gamma, (T_sk - 298) / 10);
        }

        /// <summary>
        /// light use efficiency
        /// </summary>
        /// <param name="Gamma"></param>
        /// <param name="C_s"></param>
        /// <param name="alpha"></param>
        public static void light_use_efficiency(double Gamma, double C_s, out double alpha)
        {
            double alpha_0;
            if (SWHSMyConstants.C3 == 1)
            {
                alpha_0 = 0.017; // alpha_0: light use efficiency at low light(mg/ J)

            }
            else
            {
                alpha_0 = 0.014;
            }
            alpha = alpha_0 * (C_s - Gamma) / (C_s + 2 * Gamma);
        }

        /// <summary>
        /// to calculate A_m (primary_productivity)
        /// </summary>
        /// <param name="T_sk_0"></param>
        /// <param name="g_m"></param>
        /// <param name="Gamma"></param>
        /// <param name="C_i_0"></param>
        /// <param name="A_m"></param>
        public static void prim_prod(double T_sk_0, double g_m, double Gamma, double C_i_0, out double A_m)
        {
            double A_m_max_298, Q_10_A_m, T_1_A_m, T_2_A_m;
            if (SWHSMyConstants.C3 == 1)
            {
                A_m_max_298 = 2.2;
                Q_10_A_m = 2.0;
                T_1_A_m = 281.0;
                T_2_A_m = 311.0;

            }
            else
            {
                A_m_max_298 = 1.7;
                Q_10_A_m = 2.0;
                T_1_A_m = 286.0;
                T_2_A_m = 311.0;
            }
            double A_m_max = A_m_max_298 * Math.Pow(Q_10_A_m, (T_sk_0 - 298) / 10);
            A_m_max = A_m_max / ((1 + Math.Exp(0.3 * (T_1_A_m - T_sk_0))) * (1 + Math.Exp(0.3 * (T_sk_0 - T_2_A_m))));
            //if (A_m_max < 0.01 * A_m_max_298) // 避免太小超出程序能够储存的精度
            // {
            //  //   A_m_max = A_m_max_298 * 0.01;
            // }
            A_m = A_m_max * (1 - Math.Exp(-g_m * (C_i_0 - Gamma) / A_m_max));
        }

        public static void ETsw(double e_Avg, double Prss_Avg, double Ta_Avg, double rsc, double LAI, double Zh, double rss, double ustar, double wnd_spd, double As, double A, double VPD, out double E, out double T)
        {
            metalib(e_Avg, Prss_Avg, Ta_Avg, out double Cp, out double Psy, out double rou, out double sigma, out double delta);//get metro data

            //Calculate reference height of measurement (d0) and the roughness lengths(z0) governing the transfer of momentum [m]
            double z0;
            double X = SWHSMyConstants.cd * LAI;
            double d0 = 1.1 * Zh * Math.Log(1 + Math.Pow(X, 0.25));
            if (X < 0.2)
            {
                z0 = SWHSMyConstants.z0s + 0.3 * Zh * Math.Pow(X, 0.5);
            }
            else
            {
                z0 = 0.3 * Zh * ((1 - d0) / Zh);
            }

            //the eddy diffusion coefficient at the top of the canopy (Kh)
            double Kh = 0.4 * ustar * (Zh - d0);

            // canopy boundary layer resistance(rac) and the mean boundary layer resistance(rb), calcualted from the wind speed at the top of canopy (uh)and the characteristic leaf dimension(dl)
            double Uh = wnd_spd / (1 + Math.Log(SWHSMyConstants.Zu_m - Zh + 1));
            double rb = (100 / SWHSMyConstants.Km) * (SWHSMyConstants.dl / Uh) / (1 - Math.Exp(-SWHSMyConstants.Km / 2));
            double rac = rb / (2 * LAI);

            //aerodynamic resistances ras and raa are calculated by integrating the eddy diffusion coefficients from the soil surface to the level of the preferred sink of momentum in the canopy [s/m]
            double raa = (1 / (0.4 * ustar)) * Math.Log(((SWHSMyConstants.Zu_m) - d0) / (Zh - d0)) + (Zh / ((SWHSMyConstants.Km) * Kh)) * (Math.Exp((SWHSMyConstants.Km) * (1 - (d0 + z0) / Zh)) - 1);
            double ras = (Zh * (Math.Exp(SWHSMyConstants.Km)) / ((SWHSMyConstants.Km) * Kh)) * (Math.Exp((-(SWHSMyConstants.Km) * (SWHSMyConstants.z0s)) / Zh) - Math.Exp(-(SWHSMyConstants.Km) * ((d0 + z0) / Zh)));


            //Two source SW model calculation
            double Rc = (delta + Psy) * rac + Psy * rsc;
            double Rs = (delta + Psy) * ras + Psy * rss;
            double Ra = (delta + Psy) * raa;
            double wc = 1 / (1 + Rc * Ra / (Rs * (Rc + Ra)));
            double ws = 1 / (1 + Rs * Ra / (Rc * (Rs + Ra)));
            double PMc = (delta * A + (rou * Cp * VPD - delta * rac * As) / (raa + rac)) / (delta + Psy * (1 + rsc / (raa + rac)));
            double PMs = (delta * A + (rou * Cp * VPD - delta * ras * (A - As)) / (raa + ras)) / (delta + Psy * (1 + rss / (raa + ras)));
            //T = wc * PMc;
            // E = ws * PMs;

            double ET = wc * PMc + ws * PMs;
            double VPD0 = VPD + (delta * A - (delta + Psy) * ET) * raa / (rou * Cp);
            E = (delta * As + rou * Cp * VPD0 / ras) / (delta + Psy * (1 + rss / ras));
            T = (delta * (A - As) + rou * Cp * VPD0 / rac) / (delta + Psy * (1 + rsc / rac));

        }

        public static void metalib(double e, double p, double Ta_Avg, out double Cp, out double Psy, out double rou, out double sigma, out double delta)
        {
            Cp = 0.24 * 4185.5 * (1 + 0.8 * (0.622 * e / (p - e)));//  [J kg - 1C - 1],
            Psy = 0.000665 * p;// Psy psychrometic constant[KPaC - 1]
            rou = 1.293 * (273.15 / (Ta_Avg + 273.15)) * (p / 101.325) * (1 - 0.378 * (e / p)); // air density[kgm - 3]
            sigma = 5.67 * Math.Pow(10, -8.0);
            delta = 4098 * (0.6108 * Math.Exp(17.27 * Ta_Avg / (Ta_Avg + 237.3))) / Math.Pow(Ta_Avg + 237.3, 2);// slope of the saturated wapor-temperature curve[kPaC - 1]
        }


        public static void Tc_Taylor_Expansion_theory(double Ta_Avg, double Rh_Avg, double rsc, double Rav, double T, double P, out double Tc)
        {
            double ea_air = 0.6108 * Math.Exp(17.27 * Ta_Avg / (Ta_Avg + 237.3)) * Rh_Avg; // Kpa
            double esat_air = 0.6108 * Math.Exp(17.27 * Ta_Avg / (Ta_Avg + 237.3));// Kpa
            metalib(ea_air, P, Ta_Avg, out double Cp, out double Psy, out double rou, out double sigma, out double delta);// Psy = P * Cp / 0.622lamda
            double diff_eas = -(1527 * Math.Exp((1727 * Ta_Avg) / (100 * (Ta_Avg + 2373 / 10))) * ((1727 * Ta_Avg) / (100 * Math.Pow(Ta_Avg + 2373 / 10, 2)) - 1727 / (100 * (Ta_Avg + 2373 / 10)))) / 2500;//水汽压函数的导数在Ta处的值
            double gw = 1 / (Rav + rsc);
            double rhoa = 1.293 * 273.15 / (273.15 + Ta_Avg) * P / 101.325 * (1 - 0.378 * ea_air / P);
            double DD = T * Psy / (Cp * rhoa * gw);
            double D = esat_air - ea_air;
            Tc = (DD - D) / diff_eas + Ta_Avg;
            Tc = Math.Min(Math.Max(Tc, -25), 50);//避免叶片温度过高不符合实际情况
        }

        public static void DE_nonflooding(double Ta_Avg, double Ts, double es, double RH, double DSWO, double DO, out double Delta_E_O)
        {
            double Tak = Ta_Avg + 273.15;
            double Tsk = Ts + 273.15;
            double Delta_O_surface = DSWO;
            double ew = 0.611 * Math.Exp(17.3 * Ts / (Ts + 237.3));
            double RH1 = RH * (es / ew);
            double alpha_O = 1 / (Math.Exp(1137 / (Tsk * Tsk) - 0.4156 / Tsk - 0.002067));
            double AK_0 = SWHSMyConstants.AK_0;
            double Aeq = (1 - alpha_O) * 1000;
            Delta_E_O = (alpha_O * Delta_O_surface - RH1 * DO - Aeq - (1 - RH1) * AK_0) / ((1 - RH1) + 0.001 * ((1 - RH1) * AK_0));
        }

        //用HHMM模型内部数据尽可能计算SW模型需要的输入数据和参数
        public static void SWinput(double dz, int coni, int layernum, int rocknum, int[] cellsoiltype, double[] soilwater, double[] soilT, double[] kssoil, double z0, double d, double z, double u, double Rn_avg, ref double theta_2, ref double Gs_avg, ref double ustar)
        {
            //求土壤层含水率平均值（假设根区土壤含水率 = 土壤层含水率平均值）
            int count = 0;
            for (int li = 0; li < layernum; li++)
            {
                int st = cellsoiltype[coni + li];
                if (st < rocknum - 1)
                {
                    theta_2 += soilwater[coni + li];
                    count += 1;
                }
            }
            theta_2 /= count;

            ////求地表热通量（假设地表热通量 = 表层土壤与下层土壤之间温度传导的热量，忽略表层土壤热储量变化）
            //Gs_avg = (kssoil[coni] + kssoil[coni + 1]) / 2 * (soilT[coni] - soilT[coni + 1]) / dz;
            Gs_avg = 0.2 * Rn_avg;//用0.2倍净辐射简单估计地表热通量

            //求摩擦风速
            ustar = u * SWHSconst.VONKRM / Math.Log((z - d) / z0);
        }

    }
}
