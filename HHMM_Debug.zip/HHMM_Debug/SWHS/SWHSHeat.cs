﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace HHMM
{
    public class SWHSHeat
    {
        /// <summary>
        /// 土壤热量计算
        /// </summary>
        /// <param name="HHvar"></param>
        /// <param name="TVvar"></param>
        /// <param name="Timestep"></param>
        public static void Soilheatcal(HHMMvar HHvar, SWHSvar TVvar, double Timestep)
        {
            Cscal(HHvar, TVvar.waterphas.VLCDT, TVvar.icephas.VICDT, ref TVvar.heatphas.Cssoil);//土壤热容量计算
            Kscal(HHvar, TVvar.waterphas.VLCDT, TVvar.icephas.VICDT, ref TVvar.heatphas.Kssoil);//土壤热传导计算
            Soilheatupdate(HHvar.cuboidnum, TVvar.Cellx, TVvar.Celly, TVvar.Cellz, Timestep, TVvar.cellsize.celltopo, TVvar.heatphas.Kssoil, TVvar.waterphas.K, TVvar.heatphas.Cssoil, ref TVvar.waterphas.C, TVvar.waterphas.VLCDT, TVvar.waterphas.VLC, TVvar.waterphas.MATDT, TVvar.waterphas.MAT, TVvar.heatphas.TSDT, TVvar.heatphas.TS, TVvar.icephas.VICDT, TVvar.icephas.VIC, TVvar.icephas.ICESDT, TVvar.icephas.ICES, TVvar.mumpsSWHS.EMatrixadd, TVvar.mumpsSWHS.EnergBaadd, ref TVvar.mumpsSWHS.a, ref TVvar.mumpsSWHS.rhs, HHvar.cellsoiltype, HHvar.soilwaterpara.soilwas, HHvar.soilwaterpara.soilwar, HHvar.soilwaterpara.avg, HHvar.soilwaterpara.m, HHvar.soilwaterpara.n, HHvar.soilheatpara.csmine);//土壤热量运移
        }
        /// <summary>
        /// 矿物质热传导计算
        /// </summary>
        /// <param name="sand"></param>
        /// <param name="silt"></param>
        /// <param name="clay"></param>
        /// <param name="Ksmine"></param>
        public static void Ksminecal(double sand, double silt, double clay, out double ksmine)
        {
            ksmine = 2.3;
        }
        /// <summary>
        /// 矿物质热容量计算
        /// </summary>
        /// <param name="sand"></param>
        /// <param name="silt"></param>
        /// <param name="clay"></param>
        /// <param name="Csmine"></param>
        public static void Csminecal(double sand, double silt, double clay, out double csmine)
        {
            csmine = 2310;
        }//计算矿物质热容量

        /// <summary>
        /// 土壤热容量计算
        /// </summary>
        /// <param name="soilwas"></param>
        /// <param name="mineden"></param>
        /// <param name="Csmine"></param>
        /// <param name="soilwa"></param>
        /// <param name="waterden"></param>
        /// <param name="watercap"></param>
        /// <param name="Airden"></param>
        /// <param name="AirCs"></param>
        /// <param name="Cs"></param>
        public static void Cellcscal(double soilwas, double soilwa, double soilice, double mineden, double Csmine, double waterden, double watercap, double Airden, double AirCs, double iceden, double icecap, out double Cssoil)
        {

            Cssoil = (1.0 - soilwas) * mineden * Csmine + soilwa * waterden * watercap + soilice * iceden * icecap + Math.Max(0.0, (soilwas - soilwa - soilice)) * Airden * AirCs;//矿物+水+冰+空气
        }

        /// <summary>
        /// 土壤热容量计算
        /// </summary>
        /// <param name="HHvar"></param>
        /// <param name="soilwa"></param>
        /// <param name="soilice"></param>
        /// <param name="Cssoil"></param>
        public static void Cscal(HHMMvar HHvar, double[] soilwa, double[] soilice, ref double[] Cssoil)
        {
            for (int ic = 0; ic < HHvar.cuboidnum; ic++)
            {
                int ct = HHvar.cellsoiltype[ic];
                Cellcscal(HHvar.soilwaterpara.soilwas[ct], soilwa[ic], soilice[ic], HHvar.soilheatpara.minedensity[ct], HHvar.soilheatpara.csmine[ct], SWHSconst.RHOL, SWHSconst.CL, SWHSconst.RHOA, SWHSconst.CA, SWHSconst.RHOI, SWHSconst.CI, out Cssoil[ic]);
            }
        }

        /// <summary>
        /// 土壤热传导计算
        /// </summary>
        public static void Cellkscal(double soilwas, double soilwa, double soilice, double ksmine, double TKL, double TKA, double TKI, double ksmineweight, double TKLweight, double TKAweight, double TKIweight, out double kssoil)
        {
            //kssoil = 1.40;

            kssoil = (soilwa * TKLweight * TKL + soilice * TKIweight * TKI + (1 - soilwas) * ksmineweight * ksmine + Math.Max(0.0, (soilwas - soilwa - soilice)) * TKAweight * TKA) / (soilwa * TKLweight + soilice * TKIweight + (1 - soilwas) * ksmineweight + Math.Max(0.0, (soilwas - soilwa)) * TKAweight);//水+冰+矿物+空气
        }

        /// <summary>
        /// 土壤热传导计算
        /// </summary>
        /// <param name="HHvar"></param>
        /// <param name="soilwa"></param>
        /// <param name="soilice"></param>
        /// <param name="Kh"></param>
        public static void Kscal(HHMMvar HHvar, double[] soilwa, double[] soilice, ref double[] Kh)
        {
            for (int ic = 0; ic < HHvar.cuboidnum; ic++)
            {
                int ct = HHvar.cellsoiltype[ic];
                Cellkscal(HHvar.soilwaterpara.soilwas[ct], soilwa[ic], soilice[ic], HHvar.soilheatpara.ksmine[ct], SWHSconst.TKL, SWHSconst.TKA, SWHSconst.TKI, SWHSconst.ksmineweight, SWHSconst.TKLweight, SWHSconst.TKAweight, SWHSconst.TKIweight, out Kh[ic]);
            }
        }

        /// <summary>
        /// 土壤热量计算
        /// </summary>
        /// <param name="cuboidnum"></param>
        /// <param name="xlen"></param>
        /// <param name="ylen"></param>
        /// <param name="zlen"></param>
        /// <param name="dt"></param>
        /// <param name="celltopo"></param>
        /// <param name="Kh"></param>
        /// <param name="Kw"></param>
        /// <param name="Cssoil"></param>
        /// <param name="Cwsoil"></param>
        /// <param name="VLCDT"></param>
        /// <param name="VLC"></param>
        /// <param name="MATDT"></param>
        /// <param name="MAT"></param>
        /// <param name="TSDT"></param>
        /// <param name="TS"></param>
        /// <param name="VICDT"></param>
        /// <param name="VIC"></param>
        /// <param name="ICESDT"></param>
        /// <param name="ICES"></param>
        /// <param name="Ematrixadd"></param>
        /// <param name="Energyadd"></param>
        /// <param name="a"></param>
        /// <param name="rhs"></param>
        /// <param name="cellsoiltype"></param>
        /// <param name="soilwas"></param>
        /// <param name="soilwar"></param>
        /// <param name="avg"></param>
        /// <param name="m"></param>
        /// <param name="n"></param>
        /// <param name="RHOB"></param>        
        public static void Soilheatupdate(int cuboidnum, double xlen, double ylen, double zlen, double dt, int[][] celltopo, double[] Kh, double[] Kw, double[] Cssoil, ref double[] Cwsoil, double[] VLCDT, double[] VLC, double[] MATDT, double[] MAT, double[] TSDT, double[] TS, double[] VICDT, double[] VIC, int[] ICESDT, int[] ICES, double[] Ematrixadd, double[] Energyadd, ref double[] a, ref double[] rhs, int[] cellsoiltype, double[] soilwas, double[] soilwar, double[] avg, double[] m, double[] n, double[] RHOB)
        {
            int ici, ct, cti;
            int an = 0, li = 0;
            double ltemp = 0.0;
            //double Ts=0.0,Tsdt=0.0;
            //double DLDT = 0.0, DLDTDT = 0.0;
            for (int ic = 0; ic < cuboidnum; ic++)
            {
                ct = cellsoiltype[ic];
                ltemp = 0;
                rhs[ic] = Cssoil[ic] / dt * (TSDT[ic] - TS[ic]) - Energyadd[ic] / zlen; // W/m^3               
                if (celltopo[ic][3] >= 0)
                {
                    ici = celltopo[ic][3];
                    a[an] = ((Kh[ic] + Kh[ici]) / 2 / xlen + SWHSconst.RHOL * SWHSconst.CL * Math.Max(0.0, ((Kw[ic] + Kw[ici]) / 2 * (MATDT[ici] - MATDT[ic]) / xlen))) / xlen;
                    rhs[ic] += -1 * a[an] * (TSDT[ici] - TSDT[ic]);
                    ltemp += -1 * a[an];
                    an += 1;
                }
                if (celltopo[ic][4] >= 0)
                {
                    ici = celltopo[ic][4];
                    a[an] = ((Kh[ic] + Kh[ici]) / 2 / ylen + SWHSconst.RHOL * SWHSconst.CL * Math.Max(0.0, ((Kw[ic] + Kw[ici]) / 2 * (MATDT[ici] - MATDT[ic]) / ylen))) / ylen;
                    rhs[ic] += -1 * a[an] * (TSDT[ici] - TSDT[ic]);
                    ltemp += -1 * a[an];
                    an += 1;
                }
                if (celltopo[ic][5] >= 0)
                {
                    ici = celltopo[ic][5];
                    a[an] = ((Kh[ic] + Kh[ici]) / 2 / zlen + SWHSconst.RHOL * SWHSconst.CL * Math.Max(0.0, ((Kw[ic] + Kw[ici]) / 2 * ((MATDT[ici] - MATDT[ic]) / zlen + 1)))) / zlen;
                    rhs[ic] += -1 * a[an] * (TSDT[ici] - TSDT[ic]);
                    ltemp += -1 * a[an];
                    an += 1;
                }
                li = an;
                ltemp += -Cssoil[ic] / dt;
                an += 1;

                if (celltopo[ic][6] >= 0)
                {
                    ici = celltopo[ic][6];
                    a[an] = ((Kh[ic] + Kh[ici]) / 2 / zlen + SWHSconst.RHOL * SWHSconst.CL * Math.Max(0.0, ((Kw[ic] + Kw[ici]) / 2 * ((MATDT[ici] - MATDT[ic]) / zlen - 1)))) / zlen;
                    rhs[ic] += -1 * a[an] * (TSDT[ici] - TSDT[ic]);
                    ltemp += -1 * a[an];
                    an += 1;
                }
                if (celltopo[ic][7] >= 0)
                {
                    ici = celltopo[ic][7];
                    a[an] = ((Kh[ic] + Kh[ici]) / 2 / ylen + SWHSconst.RHOL * SWHSconst.CL * Math.Max(0.0, ((Kw[ic] + Kw[ici]) / 2 * (MATDT[ici] - MATDT[ic]) / ylen))) / ylen;
                    rhs[ic] += -1 * a[an] * (TSDT[ici] - TSDT[ic]);
                    ltemp += -1 * a[an];
                    an += 1;

                }
                if (celltopo[ic][8] >= 0)
                {
                    ici = celltopo[ic][8];
                    a[an] = ((Kh[ic] + Kh[ici]) / 2 / xlen + SWHSconst.RHOL * SWHSconst.CL * Math.Max(0.0, ((Kw[ic] + Kw[ici]) / 2 * (MATDT[ici] - MATDT[ic]) / xlen))) / xlen;
                    rhs[ic] += -1 * a[an] * (TSDT[ici] - TSDT[ic]);
                    ltemp += -1 * a[an];
                    an += 1;
                }
                a[li] = ltemp + Ematrixadd[ic] / zlen;
                //if (ICESDT[ic] != 1)
                //{
                //    continue;
                //}
                //else
                //{
                //    if (ICES[ic] == 1)
                //    {
                //        Ts = TS[ic] + SWHSconst.Tk0;
                //    }
                //    else
                //    {
                //        Ts = SWHSconst.Tk0 * SWHSconst.LF / SWHSconst.G / (SWHSconst.LF / SWHSconst.G - MAT[ic]);
                //    }
                //    Tsdt = SWHSconst.Tk0 + TSDT[ic];
                //    DLDTDT = SWHSIce.FSLOPE(TSDT[ic], VLCDT[ic], MATDT[ic], soilwar[ct], avg[ct], m[ct], n[ct], RHOB[ct]);//冻结期间含水率对于温度的变化
                //    DLDT = SWHSIce.FSLOPE(TS[ic], VLC[ic], MAT[ic], soilwar[ct], avg[ct], m[ct], n[ct], RHOB[ct]);
                //   SWHSWater.CellSoilwatcap(MATDT[ic], VLCDT[ic], soilwas[ct], soilwar[ct], avg[ct], m[ct], n[ct], VICDT[ic],ref Cwsoil[ic]);//求解比水容量C
                //    a[li] += SWHSconst.RHOL * SWHSconst.LF * ((1 / dt * (DLDT + DLDT) / 2) + q0 * DLDTDT / Cwsoil[ic]);
                //}
            }
        }
    }
}
