﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CSparse;
using CSparse.Storage;
using CSparse.Double.Factorization;
using CSparse.IO;
using CSparse.Ordering;
using CSparse.Double;

namespace HHMM
{
    /// <summary>
    /// 方程求解
    /// </summary>
    public class SWHSFun
    {
        public static CompressedColumnStorage<double> spaccell = null;
        public static double[][] modelcell = null;
        public static double[] cellord = null;

        /// <summary>
        /// 创建稀疏矩阵
        /// </summary>
        /// <param name="TVvar"></param>
        public static void CSparsecreate(SWHSvar TVvar)
        {
            spaccell = null;
            modelcell = new double[TVvar.nnum][];
            for (int i = 0; i < TVvar.nnum; i++)
            {
                modelcell[i] = new double[TVvar.nnum];
            }
            for (int i = 0; i < TVvar.nznum; i++)
            {
                modelcell[TVvar.mumpsSWHS.irn[i]][TVvar.mumpsSWHS.jcn[i]] = i + 1;
            }
            spaccell = Converter.ToCompressedColumnStorage(modelcell);//列主序压缩稀疏矩阵
            cellord = (double[])spaccell.Values.Clone();
        }


        public static void SWHSheatcal(HHMMvar HHvar, SWHSvar TVvar, double Timestep, ref double[] hxc)
        {
            SWHSWater.Gq2k(HHvar, TVvar.waterphas.VLCDT, TVvar.icephas.VICDT, ref TVvar.waterphas.K);//求解土壤不饱和导水率K
            SWHSHeat.Soilheatcal(HHvar, TVvar, Timestep);
            hxc = new double[TVvar.nnum];
            for (int i = 0; i < TVvar.nznum; i++)
            {
                spaccell.Values[i] = TVvar.mumpsSWHS.a[(int)cellord[i] - 1];
            }
            if (TVvar.Nummethod == 1)
            {
                var lu = SparseLU.Create(spaccell, ColumnOrdering.MinimumDegreeAtPlusA, 1.0);
                lu.Solve(TVvar.mumpsSWHS.rhs, hxc);
            }
            else
            {
                var qr = SparseQR.Create(spaccell, ColumnOrdering.MinimumDegreeAtA);
                qr.Solve(TVvar.mumpsSWHS.rhs, hxc);
            }
        }

        public static void SWHSwatercal(string Richardmethod, HHMMvar HHvar, SWHSvar TVvar, double Timestep, ref double[] wxc)
        {
            SWHSWater.Soilwatercal(Richardmethod, HHvar, TVvar, Timestep);
            for (int i = 0; i < TVvar.nznum; i++)
            {
                spaccell.Values[i] = TVvar.mumpsSWHS.a[(int)cellord[i] - 1];
            }

            if (TVvar.Nummethod == 1)
            {
                var lu = SparseLU.Create(spaccell, ColumnOrdering.MinimumDegreeAtPlusA, 1.0);
                lu.Solve(TVvar.mumpsSWHS.rhs, wxc);
            }
            else
            {
                var qr = SparseQR.Create(spaccell, ColumnOrdering.MinimumDegreeAtA);
                qr.Solve(TVvar.mumpsSWHS.rhs, wxc);
            }
        }

        public static void SWHSsolutecal(HHMMvar HHvar, SWHSvar TVvar, double Timestep)
        {
            for (int soli = 0; soli < HHvar.solutenum; soli++)
            {
                for (int ic = 0; ic < HHvar.cuboidnum; ic++)
                {
                    TVvar.solutephas.soilsolunew[soli][ic] = TVvar.solutephas.soilsolunew[soli][ic] * TVvar.waterphas.VLCDT[ic] / (TVvar.waterphas.VLCDT[ic] + TVvar.waterphas.OUTWADT[ic] / (TVvar.Cellx * TVvar.Celly * TVvar.Cellz) + TVvar.waterphas.OUTWA2DT[ic] / (TVvar.Cellx * TVvar.Celly * TVvar.Cellz) + TVvar.waterphas.OUTE[ic] / (TVvar.Cellx * TVvar.Celly * TVvar.Cellz));//特殊处理

                }
                SWHSSolute.Soilsolute(soli, HHvar, TVvar, Timestep);
                double[] sxc = new double[TVvar.nnum];
                for (int i = 0; i < TVvar.nznum; i++)
                {
                    spaccell.Values[i] = TVvar.mumpsSWHS.a[(int)cellord[i] - 1];
                }

                if (TVvar.Nummethod == 1)
                {
                    var lu = SparseLU.Create(spaccell, ColumnOrdering.MinimumDegreeAtPlusA, 1.0);
                    lu.Solve(TVvar.mumpsSWHS.rhs, sxc);
                }
                else
                {
                    var qr = SparseQR.Create(spaccell, ColumnOrdering.MinimumDegreeAtA);
                    qr.Solve(TVvar.mumpsSWHS.rhs, sxc);
                }

                for (int ic = HHvar.startcell; ic < HHvar.endcell; ic++)
                {

                    TVvar.solutephas.soilsolunew[soli][ic] = sxc[ic];
                }
            }
        }
    }
}
