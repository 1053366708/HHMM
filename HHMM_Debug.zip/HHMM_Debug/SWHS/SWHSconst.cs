﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HHMM
{
    public class SWHSconst
    {
        public const double LF = 335000;     //冰熔解热 J/Kg
        public const double LV = 2500000;    //汽化 J/Kg
        public const double LS = 2835000;
        public const double G = 9.81;           //重力加速度  m2/s
        public const double UGAS = 8.3143;      //8.3143J/mole-k, universal gas constant
        public const double VONKRM = 0.4;  // Von Karman's constant
        public const double VDIFF = 0.0000212;  // 
        public const double P0 = 101300;    //标准大气压

        public const double RHOM = 2600;
        public const double RHOL = 1000;        //水的密度 kg m-3
        public const double RHOA = 1.25;       //空气密度 kg m-3
        public const double RHOI = 920;    //冰的密度kgm-3
        public const double RHOMM = 2600;

        public const double TKL = 0.57;  //水的导热 wm-1c-1
        public const double TKI = 2.20;     //冰的导热 wm-1c-1
        public const double TKA = 0.025;   //空气的导热 wm-1c-1
        public const double TKR = 0.050;
        public const double TKSA = 8.80;
        public const double TKSI = 2.92;
        public const double TKCL = 2.92;
        public const double TKOM = 0.25;

        public const double CM = 900;
        public const double COM = 1920;
        public const double CL = 4200;//水的比热容Jkg-1C-1
        public const double CI = 2100;//冰的比热容Jkg-1C-1
        public const double CA = 1006;//空气的比热容Jkg-1C-1
        public const double CV = 1860;
        public const double CR = 1900;

        public const double SOLCON = 1360; //w/m2 solar constant
        public const double STEFAN = 5.6697 / 100000000;   //stefan常数，长波辐射计算W m-2 K-4

        public const double EMATM1 = 0.261;
        public const double EMATM2 = 0.000777;
        public const double EMITC = 1.0;
        public const double EMITR = 1.0;
        public const double EMITSP = 1.0;
        public const double EMITS = 1.0;

        public const double DIFATM = 0.76;
        public const double DIFRES = 0.667;
        public const double SNOCOF = 0.0;
        public const double SNOEXP = 1.0;

        public const double VAPCOF = 33.0;
        public const double VAPEXP = 50.0;

        public const double RESMA = -53.72;
        public const double RESMB = 1.32;
        public const double RESMC = 0.0;
        public const double RESTKA = 0.007;
        public const double RESTKB = 4.0;

        public const double G1 = 0.16;
        public const double G2 = 0.0;
        public const double G3 = 110.0;
        public const double EXTSP = 1.77;
        public const double TKSPA = 0.021;
        public const double TKSPB = 2.51;
        public const double TKSPEX = 2.0;
        public const double VDIFSP = 0.00009;
        public const double VAPSPX = 14.0;

        public const double CLAG1 = 10.0;//最大可能滞后，h
        public const double CLAG2 = 1.0;// cm^-1  经验系数
        public const double CLAG3 = 5.0;// h
        public const double CLAG4 = 450.0;
        public const double PLWMAX = 0.1;//积雪最大体积含水率  m3/m3
        public const double PLWDEN = 200.0;//积雪最小体积含水率对应的雪密度 kg/m3
        public const double PLWHC = 0.03;//积雪最小体积含水率  m3/m3
        public const double THICK = 0.025;
        public const double CTHICK = 0.050;

        public const double CMET1 = 0.010;
        public const double CMET2 = 21.0;
        public const double CMET3 = 0.010;
        public const double CMET4 = 0.040;
        public const double CMET5 = 2.000;
        public const double SNOMAX = 150.0;

        public const double ksmineweight = 1.0;
        public const double TKLweight = 1.0;
        public const double TKAweight = 1.0;
        public const double TKIweight = 1.0;

        public const double Tk0 = 273.16; // Kevin degree





        public const double Dtmin = 0.5;   //用以标出最冷时间
        public const double Mw = 0.018;//0.018kg/mole, molecular weight of water

        public const double Htoler = 0.01;   //变化允许值

        public const double RadDegTrans = 180.0 / Math.PI;
        public const double DegRadTrans = Math.PI / 180.0;

        public const double WT = 0.0;         //前时刻步长权重
        public const double WDT = 1.0;        //后时刻步长权重  

        public const double LWcon = 1.001; //含水率限制系数
        public const double ICEstep = 0.00001;// 冻融最大变化量
        public const double WAstep = 0.0001;//含水率最大传输量，用于热量对流项限制
                                            // public const double LWtempo = 0.90;//含水率限制临时值，如果可以改的话用1.0/LWcon代替

        public const double CO2 = 688;//大气二氧化碳浓度mg/m3
        public const double Timestep = 10;



    }
}
