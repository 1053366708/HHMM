﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace HHMM
{
    public class SWHSSolute
    {
        /// <summary>
        /// 对每一种溶质进行计算
        /// </summary>
        /// <param name="soilsolutelist">第几种溶质</param>
        /// <param name="HHvar">HHmodel参数</param>
        /// <param name="TVvar">TVmodel参数</param>
        /// <param name="Timestep">时间步长</param>
        public static void Soilsolute(int soilsolutelist, HHMMvar HHvar, SWHSvar TVvar, double Timestep)
        {
            Soilsoluteupdate(HHvar.cuboidnum, TVvar.Cellx, TVvar.Celly, TVvar.Cellz, SWHSconst.RHOL, HHvar.soilheatpara.minedensity, HHvar.soilsolutepara.dh[soilsolutelist], HHvar.soilsolutepara.dm[soilsolutelist], HHvar.soilsolutepara.kcq[soilsolutelist], HHvar.cellsoiltype, Timestep, TVvar.cellsize.celltopo, TVvar.waterphas.K, TVvar.waterphas.MATDT, TVvar.waterphas.VLC, TVvar.waterphas.VLCDT, TVvar.solutephas.soilsolunew[soilsolutelist], ref TVvar.mumpsSWHS.a, ref TVvar.mumpsSWHS.rhs);
        }


        /// <summary>
        /// 土壤溶质计算，计算线性方程组的左右两侧参数，从而求解土壤溶质浓度
        /// </summary>
        /// <param name="cuboidnum">计算网格总的数目</param>
        /// <param name="xlen">网格x长度</param>
        /// <param name="ylen">网格y长度</param>
        /// <param name="zlen">网格z长度</param>
        /// <param name="waterden">水密度</param>
        /// <param name="buldden">某种类型土壤的密度</param>
        /// <param name="dh">水动力弥散系数</param>
        /// <param name="dm">分子扩散系数</param>
        /// <param name="KcQ">土壤溶质吸附比</param>
        /// <param name="cellsoiltype">土壤类型</param>
        /// <param name="dt">时间</param>
        /// <param name="celltopo"></param>
        /// <param name="Kw">土壤导水率</param>
        /// <param name="soilhnew">土壤水势</param>
        /// <param name="soilwater">土壤水哈量</param>
        /// <param name="soilcold">土壤溶质浓度</param>
        /// <param name="a">线性方程组左边系数</param>
        /// <param name="rhs">线性方程组右边系数</param>
        public static void Soilsoluteupdate(int cuboidnum, double xlen, double ylen, double zlen, double waterden, double[] buldden, double[] dh, double[] dm, double[] KcQ, int[] cellsoiltype, double dt, int[][] celltopo, double[] Kw, double[] soilhnew, double[] soilwaterold, double[] soilwaternew, double[] soilcold, ref double[] a, ref double[] rhs)
        {
            int ici;
            int an = 0, li = 0;
            double q = 0;
            double ltemp = 0;
            int ct0, ct1;
            for (int ic = 0; ic < cuboidnum; ic++)
            {
                ct0 = cellsoiltype[ic];
                ltemp = 0;
                if (celltopo[ic][3] >= 0)
                {
                    ici = celltopo[ic][3];
                    ct1 = cellsoiltype[ici];
                    q = ((Kw[ic] + Kw[ici]) / 2 * (soilhnew[ici] - soilhnew[ic]) / xlen);
                    a[an] = q * SCindex(q, 1) / xlen + ((dh[ct0] + dh[ct1]) / 2 + (dm[ct0] + dm[ct1]) / 2) / xlen / xlen;
                    ltemp += q * SCindex(q, 0) / xlen - ((dh[ct0] + dh[ct1]) / 2 + (dm[ct0] + dm[ct1]) / 2) / xlen / xlen;
                    an += 1;
                }

                if (celltopo[ic][4] >= 0)
                {
                    ici = celltopo[ic][4];
                    ct1 = cellsoiltype[ici];
                    q = ((Kw[ic] + Kw[ici]) / 2 * (soilhnew[ici] - soilhnew[ic]) / ylen);
                    a[an] = q * SCindex(q, 1) / ylen + ((dh[ct0] + dh[ct1]) / 2 + (dm[ct0] + dm[ct1]) / 2) / ylen / ylen;
                    ltemp += q * SCindex(q, 0) / ylen - ((dh[ct0] + dh[ct1]) / 2 + (dm[ct0] + dm[ct1]) / 2) / ylen / ylen;
                    an += 1;
                }

                if (celltopo[ic][5] >= 0)
                {
                    ici = celltopo[ic][5];
                    ct1 = cellsoiltype[ici];
                    q = ((Kw[ic] + Kw[ici]) / 2 * ((soilhnew[ici] - soilhnew[ic]) / zlen + 1));
                    a[an] = q * SCindex(q, 1) / zlen + ((dh[ct0] + dh[ct1]) / 2 + (dm[ct0] + dm[ct1]) / 2) / zlen / zlen;
                    ltemp += q * SCindex(q, 0) / zlen - ((dh[ct0] + dh[ct1]) / 2 + (dm[ct0] + dm[ct1]) / 2) / zlen / zlen;
                    an += 1;
                }

                li = an;
                ltemp += -1 * buldden[ct0] / waterden / dt * (waterden / buldden[ct0] * soilwaternew[ic] + KcQ[ct0]);
                an += 1;
                if (celltopo[ic][6] >= 0)
                {
                    ici = celltopo[ic][6];
                    ct1 = cellsoiltype[ici];
                    q = ((Kw[ic] + Kw[ici]) / 2 * ((soilhnew[ici] - soilhnew[ic]) / zlen - 1));
                    a[an] = q * SCindex(q, 1) / zlen + ((dh[ct0] + dh[ct1]) / 2 + (dm[ct0] + dm[ct1]) / 2) / zlen / zlen;
                    ltemp += q * SCindex(q, 0) / zlen - ((dh[ct0] + dh[ct1]) / 2 + (dm[ct0] + dm[ct1]) / 2) / zlen / zlen;
                    an += 1;
                }

                if (celltopo[ic][7] >= 0)
                {
                    ici = celltopo[ic][7];
                    ct1 = cellsoiltype[ici];
                    q = ((Kw[ic] + Kw[ici]) / 2 * ((soilhnew[ici] - soilhnew[ic]) / ylen));
                    a[an] = q * SCindex(q, 1) / ylen + ((dh[ct0] + dh[ct1]) / 2 + (dm[ct0] + dm[ct1]) / 2) / ylen / ylen;
                    ltemp += q * SCindex(q, 0) / ylen - ((dh[ct0] + dh[ct1]) / 2 + (dm[ct0] + dm[ct1]) / 2) / ylen / ylen;
                    an += 1;
                }

                if (celltopo[ic][8] >= 0)
                {
                    ici = celltopo[ic][8];
                    ct1 = cellsoiltype[ici];
                    q = ((Kw[ic] + Kw[ici]) / 2 * ((soilhnew[ici] - soilhnew[ic]) / xlen));
                    a[an] = q * SCindex(q, 1) / xlen + ((dh[ct0] + dh[ct1]) / 2 + (dm[ct0] + dm[ct1]) / 2) / xlen / xlen;
                    ltemp += q * SCindex(q, 0) / xlen - ((dh[ct0] + dh[ct1]) / 2 + (dm[ct0] + dm[ct1]) / 2) / xlen / xlen;
                    an += 1;
                }
                a[li] = ltemp;
                rhs[ic] = -1 * buldden[ct0] / waterden / dt * (waterden / buldden[ct0] * soilwaterold[ic] + KcQ[ct0]) * soilcold[ic];
            }
        }

        /// <summary>
        /// 判断流向，进而分析溶质的变化的系数
        /// </summary>
        /// <param name="x"></param>
        /// <param name="m"></param>
        /// <returns></returns>
        public static int SCindex(double x, int m)
        {
            if (m == 1)
            {
                if (x > 0)
                    return 1;
                else
                    return 0;
            }
            else
            {
                if (x > 0)
                    return 0;
                else
                    return 1;
            }
        }

        public static void CGE(SWHSvar TVvar, HHMMvar HHvar, double deltain, double Timestep)
        {
            for (int i = HHvar.startcol; i < HHvar.endcol; i++)
            {
                for (int j = 0; j < HHvar.NYCELL; j++)
                {
                    if (HHvar.upfaceid[i][j] >= 0)
                    {

                        //蒸发通量同位素18O含量的计算

                        int coni = HHvar.conupfaceid[i][j];//有效网格的编号                       
                        double Evap = -TVvar.WaEndata.VFLUX[i][j] / SWHSconst.RHOL * Timestep * TVvar.Cellx * TVvar.Celly;//m3                        
                        double Ta = SWHSSurfcal.TADT + SWHSconst.Tk0;//大气温度（K）
                        double h = SWHSSurfcal.HUMDT;//大气相对湿度（0~1）                     
                        double M = 0.35041 * Math.Pow(10, 6) / Math.Pow(Ta, 3) - 1.6664 * Math.Pow(10, 3) / Math.Pow(Ta, 2) + 6.7123 / Ta - 7.685 / Math.Pow(10, 3);
                        double eqa = Math.Exp(M);//αeq
                        double eqe = (eqa - 1) * Math.Pow(10, 3);//εeq
                        double deltarain = (deltain - 1) * 1000;
                        double deltaA = (deltarain - eqe) / eqa;//大气环境同位素组成‰
                        double n = 0.5;// - 0.5 * (soilwas - soilwa) / (soilwas - soilwar);//气动参数
                        double ke = n * (1 - h) * (1 - 0.9859) * Math.Pow(10, 3);//0.9859表示含有氧18和氧16的水分子的扩散系数比值，其中n为气动参数，土壤是0.65~1，需要调整（根据土壤汗含水量调整）
                        double[] soilsoluold = new double[HHvar.solutenum];
                        double[] soilsolunew = new double[HHvar.solutenum];
                        double[] deltaE = new double[HHvar.solutenum];
                        for (int solu = 0; solu < HHvar.solutenum; solu++)
                        {
                            soilsoluold[solu] = TVvar.solutephas.soilsolunew[solu][coni];//初始浓度绝对值mol/kg
                            double deltaL = (soilsoluold[solu] - 1) * 1000;//蒸发前相对值‰
                            deltaE[solu] = (eqa * deltaL - h * deltaA - (eqe + ke)) / ((1 - h) + ke / 1000);//蒸发蒸汽的同位素组成相对值‰
                            soilsolunew[solu] = deltaE[solu] / 1000 + 1;//蒸发绝对值浓度mol/kg
                            TVvar.solutephas.soilsolunew[solu][coni] = (TVvar.solutephas.soilsolunew[solu][coni] * TVvar.waterphas.VLCDT[coni] * TVvar.Cellx * TVvar.Celly * TVvar.Cellz - soilsolunew[solu] * Evap) / (TVvar.waterphas.VLCDT[coni] * TVvar.Cellx * TVvar.Celly * TVvar.Cellz);
                            TVvar.SoluteCG[solu] += soilsolunew[solu] * Evap * SWHSconst.RHOL;//分馏出去的溶质累积量mol

                        }
                    }
                }
            }
        }
    }
}
