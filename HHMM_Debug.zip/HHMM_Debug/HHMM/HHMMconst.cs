﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HHMM
{
    public class HHMMconst
    {
        public const int SecondPerHour = 3600;        //每个小时的秒数
        public const int HourPerDay = 24;             //每天的小时数
    }
}
