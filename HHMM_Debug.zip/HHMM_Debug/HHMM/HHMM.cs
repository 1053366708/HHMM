﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//考虑地表二维浅水方程、垂向分层入渗和三维土壤水热盐冰的水文水动力系统(HHFS)的一个重要模型，命名为HHMM（Hydrology Hydraulic Module Modeling），预期对小流域的气象-水文-地下水模拟、山坡水文过程阐述、景观水利设计等提供支撑。其三维模拟及目前正在完善的三维显示具有较好的水动力效果。模型耦合了二维浅水模型（SWOF）,将其修改为c#语言，实现了其一阶和二阶功能；参考SHAW模型等相关土壤水热盐模型，编写了SWHS（soil-water-heat-solute）模型；地表水的入渗参考SHAW模型的相关方案，编写了GMIM（Green-Ampt Infiltrate Model）；为了提高计算效率，上述三者模型在时间上同步，根据自身的动力学特征基于不同时间步长开展预算，在固定时间节点耦合。
//HHMM (Hydrology Hydraulic Module Modeling) is an important model of hydrology and hydrodynamic force system (HHFS) considering surface 2D shallow water equation, vertical layered infiltration and 3D soil-water-heat-solute-ice. The model couples with 2D shallow water model (SWOF), soil-water-heat-solute model (SWHS) and Green-Ampt Infiltrate Model (GMIM). SWOF is developed in C# language by referring to FullSWOF, and the first-order and second-order functions of FullSWOF are implemented. SWHS is developed by referring to SHAW model and other soil-water-heat-solute models. GMIM is developed by referring to infiltration scheme of surface water based on SHAW model.
namespace HHMM
{
    public class HHMM
    {
        static void Main(string[] args)
        {
            MPI.Environment.Run(ref args, comm =>
            {
                string prepath = @"..\Debug";//整体的文件路径/前处理前的文件路径
                int ranknum = comm.Size;//设置并行处理的核数，注意不要超过dem的列数
                if (comm.Rank == 0 & ranknum > 1) HHMMpre.HHpre(prepath, ranknum);//并行文件前处理

                comm.Barrier();
                string inputpath = @"..\" + comm.Rank;//输入文件路径
                if (ranknum == 1) inputpath = @"..\Debug";
                string outputpath = @"..\..\output\" + comm.Rank;//输出文件路径                

                HHMMvar HHvar = new HHMMvar(inputpath);//HHMM变量定义         
                HHMMinit.HHinit(HHvar, inputpath, comm);//HHMM变量初始化
                SWHSvar TVvar = new SWHSvar(HHvar);//TV变量定义
                SVCSvar SVvar = new SVCSvar(HHvar);//SW变量定义
                GMIMvar GMvar = new GMIMvar(HHvar);//GM变量定义     

                SWHSinit.TVinit(TVvar, HHvar, inputpath);//TV变量初始化
                SWHSTools.SUMDT(0, HHvar.NXCELL, HHvar.NYCELL, HHvar.upfaceid, TVvar.SNMatrix.NSP, 0, TVvar.WaEndata.VFLUX, TVvar.SNMatrix.QVSP, ref TVvar.SWSUMDT.TOPSNO, ref TVvar.SWSUMDT.EVAP1, ref TVvar.SWSUMDT.TQVSP);//初始化变量
                SVCSinit.SVinit(SVvar, HHvar, inputpath); //SV变量初始化
                SWHSRad.Aspectslopecal(HHvar.cellsize, HHvar.Tdemvalue);//坡度和坡向计算，用来进行空间辐射分析
                HHMMout.Concluresult(outputpath, HHvar, TVvar, SVvar, comm);

                if (comm.Size > 1)
                {
                    comm.Barrier();
                    HHMMtool.Sendreceive2D(comm, ref SVvar.h, HHvar.NXCELL, HHvar.NYCELL);
                    HHMMtool.Sendreceive2D(comm, ref SVvar.u, HHvar.NXCELL, HHvar.NYCELL);
                    HHMMtool.Sendreceive2D(comm, ref SVvar.v, HHvar.NXCELL, HHvar.NYCELL);
                    HHMMtool.Sendreceive1D(comm, ref TVvar.waterphas.VLC, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    HHMMtool.Sendreceive1D(comm, ref TVvar.waterphas.MAT, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    HHMMtool.Sendreceive1D(comm, ref TVvar.heatphas.TS, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    HHMMtool.Sendreceive1D(comm, ref TVvar.icephas.VIC, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    HHMMtool.Sendreceive1Dint(comm, ref TVvar.icephas.ICES, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    HHMMtool.Sendreceive1D(comm, ref TVvar.waterphas.OUTWA, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    HHMMtool.Sendreceive1D(comm, ref TVvar.waterphas.OUTWA2, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    HHMMtool.Sendreceive1D(comm, ref TVvar.waterphas.OUTE, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    for (int i = 0; i < HHvar.solutenum; i++)
                    {
                        HHMMtool.Sendreceive1D(comm, ref TVvar.solutephas.soilsolunew[i], HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    }

                }


                if (comm.Rank == 0) Console.WriteLine("{1}已开始， 当前系统时间是：{0} \n", DateTime.Now, Directory.GetCurrentDirectory());


                for (int di = 0; di < HHvar.Dtdays; di++)//di表示模拟的天数
                {
                    //计算每天的辐射数据，统计每天的数据，主要是得到云盖因子，及其他参数 
                    double Dailyradiation = HHMMtool.weatherred(HHvar.weafile, ref HHvar.weadata);
                    SWHSRad.Daypar(HHvar.Dtstart.DayOfYear, HHvar.regionpara.Latitude, Dailyradiation);
                    for (int hi = 0; hi < 24; hi++)//hi表示小时
                    {
                        //气象因子整理,对积雪部分进行了详细处理,包括积雪压实，积雪出流，融化等，第一步先对积雪网格进行处理

                        SWHSSurfcal.WeatherHour(di, hi, HHvar, TVvar);

                        Console.WriteLine("{0}day {1}hour of Rank {2}", di, hi, comm.Rank);

                        for (int hhi = 0; hhi < HHvar.stepphour; hhi++)
                        {
                            HHvar.tn += 1;
                            SWOF.SVCSrun(SVvar, HHvar, GMvar, TVvar, comm);//运行地表水运动并计算每一步入渗量
                            SWHS.SWHSrun(di, hi, TVvar, HHvar, SVvar, comm);//其它模块

                        }
                        SVCSout.WaEnbalance(SVvar, GMvar, HHvar);//统计SWOF和GMIM涉及的变量
                        SWHSout.WaEnbalance(TVvar, HHvar);//统计SWHS涉及的变量
                        HHMMout.Concluresult(outputpath, HHvar, TVvar, SVvar, comm);//每小时末输出

                    }
                    HHvar.Dtstart = HHvar.Dtstart.AddDays(1);
                }
                HHMMout.rfclose(HHvar.resultfile);

                if (comm.Rank == 0) HHMMout.rfclose(HHvar.resultfileall);
                if (comm.Rank == 0) Console.WriteLine("{1}已结束， 当前系统时间是：{0} \n", DateTime.Now, Directory.GetCurrentDirectory());
            });

        }
    }
}
//mpiexec -n 4 HHMM.exe 