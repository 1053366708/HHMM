﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Globalization;
using MPI;

namespace HHMM
{

    public class HHMMpre
    {
        /// <summary>
        /// 并行文件前处理。将所有的整体输入文件放入inputpath（一般是bin\Debug文件夹）的文件夹下即可
        /// </summary>
        /// <param name="inputpath"></param>
        /// <param name="ranknum"></param>
        public static void HHpre(string inputpath, int ranknum)
        {
            copyfile(inputpath, ranknum);//创建并行输入文件夹，并将相同的输入文件复制到各个文件夹
            soiltypefile(inputpath, ranknum);//分割solitype.asc
            demfile(inputpath, ranknum);//分割rawdem.asc
        }

        /// <summary>
        /// 创建并行输入文件夹，并将相同的输入文件复制到各个文件夹
        /// </summary>
        /// <param name="sourcefolder"></param>
        /// <param name="ranknum"></param>
        public static void copyfile(string sourcefolder, int ranknum)
        {
            string[] filename = { "HHpar.txt", "soilpara.txt", "soiltype.txt", "solupara.txt", "studysite.txt", "SWHSpara.txt", "weather.txt" };//每个核都相同的文件（即除去两个asc文件以外的文件）

            for (int i = 0; i < ranknum; i++)
            {
                string destfolder = @"..\" + i;
                if (!System.IO.Directory.Exists(destfolder)) System.IO.Directory.CreateDirectory(destfolder);//如果不存在文件夹，创建文件夹                
                for (int j = 0; j < filename.Length; j++)
                {
                    string sourcename = System.IO.Path.Combine(sourcefolder, filename[j]);
                    string destname = System.IO.Path.Combine(destfolder, filename[j]);
                    if (System.IO.File.Exists(destname)) System.IO.File.Delete(destname);//将原有文件删除，避免影响复制
                    System.IO.File.Copy(sourcename, destname);
                }
            }
        }

        /// <summary>
        /// 分割solitype.asc
        /// </summary>
        /// <param name="datapath"></param>
        /// <param name="ranknum"></param>
        public static void soiltypefile(string datapath, int ranknum)
        {
            char[] spi = new char[] { ' ', ',', '\t' };
            string soilindexfile = System.IO.Path.Combine(datapath, "soiltype.asc");
            StreamReader indexfile = File.OpenText(soilindexfile);
            String indexs = indexfile.ReadLine();
            int NX = Convert.ToInt32(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            indexs = indexfile.ReadLine();
            int NY = Convert.ToInt32(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            indexs = indexfile.ReadLine();
            double xleft = Convert.ToDouble(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            indexs = indexfile.ReadLine();
            double ybottom = Convert.ToDouble(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            indexs = indexfile.ReadLine();
            double cellsize = Convert.ToDouble(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            indexs = indexfile.ReadLine();
            int Novalue = Convert.ToInt32(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);


            int[,] glosoilindx = new int[NX, NY];
            for (int demrow = 0; demrow < NY; demrow++)
            {
                indexs = indexfile.ReadLine();
                for (int demcol = 0; demcol < NX; demcol++)
                {
                    int gindex = Convert.ToInt32(Convert.ToDouble(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[demcol]));
                    if (gindex > Novalue + 10)
                    {
                        glosoilindx[demcol, demrow] = gindex;
                    }
                    else
                    {
                        glosoilindx[demcol, demrow] = Novalue;
                    }
                }
            }
            indexfile.Close();

            //开始分割
            int colmean = NX / ranknum;//均分列数(向下取整)
            int remaincol = NX - colmean * ranknum;//剩余列数
            int[] colperrank = new int[ranknum];//实际每个核分配到的列数（只包括自身网格，不含接收边界的部分）
            for (int i = 0; i < ranknum; i++) colperrank[i] = colmean;
            for (int i = 0; i < remaincol; i++) colperrank[i] += 1;

            int startcol = 0;//每个核的开始列
            int endcol;//每个核的结束列（endcol-1为编号）
            int NXrank;//每个核的列数
            double xleftrank = xleft;//每个核左下角x坐标（这两个参数每个核不一样）
            for (int i = 0; i < ranknum; i++)
            {
                string destfolder = @"..\" + i;//核文件夹

                if (i == 0)//左边
                {
                    NXrank = colperrank[i] + 1;
                }
                else if (i == ranknum - 1)//右边
                {
                    NXrank = colperrank[i] + 1;
                }
                else//中间
                {
                    NXrank = colperrank[i] + 2;
                }

                endcol = startcol + NXrank;
                StreamWriter fasc = new StreamWriter(System.IO.Path.Combine(destfolder, "soiltype.asc"));
                fasc.WriteLine("ncols         {0}", NXrank);
                fasc.WriteLine("nrows         {0}", NY);
                fasc.WriteLine("xllcorner     {0}", xleftrank);
                fasc.WriteLine("yllcorner     {0}", ybottom);
                fasc.WriteLine("cellsize      {0}", cellsize);
                fasc.WriteLine("NODATA_value  {0}", Novalue);

                for (int row = 0; row < NY; row++)
                {
                    string content = "";
                    for (int col = startcol; col < endcol; col++)
                    {
                        content += string.Format("{0} ", glosoilindx[col, row]);

                    }
                    fasc.WriteLine(content);
                }
                startcol += NXrank - 2;
                xleftrank += cellsize * (NXrank - 2);
                fasc.Flush();
                fasc.Close();
            }

        }


        /// <summary>
        /// 分割rawdem.asc
        /// </summary>
        /// <param name="datapath"></param>
        /// <param name="ranknum"></param>
        public static void demfile(string datapath, int ranknum)
        {
            char[] spi = new char[] { ' ', ',', '\t' };
            string soilindexfile = System.IO.Path.Combine(datapath, "rawdem.asc");
            StreamReader indexfile = File.OpenText(soilindexfile);
            String indexs = indexfile.ReadLine();
            int NX = Convert.ToInt32(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            indexs = indexfile.ReadLine();
            int NY = Convert.ToInt32(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            indexs = indexfile.ReadLine();
            double xleft = Convert.ToDouble(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            indexs = indexfile.ReadLine();
            double ybottom = Convert.ToDouble(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            indexs = indexfile.ReadLine();
            double cellsize = Convert.ToDouble(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            indexs = indexfile.ReadLine();
            int Novalue = Convert.ToInt32(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);


            double[,] glodemindx = new double[NX, NY];
            for (int demrow = 0; demrow < NY; demrow++)
            {
                indexs = indexfile.ReadLine();
                for (int demcol = 0; demcol < NX; demcol++)
                {
                    double gindex = Convert.ToDouble(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[demcol]);
                    if (gindex > Novalue + 10)
                    {
                        glodemindx[demcol, demrow] = gindex;
                    }
                    else
                    {
                        glodemindx[demcol, demrow] = Novalue;
                    }
                }
            }
            indexfile.Close();

            //开始分割
            int colmean = NX / ranknum;//均分列数(向下取整)
            int remaincol = NX - colmean * ranknum;//剩余列数
            int[] colperrank = new int[ranknum];//实际每个核分配到的列数（只包括自身网格，不含接收边界的部分）
            for (int i = 0; i < ranknum; i++) colperrank[i] = colmean;
            for (int i = 0; i < remaincol; i++) colperrank[i] += 1;

            int startcol = 0;//每个核的开始列
            int endcol;//每个核的结束列（endcol-1为编号）
            int NXrank;//每个核的列数
            double xleftrank = xleft;//每个核左下角x坐标（这两个参数每个核不一样）
            for (int i = 0; i < ranknum; i++)
            {
                string destfolder = @"..\" + i;//核文件夹

                if (i == 0)//左边
                {
                    NXrank = colperrank[i] + 1;
                }
                else if (i == ranknum - 1)//右边
                {
                    NXrank = colperrank[i] + 1;
                }
                else//中间
                {
                    NXrank = colperrank[i] + 2;
                }

                endcol = startcol + NXrank;
                StreamWriter fasc = new StreamWriter(System.IO.Path.Combine(destfolder, "rawdem.asc"));
                fasc.WriteLine("ncols         {0}", NXrank);
                fasc.WriteLine("nrows         {0}", NY);
                fasc.WriteLine("xllcorner     {0}", xleftrank);
                fasc.WriteLine("yllcorner     {0}", ybottom);
                fasc.WriteLine("cellsize      {0}", cellsize);
                fasc.WriteLine("NODATA_value  {0}", Novalue);

                for (int row = 0; row < NY; row++)
                {
                    string content = "";
                    for (int col = startcol; col < endcol; col++)
                    {
                        content += string.Format("{0} ", glodemindx[col, row]);

                    }
                    fasc.WriteLine(content);
                }
                startcol += NXrank - 2;
                xleftrank += cellsize * (NXrank - 2);
                fasc.Flush();
                fasc.Close();
            }

        }
    }
}
