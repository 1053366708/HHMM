﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Globalization;
using MPI;

namespace HHMM
{
    public class HHMMinit
    {
        public static void HHinit(HHMMvar HHvar, string inputpath, Intracommunicator comm)
        {
            int[][] soilindex;//soiltype.asc的信息，也就是土壤水平分类
            HHMMsoilpara(inputpath, HHvar);
            HHMMsoiltype(inputpath, HHvar, out soilindex);
            HHMMtopo(inputpath, HHvar, soilindex);
            HHMMout.cubicdefine(HHvar.NXCELL, HHvar.NYCELL, HHvar.NZCELL, HHvar.DX, HHvar.DY, HHvar.DZ, HHvar.Novalue, HHvar.xleft, HHvar.ytop, HHvar.ztop, HHvar.cuboidnum, HHvar.upfaceid, HHvar.downfaceid, out HHvar.cuboid, out HHvar.validpoint);
            HHMMout.platedefine(HHvar.NXCELL, HHvar.NYCELL, HHvar.DX, HHvar.DY, HHvar.DZ, HHvar.Novalue, HHvar.xleft, HHvar.ytop, HHvar.ztop, HHvar.globalvd, HHvar.upfaceid, HHvar.Tdemvalue, out HHvar.swtripoint);
            HHMMmpiself(comm, HHvar);//与每个核自身网格相关参数
        }

        /// <summary>
        /// 土壤参数获取
        /// </summary>
        /// <param name="datapath">路径</param>
        /// <param name="HHvar">数据类</param>
        public static void HHMMsoilpara(string datapath, HHMMvar HHvar)
        {
            //土壤分类获取
            char[] spi = new char[] { ' ', ',', '\t' };
            string soitypefile = System.IO.Path.Combine(datapath, "soiltype.txt");
            string[] st = File.ReadAllLines(soitypefile);

            HHvar.soiltype = new int[st.Length - 1][];
            HHvar.soildepth = new double[st.Length - 1][];
            HHvar.soilthickmax = 0;
            for (int si = 0; si < st.Length - 1; si++)
            {
                int soiltype = Convert.ToInt32(st[si + 1].Split(spi, StringSplitOptions.RemoveEmptyEntries)[0]) - 1;//水平分类class
                int soilnum = Convert.ToInt32(st[si + 1].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);//垂直分类有几种
                HHvar.soildepth[si] = new double[soilnum];
                HHvar.soiltype[si] = new int[soilnum];
                for (int li = 0; li < soilnum; li++)
                {
                    HHvar.soildepth[si][li] = Convert.ToDouble(st[si + 1].Split(spi, StringSplitOptions.RemoveEmptyEntries)[2 + li]);
                    HHvar.soiltype[si][li] = Convert.ToInt32(st[si + 1].Split(spi, StringSplitOptions.RemoveEmptyEntries)[2 + soilnum + li]) - 1;
                }
                HHvar.soilthickmax = Math.Max(HHvar.soilthickmax, HHvar.soildepth[si][soilnum - 1]);
            }

            //土壤参数获取
            string soilparafile = System.IO.Path.Combine(datapath, "soilpara.txt");
            string[] sp = File.ReadAllLines(soilparafile);
            HHvar.soiltypenum = sp.Length - 1;
            HHvar.soilwaterpara.soilwas = new double[HHvar.soiltypenum];
            HHvar.soilwaterpara.soilwar = new double[HHvar.soiltypenum];
            HHvar.soilwaterpara.l = new double[HHvar.soiltypenum];
            HHvar.soilwaterpara.n = new double[HHvar.soiltypenum];
            HHvar.soilwaterpara.m = new double[HHvar.soiltypenum];
            HHvar.soilwaterpara.Ks = new double[HHvar.soiltypenum];
            HHvar.soilwaterpara.Ks9 = new double[HHvar.soiltypenum];
            HHvar.soilwaterpara.avg = new double[HHvar.soiltypenum];
            HHvar.soilwaterpara.ha = new double[HHvar.soiltypenum];
            HHvar.soilheatpara.sand = new double[HHvar.soiltypenum];
            HHvar.soilheatpara.silt = new double[HHvar.soiltypenum];
            HHvar.soilheatpara.clay = new double[HHvar.soiltypenum];
            HHvar.soilheatpara.orgran = new double[HHvar.soiltypenum];
            HHvar.soilheatpara.minedensity = new double[HHvar.soiltypenum];
            HHvar.soilwaterpara.swinit = new double[HHvar.soiltypenum];
            HHvar.soilheatpara.stinit = new double[HHvar.soiltypenum];
            HHvar.soilheatpara.ksmine = new double[HHvar.soiltypenum];
            HHvar.soilheatpara.csmine = new double[HHvar.soiltypenum];
            HHvar.soilheatpara.ALBDRY = new double[HHvar.soiltypenum];
            HHvar.soilheatpara.ALBEXP = new double[HHvar.soiltypenum];
            for (int si = 1; si < sp.Length; si++)
            {
                HHvar.soilwaterpara.soilwas[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
                HHvar.soilwaterpara.soilwar[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[2]);
                HHvar.soilwaterpara.l[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[3]);
                HHvar.soilwaterpara.n[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[4]);
                HHvar.soilwaterpara.m[si - 1] = 1.0 - 1.0 / HHvar.soilwaterpara.n[si - 1];
                HHvar.soilwaterpara.Ks[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[5]);
                HHvar.soilwaterpara.avg[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[6]);
                HHvar.soilwaterpara.ha[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[7]);
                HHvar.soilheatpara.sand[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[8]);
                HHvar.soilheatpara.silt[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[9]);
                HHvar.soilheatpara.clay[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[10]);
                HHvar.soilheatpara.orgran[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[11]);
                HHvar.soilheatpara.minedensity[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[12]);
                HHvar.soilheatpara.ALBDRY[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[13]);
                HHvar.soilheatpara.ALBEXP[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[14]);
                HHvar.soilwaterpara.swinit[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[15]);
                HHvar.soilheatpara.stinit[si - 1] = Convert.ToDouble(sp[si].Split(spi, StringSplitOptions.RemoveEmptyEntries)[16]);
                SWHSWater.Cellgq2k(HHvar.soilwaterpara.soilwas[si - 1], HHvar.soilwaterpara.soilwar[si - 1], HHvar.soilwaterpara.Ks[si - 1], HHvar.soilwaterpara.l[si - 1], HHvar.soilwaterpara.m[si - 1], 0.9 * HHvar.soilwaterpara.soilwas[si - 1], 0.0, out HHvar.soilwaterpara.Ks9[si - 1]);
                SWHSHeat.Ksminecal(HHvar.soilheatpara.sand[si - 1], HHvar.soilheatpara.silt[si - 1], HHvar.soilheatpara.clay[si - 1], out HHvar.soilheatpara.ksmine[si - 1]);
                SWHSHeat.Csminecal(HHvar.soilheatpara.sand[si - 1], HHvar.soilheatpara.silt[si - 1], HHvar.soilheatpara.clay[si - 1], out HHvar.soilheatpara.csmine[si - 1]);
            }

            string soluparafile = System.IO.Path.Combine(datapath, "solupara.txt");
            string[] solu = File.ReadAllLines(soluparafile);
            HHvar.solutenum = (solu.Length - 1) / HHvar.soiltypenum;//有n种在txt文件中就是n*6行
            HHvar.soilsolutepara.dh = new double[HHvar.solutenum][];
            HHvar.soilsolutepara.dm = new double[HHvar.solutenum][];
            HHvar.soilsolutepara.kcq = new double[HHvar.solutenum][];
            HHvar.soilsolutepara.dhra = new double[HHvar.solutenum][];
            HHvar.soilsolutepara.soinit = new double[HHvar.solutenum][];
            for (int si = 0; si < HHvar.solutenum; si++)
            {
                HHvar.soilsolutepara.dh[si] = new double[HHvar.soiltypenum];
                HHvar.soilsolutepara.dm[si] = new double[HHvar.soiltypenum];
                HHvar.soilsolutepara.kcq[si] = new double[HHvar.soiltypenum];
                HHvar.soilsolutepara.dhra[si] = new double[HHvar.soiltypenum];
                HHvar.soilsolutepara.soinit[si] = new double[HHvar.soiltypenum];
                for (int soi = 0; soi < HHvar.soiltypenum; soi++)
                {
                    HHvar.soilsolutepara.dh[si][soi] = Convert.ToDouble(solu[si * HHvar.soiltypenum + soi + 1].Split(spi, StringSplitOptions.RemoveEmptyEntries)[2]);
                    HHvar.soilsolutepara.dm[si][soi] = Convert.ToDouble(solu[si * HHvar.soiltypenum + soi + 1].Split(spi, StringSplitOptions.RemoveEmptyEntries)[3]);
                    HHvar.soilsolutepara.kcq[si][soi] = Convert.ToDouble(solu[si * HHvar.soiltypenum + soi + 1].Split(spi, StringSplitOptions.RemoveEmptyEntries)[4]);
                    HHvar.soilsolutepara.dhra[si][soi] = Convert.ToDouble(solu[si * HHvar.soiltypenum + soi + 1].Split(spi, StringSplitOptions.RemoveEmptyEntries)[5]);
                    HHvar.soilsolutepara.soinit[si][soi] = Convert.ToDouble(solu[si * HHvar.soiltypenum + soi + 1].Split(spi, StringSplitOptions.RemoveEmptyEntries)[6]);
                }
            }
        }
        /// <summary>
        /// 土壤类型获取
        /// </summary>
        /// <param name="datapath">路径</param>
        /// <param name="HHvar">数据类</param>
        public static void HHMMsoiltype(string datapath, HHMMvar HHvar, out int[][] soilindex)
        {
            char[] spi = new char[] { ' ', ',', '\t' };
            string soilindexfile = System.IO.Path.Combine(datapath, "soiltype.asc");
            StreamReader indexfile = File.OpenText(soilindexfile);
            String indexs = indexfile.ReadLine();
            HHvar.NX = Convert.ToInt32(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            indexs = indexfile.ReadLine();
            HHvar.NY = Convert.ToInt32(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            indexs = indexfile.ReadLine();
            HHvar.xleft = Convert.ToDouble(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            indexs = indexfile.ReadLine();
            double ybottom = Convert.ToDouble(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            indexs = indexfile.ReadLine();
            HHvar.cellsize = Convert.ToDouble(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            indexs = indexfile.ReadLine();
            HHvar.Novalue = Convert.ToInt32(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            HHvar.ytop = ybottom + HHvar.NY * HHvar.cellsize;

            int[,] glosoilindx = new int[HHvar.NX, HHvar.NY];
            for (int demrow = 0; demrow < HHvar.NY; demrow++)
            {
                indexs = indexfile.ReadLine();
                for (int demcol = 0; demcol < HHvar.NX; demcol++)
                {
                    int gindex = Convert.ToInt32(Convert.ToDouble(indexs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[demcol]));
                    // int gindex = 1;
                    if (gindex > HHvar.Novalue + 10)
                    {
                        glosoilindx[demcol, demrow] = gindex;
                    }
                    else
                    {
                        glosoilindx[demcol, demrow] = (int)HHvar.Novalue;
                    }
                }
            }
            indexfile.Close();

            //将demresample。可以在arcmap中进行
            HHvar.NXzoom = (int)(Math.Floor(HHvar.DX / HHvar.cellsize));
            HHvar.NYzoom = (int)(Math.Floor(HHvar.DY / HHvar.cellsize));
            HHvar.NXCELL = (int)(Math.Ceiling(HHvar.NX / (double)HHvar.NXzoom));
            HHvar.NYCELL = (int)(Math.Ceiling(HHvar.NY / (double)HHvar.NYzoom));

            soilindex = new int[HHvar.NXCELL][];
            for (int si = 0; si < HHvar.NXCELL; si++)
            {
                soilindex[si] = new int[HHvar.NYCELL];
            }

            for (int demrow = 0; demrow < HHvar.NYCELL; demrow++)
            {
                for (int demcol = 0; demcol < HHvar.NXCELL; demcol++)
                {
                    int soilmatrix = 0;
                    int[] soiltype = new int[HHvar.soiltype.GetLength(0)];
                    for (int demrowi = 0; demrowi < HHvar.NYzoom; demrowi++)
                    {
                        for (int demcoli = 0; demcoli < HHvar.NXzoom; demcoli++)
                        {
                            if (((demrow * HHvar.NYzoom + demrowi) < HHvar.NY) & (((demcol * HHvar.NXzoom + demcoli) < HHvar.NX)))
                            {
                                if (glosoilindx[demcol * HHvar.NXzoom + demcoli, demrow * HHvar.NYzoom + demrowi] > HHvar.Novalue + 10)
                                {
                                    soiltype[glosoilindx[demcol * HHvar.NXzoom + demcoli, demrow * HHvar.NYzoom + demrowi] - 1] += 1;
                                    soilmatrix += 1;
                                }
                            }
                        }
                        if (soilmatrix >= 1)
                        {
                            int stype = 0;
                            for (int st0 = 1; st0 < soiltype.Length; st0++)
                            {
                                if (soiltype[st0] > soiltype[stype])
                                {
                                    stype = st0;  //区域的土壤类型赋值
                                }
                            }
                            soilindex[demcol][demrow] = stype + 1;  //确定是那一类型土壤
                        }
                        else
                        {
                            soilindex[demcol][demrow] = (int)HHvar.Novalue;
                        }
                    }
                }
            }
        }
        /// <summary>
        /// 三维地形重构
        /// </summary>
        /// <param name="datapath">路径</param>
        /// <param name="HHvar">数据类</param>
        public static void HHMMtopo(string datapath, HHMMvar HHvar, int[][] soilindex)
        {//读取原始DEM    
            double[,] demvalueraw = new double[HHvar.NX, HHvar.NY];
            double[,] demvalue = new double[HHvar.NXCELL, HHvar.NYCELL];
            HHvar.Tdemvalue = new double[HHvar.NXCELL][];
            for (int demcol = 0; demcol < HHvar.NXCELL; demcol++)
            {
                HHvar.Tdemvalue[demcol] = new double[HHvar.NYCELL];
            }
            char[] spi = new char[] { ' ', ',', '\t' };
            string demhfile = System.IO.Path.Combine(datapath, "rawdem.asc");
            StreamReader demfile = File.OpenText(demhfile);
            String demfs;
            for (int demi = 0; demi < 6; demi++)
            {
                demfs = demfile.ReadLine();
            }
            for (int demrow = 0; demrow < HHvar.NY; demrow++)
            {
                demfs = demfile.ReadLine();
                for (int demcol = 0; demcol < HHvar.NX; demcol++)
                {
                    demvalueraw[demcol, demrow] = Convert.ToDouble(demfs.Split(spi, StringSplitOptions.RemoveEmptyEntries)[demcol]);
                }
            }
            demfile.Close();

            HHvar.globalvd = 0;  //水平有效网格，即非-9999的
            HHvar.Demmin = 10000000; HHvar.Demmax = -100;
            //将原始的dem数据转换成需要的空间步长。可以在arcmap中进行
            for (int demrow = 0; demrow < HHvar.NYCELL; demrow++)
            {
                for (int demcol = 0; demcol < HHvar.NXCELL; demcol++)
                {
                    double demdata = 0;
                    int validgrid = 0;
                    for (int demrowi = 0; demrowi < HHvar.NYzoom; demrowi++)
                    {
                        for (int demcoli = 0; demcoli < HHvar.NXzoom; demcoli++)
                        {
                            if (((demrow * HHvar.NYzoom + demrowi) < HHvar.NY) & (((demcol * HHvar.NXzoom + demcoli) < HHvar.NX)))
                            {
                                if (demvalueraw[demcol * HHvar.NXzoom + demcoli, demrow * HHvar.NYzoom + demrowi] > HHvar.Novalue + 100)
                                {
                                    demdata += demvalueraw[demcol * HHvar.NXzoom + demcoli, demrow * HHvar.NYzoom + demrowi];
                                    validgrid += 1;
                                }
                            }

                        }
                    }
                    if (validgrid >= 1)
                    {
                        HHvar.Tdemvalue[demcol][demrow] = Math.Round(demdata / validgrid, 2);//网格变疏，取平均
                        demvalue[demcol, demrow] = Math.Round(HHvar.DZ * Convert.ToInt32((HHvar.Tdemvalue[demcol][demrow] * 100 / (HHvar.DZ * 100))), 2);//取两位小数
                        HHvar.Demmax = Math.Max(HHvar.Demmax, demvalue[demcol, demrow]);
                        HHvar.Demmin = Math.Min(HHvar.Demmin, demvalue[demcol, demrow]);
                        HHvar.globalvd += 1;
                    }
                    else
                    {
                        HHvar.Tdemvalue[demcol][demrow] = HHvar.Novalue;
                        demvalue[demcol, demrow] = HHvar.Novalue;
                    }
                }
            }
            HHvar.Demmax += HHvar.DZ;
            HHvar.Demmin -= HHvar.DZ;

            HHvar.NZCELL = (int)(Math.Ceiling((HHvar.Demmax - HHvar.Demmin) / HHvar.DZ) + 1);
            int Soilmaxlay = (int)(Math.Ceiling(HHvar.soilthickmax / HHvar.DZ));
            HHvar.NZCELL += Soilmaxlay;
            HHvar.ztop = HHvar.Demmax;

            Topodefine(HHvar);
            HHvar.cuboidnum = 0;//有效网格数
            HHvar.upfaceid = new int[HHvar.NXCELL][];
            HHvar.downfaceid = new int[HHvar.NXCELL][];
            HHvar.conupfaceid = new int[HHvar.NXCELL][];
            int ordern = 0;
            for (int cxi = 0; cxi < HHvar.NXCELL; cxi++)
            {
                HHvar.upfaceid[cxi] = new int[HHvar.NYCELL];
                HHvar.downfaceid[cxi] = new int[HHvar.NYCELL];
                HHvar.conupfaceid[cxi] = new int[HHvar.NYCELL];
                for (int cyi = 0; cyi < HHvar.NYCELL; cyi++)
                {
                    if (HHvar.Tdemvalue[cxi][cyi] < HHvar.Novalue + 10)
                    {
                        HHvar.Tdemvalue[cxi][cyi] = HHvar.Demmax + 100;//用途。变成一个围墙，水上不去
                    }

                    if (demvalue[cxi, cyi] > (HHvar.Novalue + 10))
                    {
                        int soiltype = soilindex[cxi][cyi];
                        int soillayer = HHvar.soildepth[soiltype - 1].Length;
                        double soilthick = HHvar.soildepth[soiltype - 1][soillayer - 1];//土壤厚度
                        int soillayerlist = (int)(Math.Ceiling(soilthick / HHvar.DZ));//土壤层数
                        int tz = 0;
                        for (int czi = 0; czi < HHvar.NZCELL; czi++)  //DEM的最上层是z节点值最大
                        {
                            if ((HHvar.Demmax - czi * HHvar.DZ) <= demvalue[cxi, cyi])
                            {
                                if (tz < soillayerlist)
                                {
                                    HHvar.cuboidnum += 1;
                                    if (tz == 0)
                                    {
                                        HHvar.upfaceid[cxi][cyi] = czi;
                                    }
                                }
                                tz += 1;
                            }
                        }
                        HHvar.downfaceid[cxi][cyi] = HHvar.upfaceid[cxi][cyi] + soillayerlist - 1;
                    }
                    else
                    {
                        HHvar.upfaceid[cxi][cyi] = -9999;
                        HHvar.downfaceid[cxi][cyi] = -9999;
                    }
                }
            }

            HHvar.cellsoiltype = new int[HHvar.cuboidnum];
            for (int cxi = 0; cxi < HHvar.NXCELL; cxi++)
            {
                for (int cyi = 0; cyi < HHvar.NYCELL; cyi++)
                {
                    int soilclass = soilindex[cxi][cyi] - 1;//土壤是哪一类
                    int soilclalayer = 0; //土壤发生学中的分层
                    int layeri = 0;
                    double soillayerthick = 0.0;
                    if (HHvar.upfaceid[cxi][cyi] > (HHvar.Novalue + 10))
                    {
                        HHvar.conupfaceid[cxi][cyi] = ordern;
                        for (int czi = HHvar.upfaceid[cxi][cyi]; czi <= HHvar.downfaceid[cxi][cyi]; czi++)
                        {
                            HHvar.cellord[cxi][cyi][czi] = ordern;
                            layeri += 1;
                            soillayerthick = layeri * HHvar.DZ;
                            if (soillayerthick > HHvar.soildepth[soilclass][soilclalayer] + 0.00001)//会有精度误差：比如，3*0.2=0.600……09>0.6
                            {
                                soilclalayer += 1;
                            }
                            if (soilclalayer > HHvar.soiltype[soilclass].Length - 1)
                            {
                                soilclalayer = HHvar.soiltype[soilclass].Length - 1;
                            }
                            HHvar.cellsoiltype[ordern] = HHvar.soiltype[soilclass][soilclalayer];//确定每个网格（变成一维后）的土壤类型
                            ordern++;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 数据定义
        /// </summary>
        /// <param name="HHvar"></param>
        public static void Topodefine(HHMMvar HHvar)
        {
            HHvar.weadata = new HHMMvar.Weather[24];
            HHvar.validwaterdepth = new double[HHvar.globalvd];
            HHvar.cellord = new int[HHvar.NXCELL][][];
            HHvar.landuseindex = new int[HHvar.NXCELL][];
            HHvar.soiltosurface = new double[HHvar.NXCELL][][];
            HHvar.soiltosurfaceDT = new double[HHvar.NXCELL][][];
            //每个网格的土地利用类型；
            //HHvar.weadata.rain = new double[HHvar.NXCELL][];

            for (int i = 0; i < HHvar.NXCELL; i++)
            {
                HHvar.cellord[i] = new int[HHvar.NYCELL][];
                HHvar.landuseindex[i] = new int[HHvar.NYCELL]; //每个网格的土地利用类型；没用到
                HHvar.soiltosurface[i] = new double[HHvar.NYCELL][];
                HHvar.soiltosurfaceDT[i] = new double[HHvar.NYCELL][];
                for (int j = 0; j < HHvar.NYCELL; j++)
                {
                    HHvar.cellord[i][j] = new int[HHvar.NZCELL];
                    HHvar.soiltosurface[i][j] = new double[4];
                    HHvar.soiltosurfaceDT[i][j] = new double[4];
                    for (int l = 0; l < HHvar.NZCELL; l++)
                    {
                        HHvar.cellord[i][j][l] = (int)HHvar.Novalue;
                    }
                    for (int l = 0; l < 4; l++)
                    {
                        HHvar.soiltosurface[i][j][l] = 0.0;
                        HHvar.soiltosurfaceDT[i][j][l] = 0.0;
                    }
                }
            }
        }
        /// <summary>
        /// 与每个核自身网格相关参数
        /// </summary>
        /// <param name="comm"></param>
        /// <param name="HHvar"></param>
        public static void HHMMmpiself(Intracommunicator comm, HHMMvar HHvar)
        {
            if (comm.Size > 1)
            {
                if (comm.Rank == 0)
                {
                    HHvar.startcell = 0;
                    HHvar.endcell = HHvar.conupfaceid[HHvar.NXCELL - 1][0];
                    HHvar.startcol = 0;
                    HHvar.endcol = HHvar.NXCELL - 1;
                    HHvar.startgrid = 0;
                    HHvar.endgrid = HHvar.globalvd - HHvar.NYCELL;

                }
                else if (comm.Rank == comm.Size - 1)
                {
                    HHvar.startcell = HHvar.conupfaceid[1][0];
                    HHvar.endcell = HHvar.cuboidnum;
                    HHvar.startcol = 1;
                    HHvar.endcol = HHvar.NXCELL;
                    HHvar.startgrid = HHvar.NYCELL;
                    HHvar.endgrid = HHvar.globalvd;
                }
                else
                {
                    HHvar.startcell = HHvar.conupfaceid[1][0];
                    HHvar.endcell = HHvar.conupfaceid[HHvar.NXCELL - 1][0];
                    HHvar.startcol = 1;
                    HHvar.endcol = HHvar.NXCELL - 1;
                    HHvar.startgrid = HHvar.NYCELL;
                    HHvar.endgrid = HHvar.globalvd - HHvar.NYCELL;

                }

            }
            else
            {
                HHvar.startcell = 0;
                HHvar.endcell = HHvar.cuboidnum;
                HHvar.startcol = 0;
                HHvar.endcol = HHvar.NXCELL;
                HHvar.startgrid = 0;
                HHvar.endgrid = HHvar.globalvd;

            }
            HHvar.cuboidnumself = HHvar.endcell - HHvar.startcell;
            HHvar.globalvdself = HHvar.endgrid - HHvar.startgrid;

        }
    }
}
