﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HHMM
{
    public class SHAWAtstab
    {
        public static double Zmlog;
        public static double Zhlog;
        public static double Hflux1;
        public static double Psim;
        public static double Psih;

        /// <summary>
        /// 计算感热和潜热，并计算对计算方程的贡献
        /// </summary>
        /// <param name="Iter"></param>
        /// <param name="Height"></param>
        /// <param name="Zh"></param>
        /// <param name="Zm"></param>
        /// <param name="Zero"></param>
        /// <param name="NSP"></param>
        /// <param name="Ta"></param>
        /// <param name="Tadt"></param>
        /// <param name="Hum"></param>
        /// <param name="Humdt"></param>
        /// <param name="Vap"></param>
        /// <param name="Vapdt"></param>
        /// <param name="Wind"></param>
        /// <param name="Presure"></param>
        /// <param name="ICE"></param>
        /// <param name="Ts"></param>
        /// <param name="Tsdt"></param>
        /// <param name="soilhead"></param>
        /// <param name="soilheaddt"></param>
        /// <param name="soilwater"></param>
        /// <param name="soilice"></param>
        /// <param name="dt"></param>
        /// <param name="DZ"></param>
        /// <param name="soilwar"></param>
        /// <param name="soilwas"></param>
        /// <param name="Hflux"></param>
        /// <param name="Vflux"></param>
        /// <param name="B1"></param>
        /// <param name="B2"></param>
        /// <param name="D1"></param>
        /// <param name="D2"></param>
        /// <param name="Ustar"></param>
        /// <param name="Stable"></param>
        public static void ATSTAB(int Iter, double Height, double Zh, double Zm, double Zero,
            int NSP, double Ta, double Tadt, double Hum, double Humdt, double Vap, double Vapdt, double Wind, double Presure, int ICE, double Ts, double Tsdt, double soilhead, double soilheaddt, double soilwater, double soilice, double dt, double DZ, double soilwar, double soilwas, ref double Hflux, ref double Vflux, ref double B1, ref double B2, ref double D1, ref double D2, ref double Ustar, ref double Stable)
        {
            double Satv, Satvdt, S;
            double Tempair = 0, Vapair = 0;
            double Tempsfc, Vapsfc;
            double Hflux2;
            double Rh = 0, Rv = 0;//经过大气稳定性修正的地表热交换的阻抗，水汽交换阻抗值，可认为两者等价
            double Hmin, Vmin;
            double Dv;
            double Con, Conv;
            double Error;
            int Iter1;

            if (Iter <= 2)
            {
                if (Iter <= 1)
                {
                    SHAWTools.VSLOPE(Ta, out Satv, out S);
                    SHAWTools.VSLOPE(Tadt, out Satvdt, out S);
                    Tempair = SHAWconst.WT * Ta + SHAWconst.WDT * Tadt;
                    Vapair = SHAWconst.WT * Hum * Satv + SHAWconst.WDT * Humdt * Satvdt;
                    Zmlog = Math.Log((Height + Zm - Zero) / Zm, Math.E);
                    Zhlog = Math.Log((Height + Zh - Zero) / Zh, Math.E);
                }
                Hflux1 = 0;//感热通量迭代初始值
                Psim = 0;//动量的传热校正系数
                Psih = 0;//热量的传热校正系数
                Ustar = Wind * SHAWconst.VONKRM / (Zmlog + Psim);
            }

            Tempsfc = SHAWconst.WT * Ts + SHAWconst.WDT * Tsdt;      //表层温度
            Vapsfc = SHAWconst.WT * Vap + SHAWconst.WDT * Vapdt;  //vapdt表层水气密度
            Hflux = 0;                 //初始Hflux
            Vflux = 0;                 //初始Vflux

            if (Wind <= 0)
            {
                goto Mincal;             //风速如果小于0，则按最小值计算
            }

            Iter1 = 0;              //内部迭代，计算湍流系统
        Iteration:
            Iter1++;
            Stable = SHAWconst.VONKRM * (Height - Zero) * SHAWconst.G * Hflux1 / (SHAWconst.RHOA * SHAWconst.CA * (Tempair + SHAWconst.Tk0) * Math.Pow(Ustar, 3));//S（大气稳定性热湍流和机械感应湍流和比率）
            if (Stable >= 0.0)//稳定条件
            {
                if (Stable > Zmlog / 9.4)
                {
                    Stable = Zmlog / 9.4;
                }
                Psih = 4.7 * Stable;//ψh 热量的传热校正系数
                Psim = Psih;//ψm 动量的传热校正系数
            }
            else//不稳定条件
            {
                Psih = -2 * Math.Log(((1 + Math.Pow((1 - 16 * Stable), 0.5)) / 2.0), Math.E);
                Psim = 0.6 * Psih;
                if (Psim / Zmlog < -0.5)
                {
                    Psim = -0.5 * Zmlog;
                    Psih = Psim / 0.6;
                    Stable = -(Math.Pow((2 * Math.Exp(-Psih / 2) - 1), 2) - 1) / 16;
                }
            }

            Ustar = Wind * SHAWconst.VONKRM / (Zmlog + Psim);//摩擦速度
            Rh = (Zhlog + Psih) / (Ustar * SHAWconst.VONKRM);//对流交换阻抗
            Hflux2 = SHAWconst.RHOA * SHAWconst.CA * (Tempair - Tempsfc) / Rh;//感热通量 J m-2 s-1
            Error = Math.Abs(Hflux2 - Hflux1);
            Hflux1 = Hflux2;

            if ((Math.Abs(Hflux1) < Math.Abs(SHAWconst.TKA * (Tempair - Tempsfc) / (Height - Zero))) || Iter1 > 40)
            {
                goto hcal;
            }

            if (Error > SHAWconst.Htoler)
            {
                goto Iteration;
            }

        hcal:
            Hflux = Hflux1;
            Rv = Rh;
            Vflux = (Vapair - Vapsfc) / Rv;//潜热通量 kg m-2 s-1

        Mincal:
            Hmin = SHAWconst.TKA * (Tempair - Tempsfc) / (Height - Zero);
            if (Math.Abs(Hmin) <= Math.Abs(Hflux))//风足够大
            {
                Con = SHAWconst.RHOA * SHAWconst.CA / Rh;//导热率
            }
            else//风小被认为是静止空气
            {
                Hflux = Hmin;
                Con = SHAWconst.TKA / (Height - Zero);
            }

            Dv = SHAWconst.VDIFF * Math.Pow((Tempair + SHAWconst.Tk0) / SHAWconst.Tk0, 2) * (SHAWconst.P0 / Presure);
            Vmin = Dv * (Vapair - Vapsfc) / (Height - Zero);
            if (Math.Abs(Vmin) <= Math.Abs(Vflux))
            {
                Conv = 1 / Rv;
            }
            else
            {
                Vflux = Vmin;
                Conv = Dv / (Zh - Zero);
            }
            if (NSP > 0)
            {

                SHAWTools.VSLOPE(Tsdt, out Satv, out S);
                if (ICE == 0)
                {
                    B1 = B1 - SHAWconst.WDT * Con - SHAWconst.WDT * SHAWconst.LS * S * Conv;
                }
                D1 = Hflux + SHAWconst.LS * Vflux;
                B2 = 0.0;
                D2 = 0.0;

            }
            else
            {
                Vflux = Math.Min((soilwas - soilice - soilwater) * DZ / dt * SHAWconst.RHOL, Math.Max(Vflux, (-soilwater + SHAWconst.LWcon * soilwar) * DZ / dt * SHAWconst.RHOL));

                SHAWTools.VSLOPE(Tsdt, out Satv, out S);
                D1 = Hflux + SHAWconst.LV * Vflux;//W/m^2  感热+潜热通量 Jm-2 s-1 
                D2 = Vflux / SHAWconst.RHOL;//m/s
                if (ICE == 0)
                {
                    B1 = B1 - SHAWconst.WDT * Con - SHAWconst.WDT * SHAWconst.LV * S * Conv;
                    B2 = -Vapdt * Conv * SHAWconst.Mw * SHAWconst.G / (SHAWconst.UGAS * (Tsdt + SHAWconst.Tk0)) / SHAWconst.RHOL;
                }
                else
                {
                    B2 = 0.0;
                }
            }
        }//计算感热和潜热，并计算对计算方程的贡献



        public static void SHAWSystem(int NSP, double ZMCM, double ZMSP, double ZHSP, double ZSP, double Height, out double Zm, out double Zh, out double Zero)
        {
            Zm = ZMCM;
            Zh = 0.2 * Zm;
            Zero = 0.0;
            if (NSP > 0)
            {
                Zm = ZMSP;
                Zh = ZHSP;
                Zero = ZSP;
                if ((Zero + Zm) >= Height)
                {
                    Zero = Height / 2.0;
                }
            }
        }
    }
}
