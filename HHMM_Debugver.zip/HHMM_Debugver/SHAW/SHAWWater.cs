﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace HHMM
{
    public class SHAWWater
    {
        /// <summary>
        /// Richards方程求解
        /// </summary>
        /// <param name="Richardmethod"></param>
        /// <param name="HHvar"></param>
        /// <param name="TVvar"></param>
        /// <param name="Timestep"></param>
        public static void Soilwatercal(string Richardmethod, HHMMvar HHvar, SHAWvar TVvar, double Timestep)
        {
            SHAWWater.Soilwatcap(HHvar, TVvar.waterphas.MATDT, TVvar.waterphas.VLCDT, TVvar.icephas.VICDT, ref TVvar.waterphas.C);
            if (Richardmethod == "Celia")
            {
                SHAWWater.SoilwaterupdateCelia(HHvar.cuboidnum, TVvar.Cellx, TVvar.Celly, TVvar.Cellz, Timestep, TVvar.cellsize.celltopo, TVvar.waterphas.VLC, TVvar.waterphas.VLCDT, TVvar.waterphas.MATDT, TVvar.icephas.VIC, TVvar.icephas.VICDT, TVvar.waterphas.C, TVvar.waterphas.K, TVvar.mumpsSHAW.WMatrixadd, TVvar.mumpsSHAW.WaterBaadd, ref TVvar.mumpsSHAW.a, ref TVvar.mumpsSHAW.rhs);
            }
            if (Richardmethod == "NewRap")
            {
                SHAWWater.SoilwaterupdateNewRap(HHvar.soiltosurface, HHvar.upfaceid, HHvar.NXCELL, HHvar.NYCELL, HHvar.rocknum, HHvar.cellsoiltype, HHvar.soilwaterpara.soilwar, HHvar.EnvPro, HHvar.cuboidnum, TVvar.Cellx, TVvar.Celly, TVvar.Cellz, Timestep, TVvar.cellsize.celltopo, TVvar.waterphas.VLC, TVvar.waterphas.VLCDT, TVvar.waterphas.MATDT, TVvar.icephas.VIC, TVvar.icephas.VICDT, TVvar.icephas.ICESDT, TVvar.waterphas.C, TVvar.waterphas.K, TVvar.mumpsSHAW.WMatrixadd, TVvar.mumpsSHAW.WaterBaadd, SHAWconst.RHOI, SHAWconst.RHOL, HHvar.solutenum, TVvar.solutephas.soilsolunew, ref TVvar.mumpsSHAW.a, ref TVvar.mumpsSHAW.rhs, ref TVvar.waterphas.OUTWADT, ref TVvar.waterphas.OUTWA2DT, ref TVvar.solutephas.OUTSODT, ref TVvar.solutephas.OUTSODT2, ref HHvar.soiltosurfaceDT);
            }

        }

        /// <summary>
        /// 求解水势
        /// </summary>
        /// <param name="HHvar"></param>
        /// <param name="soilwa"></param>
        /// <param name="soilice"></param>
        /// <param name="soilh"></param>
        public static void Gq2y(HHMMvar HHvar, double[] soilwa, double[] soilice, ref double[] soilh)
        {
            for (int ic = 0; ic < HHvar.cuboidnum; ic++)
            {
                int ct = HHvar.cellsoiltype[ic];
                Cellgq2y(HHvar.soilwaterpara.soilwas[ct], HHvar.soilwaterpara.soilwar[ct], HHvar.soilwaterpara.avg[ct], HHvar.soilwaterpara.m[ct], HHvar.soilwaterpara.n[ct], soilwa[ic], soilice[ic], out soilh[ic]);

            }
        }

        /// <summary>
        /// 求解含水率
        /// </summary>
        /// <param name="soilwas"></param>
        /// <param name="soilwar"></param>
        /// <param name="soilavg"></param>
        /// <param name="soilm"></param>
        /// <param name="soiln"></param>
        /// <param name="soilh"></param>
        /// <param name="soilice"></param>
        /// <param name="soilwa"></param>
        public static void Cellgy2q(double soilwas, double soilwar, double soilavg, double soilm, double soiln, double soilh, double soilice, out double soilwa)
        {//根据水势求土壤含水率

            soilwas = Math.Max(SHAWconst.LWcon * soilwar, soilwas - soilice);

            if (soilh >= 0)
            {
                soilwa = soilwas;
            }
            else
            {
                soilwa = Math.Max(SHAWconst.LWcon * soilwar, soilwar + (soilwas - soilwar) / (Math.Pow((1 + Math.Pow(Math.Abs(soilavg * soilh), soiln)), soilm)));
            }

        }

        /// <summary>
        /// 求解水势soilh
        /// </summary>
        /// <param name="soilwas"></param>
        /// <param name="soilwar"></param>
        /// <param name="soilavg"></param>
        /// <param name="soilm"></param>
        /// <param name="soiln"></param>
        /// <param name="soilwa"></param>
        /// <param name="soilice"></param>
        /// <param name="soilh"></param>
        public static void Cellgq2y(double soilwas, double soilwar, double soilavg, double soilm, double soiln, double soilwa, double soilice, out double soilh)
        {//求解水势soilh
            soilwas = Math.Max(SHAWconst.LWcon * soilwar, soilwas - soilice);

            if (soilwa >= soilwas)
            {
                soilh = 0.0;
            }
            else
            {
                soilh = -1.0 / soilavg * Math.Pow((Math.Pow((soilwas - soilwar) / (soilwa - soilwar), 1.0 / soilm) - 1), 1.0 / soiln);
            }
        }

        /// <summary>
        /// 求解土壤不饱和导水率K
        /// </summary>
        /// <param name="soilwas"></param>
        /// <param name="soilwar"></param>
        /// <param name="Ks"></param>
        /// <param name="soill"></param>
        /// <param name="soilm"></param>
        /// <param name="soilwa"></param>
        /// <param name="soilice"></param>
        /// <param name="K"></param>
        public static void Cellgq2k(double soilwas, double soilwar, double Ks, double soill, double soilm, double soilwa, double soilice, out double K)
        {//求解土壤不饱和导水率K

            soilwas = Math.Max(SHAWconst.LWcon * soilwar, soilwas - soilice);

            double Se;
            if (soilwa >= soilwas)
            {
                K = Ks;
            }
            else if (soilwa <= SHAWconst.LWcon * soilwar)
            {
                K = 0.0;
            }
            else
            {
                Se = (soilwa - soilwar) / (soilwas - soilwar);
                K = Ks * Math.Pow(Se, soill) * Math.Pow((1.0 - Math.Pow((1.0 - Math.Pow(Se, 1.0 / soilm)), soilm)), 2.0);
            }
            if (soilice > 0)
            {
                if (soilwas - soilice < 0.13)
                {
                    K = 0.0;
                }
                else
                {
                    K = K - K * soilice / (soilwas - 0.13);
                }
            }
        }

        /// <summary>
        /// 求解土壤不饱和导水率K
        /// </summary>
        /// <param name="HHvar"></param>
        /// <param name="soilwa"></param>
        /// <param name="soilice"></param>
        /// <param name="K"></param>
        public static void Gq2k(HHMMvar HHvar, double[] soilwa, double[] soilice, ref double[] K)
        {
            for (int ic = 0; ic < HHvar.cuboidnum; ic++)
            {
                int ct = HHvar.cellsoiltype[ic];
                Cellgq2k(HHvar.soilwaterpara.soilwas[ct], HHvar.soilwaterpara.soilwar[ct], HHvar.soilwaterpara.Ks[ct], HHvar.soilwaterpara.l[ct], HHvar.soilwaterpara.m[ct], soilwa[ic], soilice[ic], out K[ic]);
            }

        }

        public static void SoilwaterupdateCelia(int cuboidnum, double xlen, double ylen, double zlen, double dt, int[][] celltopo, double[] soilwaterold, double[] soilwaternew, double[] soilhnew, double[] VIC, double[] VICDT, double[] C, double[] K, double[] Wmatrixadd, double[] Wateradd, ref double[] a, ref double[] rhs)
        {
            int an = 0, li = 0; ;
            double ltemp = 0;
            for (int ic = 0; ic < cuboidnum; ic++)
            {
                ltemp = 0;
                rhs[ic] = C[ic] * soilhnew[ic] / dt - (soilwaternew[ic] - soilwaterold[ic]) / dt - (VICDT[ic] - VIC[ic]) / dt - Wateradd[ic] / zlen;
                if (celltopo[ic][3] >= 0)
                {
                    a[an] = -(K[celltopo[ic][3]] + K[ic]) / (2 * xlen * xlen);
                    ltemp -= a[an];
                    an += 1;
                }
                if (celltopo[ic][4] >= 0)
                {
                    a[an] = -(K[celltopo[ic][4]] + K[ic]) / (2 * ylen * ylen);
                    ltemp -= a[an];
                    an += 1;
                }
                if (celltopo[ic][5] >= 0)
                {
                    a[an] = -(K[celltopo[ic][5]] + K[ic]) / (2 * zlen * zlen);
                    ltemp -= a[an];
                    an += 1;
                    rhs[ic] += ((K[celltopo[ic][5]] + K[ic]) / (2 * zlen));
                }
                li = an;
                ltemp += C[ic] / dt;
                an += 1;
                if (celltopo[ic][6] >= 0)
                {
                    a[an] = -(K[celltopo[ic][6]] + K[ic]) / (2 * zlen * zlen);
                    ltemp -= a[an];
                    an += 1;
                    rhs[ic] += -1 * ((K[celltopo[ic][6]] + K[ic]) / (2 * zlen));
                }
                if (celltopo[ic][7] >= 0)
                {
                    a[an] = -(K[celltopo[ic][7]] + K[ic]) / (2 * ylen * ylen);
                    ltemp -= a[an];
                    an += 1;
                }

                if (celltopo[ic][8] >= 0)
                {
                    a[an] = -(K[celltopo[ic][8]] + K[ic]) / (2 * xlen * xlen);
                    ltemp -= a[an];
                    an += 1;
                }
                a[li] = ltemp + Wmatrixadd[ic] / zlen;
            }
        }

        /// <summary>
        /// Newton-Raphson方法求解Richards方程
        /// </summary>
        /// <param name="soiltosurface"></param>
        /// <param name="upfaceid"></param>
        /// <param name="NXCELL"></param>
        /// <param name="NYCELL"></param>
        /// <param name="rocknum"></param>
        /// <param name="soiltype"></param>
        /// <param name="soilwar"></param>
        /// <param name="EnvPro"></param>
        /// <param name="cuboidnum"></param>
        /// <param name="xlen"></param>
        /// <param name="ylen"></param>
        /// <param name="zlen"></param>
        /// <param name="dt"></param>
        /// <param name="celltopo"></param>
        /// <param name="soilwaterold"></param>
        /// <param name="soilwaternew"></param>
        /// <param name="soilhnew"></param>
        /// <param name="VIC"></param>
        /// <param name="VICDT"></param>
        /// <param name="ICES"></param>
        /// <param name="C"></param>
        /// <param name="K"></param>
        /// <param name="Wmatrixadd"></param>
        /// <param name="Wateradd"></param>
        /// <param name="RHOL"></param>
        /// <param name="RHOI"></param>
        /// <param name="solutenum"></param>
        /// <param name="soilsolunew"></param>
        /// <param name="a"></param>
        /// <param name="rhs"></param>
        /// <param name="outwa"></param>
        /// <param name="outwa2"></param>
        /// <param name="outso"></param>
        /// <param name="outso2"></param>
        /// <param name="soiltosurfaceDT"></param>
        public static void SoilwaterupdateNewRap(double[][][] soiltosurface, int[][] upfaceid, int NXCELL, int NYCELL, int rocknum, int[] soiltype, double[] soilwar, int EnvPro, int cuboidnum, double xlen, double ylen, double zlen, double dt, int[][] celltopo, double[] soilwaterold, double[] soilwaternew, double[] soilhnew, double[] VIC, double[] VICDT, int[] ICES, double[] C, double[] K, double[] Wmatrixadd, double[] Wateradd, double RHOL, double RHOI, double solutenum, double[][] soilsolunew, ref double[] a, ref double[] rhs, ref double[] outwa, ref double[] outwa2, ref double[][] outso, ref double[][] outso2, ref double[][][] soiltosurfaceDT)
        {
            int an = 0, li = 0;
            int ici = 0;
            double ltemp = 0;
            int soilboun = 2;//1：渗流   2：自由
            for (int i = 0; i < NXCELL; i++)
            {
                for (int j = 0; j < NYCELL; j++)
                {
                    if (upfaceid[i][j] >= 0)
                    {
                        for (int n = 0; n < 4; n++)
                        {

                            soiltosurfaceDT[i][j][n] = soiltosurface[i][j][n];

                        }
                    }
                }
            }
            for (int ic = 0; ic < cuboidnum; ic++)

            {
                int ct = soiltype[ic];
                double deltawa = 0.0;//壤中流部分
                double deltawaleft = 0.0;
                double deltawaback = 0.0;
                double deltawafront = 0.0;
                double deltawaright = 0.0;
                double deltabot = 0.0;//深层渗漏部分

                ltemp = 0;
                rhs[ic] = -(soilwaternew[ic] - soilwaterold[ic]) / dt - (VICDT[ic] - VIC[ic]) * SHAWconst.RHOI / SHAWconst.RHOL / dt + Wateradd[ic] / zlen;
                if (celltopo[ic][3] >= 0)
                {
                    ici = celltopo[ic][3];
                    a[an] = -(K[ici] + K[ic]) / (2 * xlen * xlen);
                    ltemp -= a[an];
                    rhs[ic] -= a[an] * (soilhnew[ici] - soilhnew[ic]);
                    //if (ICES[ici] == 1)
                    //{
                    //    a[an] = 0.0;
                    //}
                    an += 1;
                }
                else //左
                {
                    if (celltopo[ic][0] > 0)
                    {
                        if (upfaceid[celltopo[ic][0] - 1][celltopo[ic][1]] > 0 & celltopo[ic][2] > upfaceid[celltopo[ic][0] - 1][celltopo[ic][1]])
                        {
                            CellInterflow(soilboun, xlen, soilwaternew[ic], soilwar[ct], K[ic], soilhnew[ic], ref deltawaleft);

                        }
                    }

                }
                if (celltopo[ic][4] >= 0)
                {
                    ici = celltopo[ic][4];
                    a[an] = -(K[ici] + K[ic]) / (2 * ylen * ylen);
                    ltemp -= a[an];
                    rhs[ic] -= a[an] * (soilhnew[ici] - soilhnew[ic]);
                    //if (ICES[ici] == 1)
                    //{
                    //    a[an] = 0.0;
                    //}
                    an += 1;
                }
                else //后
                {
                    if (celltopo[ic][1] > 0)
                    {
                        if (upfaceid[celltopo[ic][0]][celltopo[ic][1] - 1] > 0 & celltopo[ic][2] > upfaceid[celltopo[ic][0]][celltopo[ic][1] - 1])
                        {
                            CellInterflow(soilboun, ylen, soilwaternew[ic], soilwar[ct], K[ic], soilhnew[ic], ref deltawaback);

                        }
                    }

                }

                if (celltopo[ic][5] >= 0)
                {
                    ici = celltopo[ic][5];
                    a[an] = -(K[ici] + K[ic]) / (2 * zlen * zlen);
                    ltemp -= a[an];
                    rhs[ic] += (K[ici] + K[ic]) / (2 * zlen);
                    rhs[ic] -= a[an] * (soilhnew[ici] - soilhnew[ic]);
                    //if (ICES[ici] == 1)
                    //{
                    //    a[an] = 0.0;
                    //}
                    an += 1;
                }
                li = an;
                ltemp += C[ic] / dt;
                an += 1;

                if (celltopo[ic][6] >= 0)
                {
                    ici = celltopo[ic][6];
                    a[an] = -(K[ici] + K[ic]) / (2 * zlen * zlen);
                    ltemp -= a[an];
                    rhs[ic] += -1 * (K[ici] + K[ic]) / (2 * zlen);
                    rhs[ic] -= a[an] * (soilhnew[ici] - soilhnew[ic]);
                    //if (ICES[ici] == 1)
                    //{
                    //   a[an] = 0.0;
                    //}
                    an += 1;
                }
                //基岩渗漏
                else
                {
                    Soilbot(soilwar[ct], zlen, dt, soilwaternew[ic], K[ic], ref deltabot);//渗漏率变化率                    

                }

                if (celltopo[ic][7] >= 0)
                {
                    ici = celltopo[ic][7];
                    a[an] = -(K[ici] + K[ic]) / (2 * ylen * ylen);
                    ltemp -= a[an];
                    rhs[ic] -= a[an] * (soilhnew[ici] - soilhnew[ic]);
                    //if (ICES[ici] == 1)
                    //{
                    //   a[an] = 0.0;
                    //}
                    an += 1;

                }


                else//前
                {
                    if (celltopo[ic][1] < NYCELL - 1)
                    {
                        if (upfaceid[celltopo[ic][0]][celltopo[ic][1] + 1] > 0 & celltopo[ic][2] > upfaceid[celltopo[ic][0]][celltopo[ic][1] + 1])
                        {
                            CellInterflow(soilboun, ylen, soilwaternew[ic], soilwar[ct], K[ic], soilhnew[ic], ref deltawafront);

                        }
                    }

                    if (celltopo[ic][1] >= NYCELL - 1 & ct < rocknum - 1)
                    {
                        CellInterflow(soilboun, ylen, soilwaternew[ic], soilwar[ct], K[ic], soilhnew[ic], ref deltawa);//坡脚壤中流                        

                    }

                }

                if (celltopo[ic][8] >= 0)
                {
                    ici = celltopo[ic][8];
                    a[an] = -(K[ici] + K[ic]) / (2 * xlen * xlen);
                    ltemp -= a[an];
                    rhs[ic] -= a[an] * (soilhnew[ici] - soilhnew[ic]);
                    //if (ICES[ici] == 1)
                    //{
                    //   a[an] = 0.0;
                    //}
                    an += 1;
                }
                else //右
                {
                    if (celltopo[ic][0] < NXCELL - 1)
                    {
                        if (upfaceid[celltopo[ic][0] + 1][celltopo[ic][1]] > 0 & celltopo[ic][2] > upfaceid[celltopo[ic][0] + 1][celltopo[ic][1]])
                        {
                            CellInterflow(soilboun, xlen, soilwaternew[ic], soilwar[ct], K[ic], soilhnew[ic], ref deltawaright);

                        }
                    }

                }
                a[li] = ltemp + Wmatrixadd[ic];
                //if (ICES[ici] == 1)
                //{
                //    a[li] = RHOI / RHOL / dt + Wmatrixadd[ic];
                //}


                //deltabot = 0.0;
                // deltawa = 0.0;
                deltawaback = 0.0;
                deltawafront = 0.0;
                deltawaleft = 0.0;
                deltawaright = 0.0;//关掉开口。因为还未耦合地表溶质，因此如果打开returnflow开口，会导致溶质不平衡
                double deltaall = deltabot + deltawa + deltawaback + deltawafront + deltawaleft + deltawaright;
                double ablewater = (soilwaternew[ic] - SHAWconst.LWcon * soilwar[ct]) / dt;//当前单元的可用水量
                if (ablewater > 0.0)
                {
                    if (deltaall > ablewater)
                    {
                        deltabot = ablewater * deltabot / deltaall;
                        deltawa = ablewater * deltawa / deltaall;
                        deltawaback = ablewater * deltawaback / deltaall;
                        deltawafront = ablewater * deltawafront / deltaall;
                        deltawaleft = ablewater * deltawaleft / deltaall;
                        deltawaright = ablewater * deltawaright / deltaall;
                    }
                }
                else
                {
                    rhs[ic] = -(soilwaternew[ic] - SHAWconst.LWcon * soilwar[ct]) / dt;
                    deltabot = 0.0;
                    deltawa = 0.0;
                    deltawaback = 0.0;
                    deltawafront = 0.0;
                    deltawaleft = 0.0;
                    deltawaright = 0.0;
                }
                rhs[ic] -= (deltabot + deltawa + deltawaback + deltawafront + deltawaleft + deltawaright);
                outwa2[ic] = deltabot * xlen * ylen * zlen * dt;
                outwa[ic] = deltawa * xlen * ylen * zlen * dt;//单位：m3
                for (int solu = 0; solu < solutenum; solu++)
                {
                    outso[solu][ic] = outwa[ic] * soilsolunew[solu][ic] * SHAWconst.RHOL;
                    outso2[solu][ic] = outwa2[ic] * soilsolunew[solu][ic] * SHAWconst.RHOL;
                }
                soiltosurfaceDT[celltopo[ic][0]][celltopo[ic][1]][1] += deltawaback * zlen * dt;
                soiltosurfaceDT[celltopo[ic][0]][celltopo[ic][1]][2] += deltawafront * zlen * dt;
                soiltosurfaceDT[celltopo[ic][0]][celltopo[ic][1]][3] += deltawaright * zlen * dt;
            }
        }

        /// <summary>
        /// 求解比水容量C
        /// </summary>
        /// <param name="HHvar"></param>
        /// <param name="soilh"></param>
        /// <param name="soilwa"></param>
        /// <param name="soilice"></param>
        /// <param name="C"></param>
        public static void Soilwatcap(HHMMvar HHvar, double[] soilh, double[] soilwa, double[] soilice, ref double[] C)
        {
            for (int ic = 0; ic < HHvar.cuboidnum; ic++)
            {
                int ct = HHvar.cellsoiltype[ic];
                CellSoilwatcap(soilh[ic], soilwa[ic], HHvar.soilwaterpara.soilwas[ct], HHvar.soilwaterpara.soilwar[ct], HHvar.soilwaterpara.avg[ct], HHvar.soilwaterpara.m[ct], HHvar.soilwaterpara.n[ct], soilice[ic], ref C[ic]);
            }
        }

        /// <summary>
        /// 求解比水容量C
        /// </summary>
        /// <param name="soilh"></param>
        /// <param name="soilwa"></param>
        /// <param name="soilwas"></param>
        /// <param name="soilwar"></param>
        /// <param name="avg"></param>
        /// <param name="m"></param>
        /// <param name="n"></param>
        /// <param name="soilice"></param>
        /// <param name="C"></param>
        public static void CellSoilwatcap(double soilh, double soilwa, double soilwas, double soilwar, double avg, double m, double n, double soilice, ref double C)
        {//求解比水容量C
            double temp;
            soilwas = Math.Max(SHAWconst.LWcon * soilwar, soilwas - soilice);
            if (soilwa >= soilwas)
            {
                C = 0.000000000001;
            }
            else
            {
                temp = 1 + Math.Pow(-1.0 * avg * soilh, n);
                C = Math.Pow(avg, n) * (soilwas - soilwar) * m * n * Math.Pow(-1.0 * soilh, (n - 1)) / Math.Pow(temp, (m + 1)) + 0.000000000001;
            }
        }

        /// <summary>
        /// 底部自由边界
        /// </summary>
        /// <param name="soilwar"></param>
        /// <param name="zlen"></param>
        /// <param name="dt"></param>
        /// <param name="soilwater"></param>
        /// <param name="K"></param>
        /// <param name="bot"></param>
        public static void Soilbot(double soilwar, double zlen, double dt, double soilwater, double K, ref double bot)
        {
            bot = Math.Max(0.0, Math.Min((soilwater - SHAWconst.LWcon * soilwar) / dt, K / zlen));
        }

        /// <summary>
        /// 两种边界条件
        /// </summary>
        /// <param name="soilboun"></param>
        /// <param name="y"></param>
        /// <param name="soilwater"></param>
        /// <param name="soilwar"></param>
        /// <param name="K"></param>
        /// <param name="soilh"></param>
        /// <param name="deltawa"></param>
        public static void CellInterflow(int soilboun, double y, double soilwater, double soilwar, double K, double soilh, ref double deltawa)
        {
            switch (soilboun)
            {
                case 1:
                    Seepboun(y, K, soilh, ref deltawa);
                    break;

                case 2:
                    Freeboun(y, soilwater, soilwar, K, ref deltawa);
                    break;
            }
        }

        /// <summary>
        /// 渗流边界
        /// </summary>
        /// <param name="y"></param>
        /// <param name="K"></param>
        /// <param name="soilh"></param>
        /// <param name="deltawa"></param>
        public static void Seepboun(double y, double K, double soilh, ref double deltawa)
        {
            double BGRF = 1;//边界梯度折减系数
            double h0 = 0.0;//水势阈值m
            if (soilh <= h0)
            {
                deltawa = 0.0;
            }
            else
            {
                deltawa = K * (soilh - h0) / (BGRF * y * y);
            }
        }

        /// <summary>
        /// 自由边界
        /// </summary>
        /// <param name="y"></param>
        /// <param name="soilwater"></param>
        /// <param name="soilwar"></param>
        /// <param name="K"></param>
        /// <param name="deltawa"></param>
        public static void Freeboun(double y, double soilwater, double soilwar, double K, ref double deltawa)
        {

            if (soilwater <= SHAWconst.LWcon * soilwar)
            {
                deltawa = 0.0;
            }
            else
            {
                deltawa = K / y;
            }
        }

    }
}
