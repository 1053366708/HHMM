﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HHMM
{
    public class SHAWRad
    {
        /// <param name="Decline">太阳赤纬</param>
        /// <param name="Hafday">half day angel</param>
        /// <param name="Clouds">云盖因子</param>
        public static double Decline;
        public static double Hafday;
        public static double Clouds;
        public static double[][] Aspect_rad;
        public static double[][] Slope_rad;


        /// <summary>
        /// 考虑当前日历天,计算太阳参数
        /// </summary>
        /// <param name="Day">儒略日</param>
        /// <param name="Latitude">所处纬度</param>
        /// <param name="Solard">日太阳辐射</param>
        public static void Daypar(int Day, double Latitude, double Solard)
        {
            double Coshalf;
            Decline = 0.4102 * Math.Sin(2.0 * Math.PI * (Day - 80.0) / 365.0);  //太阳赤纬。弧度制
            Coshalf = -1.0 * Math.Tan(Latitude) * Math.Tan(Decline);//日落时角
            if (Math.Abs(Coshalf) >= 1.0)
            {
                if (Coshalf >= 1.0)
                {
                    Hafday = 0.0;//？极夜
                }
                else
                {
                    Hafday = 2.0 * Math.PI;//？极昼。为什么是2pi
                }
            }
            else
            {
                Hafday = Math.Acos(Coshalf);//日落时角，0~pi
            }

            double Sunmax = 24 * SHAWconst.SOLCON * (Hafday * Math.Sin(Latitude) * Math.Sin(Decline) + Math.Cos(Latitude) * Math.Cos(Decline) * Math.Sin(Hafday)) / Math.PI;//地外辐射
            double Ttoal = 24 * Solard / Sunmax; //计算外大气和地面直接辐射比
            Clouds = (2.4 - 4.0 * Ttoal);
            if (Clouds > 1.0)
            {
                Clouds = 1.0;
            }
            if (Clouds < 0.0)
            {
                Clouds = 0.0;
            }

            //计算云盖因子
        }

        /// <summary>
        /// 基于小时观测的辐射计算时直接辐射和散射辐射
        /// </summary>
        /// <param name="Hour">当前时刻</param>
        /// <param name="Latitude">计算点纬度</param>
        /// <param name="Hrnoon">中午时刻</param>
        /// <param name="Hafday">半天长度</param>
        /// <param name="Radhourobs"> 观测太阳辐射</param>
        /// <param name="Direct">直接辐射</param>
        /// <param name="Diffus">散射辐射</param>
        /// <param name="Altitu">太阳高度角</param>
        public static void Solar(int Hour, double Latitude, double Hrnoon, double Radhourobs, ref double[][] Direct, ref double[][] Diffus, ref double Altitu)
        {
            int NX, NY;
            double Sunris, Sunset;
            double Sinalt, Azm;
            double Ttotal, Tdiffu;
            double Radhourmax, Dirhour;
            double Hrangl, Ihr;
            double Sunslp;
            NX = Direct.Length;
            NY = Direct[0].Length;

            if (Radhourobs <= 0)                  //如果太阳辐射小于0则不计算，辐射的两个分量都为0，直接跳出
            {
                Sunris = Hrnoon - Hafday / 0.261799;  //计算太阳升起的时间
                Sunset = Hrnoon + Hafday / 0.261799;  //计算太阳降落的时间

                //Ihr = (Hour - 0.5);//?t,当前时刻
                Ihr = (Hour);
                if ((Hour > Sunris) && ((Hour + 1) < Sunris))
                {
                    Ihr = (Sunris + Hour) / 2.0;
                }
                if ((Hour > Sunset) && (Hour - 1) < Sunset)
                {
                    Ihr = (Sunset - (Sunset - (Hour - 1)) / 2.0);
                }                                  //将该计算时间插值

                Hrangl = 0.261799 * (Ihr - Hrnoon);//太阳光在当前时间的几何结构。pi(t-t0)/12
                Sinalt = Math.Sin(Latitude) * Math.Sin(Decline) + Math.Cos(Latitude) * Math.Cos(Decline) * Math.Cos(Hrangl);
                //Radhourmax = SHAWconst.SOLCON * Sinalt;   //计算辐射
                Altitu = Math.Asin(Sinalt);   //太阳在地平线上的高度角
                for (int i = 0; i < NX; i++)
                {
                    for (int j = 0; j < NY; j++)
                    {
                        Direct[i][j] = 0.0;
                        Diffus[i][j] = 0.0;
                    }
                }
            }
            else
            {
                Sunris = Hrnoon - Hafday / 0.261799;  //计算太阳升起的时间
                Sunset = Hrnoon + Hafday / 0.261799;  //计算太阳降落的时间

                Ihr = (Hour - 0.5);//t,当前时刻
                //Ihr = (Hour);
                if ((Hour > Sunris) && ((Hour - 1) < Sunris))
                {
                    Ihr = (Sunris + Hour) / 2.0;
                }
                if ((Hour > Sunset) && (Hour - 1) < Sunset)
                {
                    Ihr = (Sunset - (Sunset - (Hour - 1)) / 2.0);
                }                                  //将该计算时间插值

                Hrangl = 0.261799 * (Ihr - Hrnoon);//太阳光在当前时间的几何结构。pi(t-t0)/12 
                Sinalt = Math.Sin(Latitude) * Math.Sin(Decline) + Math.Cos(Latitude) * Math.Cos(Decline) * Math.Cos(Hrangl);
                Radhourmax = SHAWconst.SOLCON * Sinalt;   //计算辐射
                Altitu = Math.Asin(Sinalt);   //太阳在地平线上的高度角
                Azm = Math.Asin(-1 * Math.Cos(Decline) * Math.Sin(Hrangl) / Math.Cos(Altitu));   //考虑坡度坡向时计算  
                if ((Latitude - Decline) >= 0)
                {
                    Azm = Azm - Math.PI;
                }

                if ((Radhourmax <= 0) | (Altitu <= 0))
                {
                    for (int i = 0; i < NX; i++)
                    {
                        for (int j = 0; j < NY; j++)
                        {
                            Diffus[i][j] = Radhourobs;
                            Direct[i][j] = 0;
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < NX; i++)
                    {
                        for (int j = 0; j < NY; j++)
                        {

                            Sunslp = Math.Asin(Math.Sin(Altitu) * Math.Cos(Slope_rad[i][j]) + Math.Cos(Altitu) * Math.Sin(Slope_rad[i][j]) * Math.Cos(Azm - Aspect_rad[i][j]));
                            Ttotal = Radhourobs / Radhourmax;//计算太阳辐射实际和潜在比
                            if (Ttotal > SHAWconst.DIFATM)
                            {
                                Ttotal = SHAWconst.DIFATM;
                            }
                            Tdiffu = Ttotal * (1.0 - Math.Exp(0.6 * (1.0 - SHAWconst.DIFATM / Ttotal) / (SHAWconst.DIFATM - 0.4))); //散射辐射比
                            Diffus[i][j] = Tdiffu * Radhourmax;                             //散射辐射
                            Dirhour = Radhourobs - Diffus[i][j]; //水平面的直接辐射 

                            if (Sunslp <= 0.0)
                            {
                                Direct[i][j] = 0.0;
                            }
                            else
                            {
                                Direct[i][j] = Dirhour * Math.Sin(Sunslp) / Math.Sin(Altitu);
                                if (Direct[i][j] > 5.0 * Dirhour)
                                {
                                    Direct[i][j] = 5.0 * Dirhour;   //直接太阳辐射
                                }
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 地表接受的短波辐射，包括直接辐射和散射辐射
        /// </summary>
        /// <param name="Direct">直接辐射</param>
        /// <param name="Diffus">散射辐射</param>
        /// <param name="ALBDRY">干土的地表反射率</param>
        /// <param name="ALBEXP">湿土的地表反射率</param>
        /// <param name="soilwater">土壤水分</param>
        /// <param name="Swsoil">地表接受的辐射</param>
        public static void SWRBAL(int NSP, double soilwater, double ALBDRY, double ALBEXP, double[] DZSP, double[] ZSP, double[] RHOSP, double Direct, double Diffus, ref double[] SWSNOW, ref double Swsoil)
        {
            double Albsoil;
            Albsoil = ALBDRY * Math.Exp(-ALBEXP * soilwater);   //地表辐射率计算。土壤反照率
            double ALBNXT = Albsoil;
            double ALBSNO = 0.0;
            if ((Direct + Diffus) <= 0)
            {
                if (NSP >= 0)
                {
                    SWSNOW = new double[NSP];
                    for (int i = 0; i < NSP; i++)
                    {
                        SWSNOW[i] = 0.0;
                    }
                }
                Swsoil = 0.0;
            }
            else
            {
                if (NSP > 0)
                {
                    SWSNOW = new double[NSP];
                    ALBSNO = SHAWSnow.SNOALB(RHOSP[0], ZSP[NSP], ALBNXT);//雪的反照率
                    //ALBSNO = 0.1;
                    SHAWSnow.SWRSNO(NSP, ALBSNO, DZSP, RHOSP, ref Direct, ref Diffus, ref SWSNOW);
                    Albsoil = 0.0;
                }
                Swsoil = (Direct + Diffus) * (1 - Albsoil); //土壤地表接受的短波辐射
            }
        }

        /// <summary>
        /// 大气长波计算，一个小区域用一个长波,每小时计算一个
        /// </summary>
        /// <param name="Wt">步长权重</param>
        /// <param name="Ta">计算步长初始温度</param>
        /// <param name="Tadt">计算步长结束温度</param>
        /// <param name="CLOUDS">计算云盖因子</param>
        /// <param name="Above">计算的大气长波辐射</param>
        public static double LWRATM(double Wt, double Ta, double Tadt)
        {
            double Above;
            double EMITAT;
            double Tamean;
            Tamean = Wt * Ta + (1.0 - Wt) * Tadt;                            //平均气温计算
            EMITAT = 1 - SHAWconst.EMATM1 * Math.Exp(-SHAWconst.EMATM2 * Math.Pow(Tamean, 2));     //晴空大气辐射系数
            EMITAT = (1 - 0.84 * Clouds) * EMITAT + 0.84 * Clouds;//考虑云的大气辐射系数
            Above = EMITAT * SHAWconst.STEFAN * Math.Pow((Tamean + SHAWconst.Tk0), 4);     //大气长波辐射
            return Above;
        }

        /// <summary>
        /// 地表长波收入计算，每个表层网格单独计算，每个计算时刻单独计算
        /// </summary>
        /// <param name="Above">入射长波</param>
        /// <param name="Ts">计算步初始地表温度</param>
        /// <param name="Tsdt">计算步结束地表温度</param>
        /// <param name="Lwsoil">长波辐射计算</param>
        public static void LWRBAL(int NSP, ref double ABOVE, double TS, double TSDT, double[] TSP, double[] TSPDT, ref double[] LWSNOW, ref double LWSOIL)
        {
            double BELOW;
            if (NSP > 0)
            {
                LWSNOW = new double[2];
                LWSNOW[0] = 0.0;
                LWSNOW[1] = 0.0;
                SHAWSnow.LWRSNO(TSP[0], TSPDT[0], ref ABOVE, ref LWSNOW[0], ref LWSNOW[1]);
                LWSNOW[0] += LWSNOW[1];
                LWSNOW[1] = 0.0;
                LWSOIL = 0.0;
                BELOW = ABOVE;
                return;
            }

            double TSK = TS + SHAWconst.Tk0;  //温度转换
            BELOW = SHAWconst.EMITS * SHAWconst.STEFAN * (Math.Pow(TSK, 4) + 4 * SHAWconst.WDT * Math.Pow(TSK, 3) * (TSDT - TS)); //基于泰勒展开的地表长波辐射计算
            LWSOIL = SHAWconst.EMITS * ABOVE - BELOW;
        }

        /// <summary>
        /// 长波辐射的能量平衡矩阵贡献
        /// </summary>
        /// <param name="TS"></param>
        /// <param name="B"></param>
        public static void LWRMAT(int NSP, int[] ICESPT, double[] TSP, double TS, ref double[] A1, ref double[] B1, ref double[] C1, ref double[] D1, out double B)
        {
            int N = 0;
            int MATERIAL = 2;

            B = 0.0;
            if (NSP > 0)
            {
                A1 = new double[NSP + 1];
                B1 = new double[NSP + 1];
                C1 = new double[NSP + 1];
                D1 = new double[NSP + 1];
                B1[N] = 0.0;
                if (ICESPT[0] > 0)
                {
                    if (MATERIAL > 2)
                    {
                        A1[N] = A1[N] * SHAWconst.EMITSP;
                        C1[N - 1] = 0.0;
                    }
                    B1[N] = 0.0;
                }
                else
                {
                    double TSP3 = SHAWconst.STEFAN * 4 * SHAWconst.WDT * Math.Pow((TSP[0] + SHAWconst.Tk0), 3);
                    if (MATERIAL > 2)
                    {
                        A1[N] = A1[N] * SHAWconst.EMITSP;
                        C1[N - 1] = C1[N - 1] * SHAWconst.EMITSP * TSP3;
                    }
                    B1[N] = -1.0 * SHAWconst.EMITSP * TSP3;
                }
                N = N + NSP;
                MATERIAL += 1;
                if (NSP > 1)
                    B1[N - 1] = 0.0;
                C1[N - 1] = 0.0;
                goto TC;
            }

            double TS3 = SHAWconst.STEFAN * 4.0 * SHAWconst.WDT * Math.Pow((TS + SHAWconst.Tk0), 3);
            /*
            if (MATERIAL > 2)
            {
                A = A1[N] * SHAWconst.EMITS;
                C1[N - 1] = C1[N - 1] * SHAWconst.EMITS * TS3;
            }*/
            B = -1.0 * SHAWconst.EMITS * TS3;
        TC:
            return;
        }

        /// <summary>
        /// 每层的source-sink项
        /// </summary>
        /// <param name="NSP"></param>
        /// <param name="SWSNOW"></param>
        /// <param name="LWSNOW"></param>
        /// <param name="SWSOIL"></param>
        /// <param name="LWSOIL"></param>
        /// <param name="SSP"></param>
        /// <param name="SS"></param>
        public static void SOURCE(int NSP, double[] SWSNOW, double[] LWSNOW, double SWSOIL, double LWSOIL, ref double[] SSP, ref double SS)
        {//汇总每个节点的source-sink项。
            if (NSP > 0)
            {//雪层节点
                SSP = new double[NSP];
                for (int i = 0; i < NSP; i++)
                {
                    SSP[i] = SWSNOW[i];
                }
                SSP[0] += LWSNOW[0];
                SSP[NSP - 1] += LWSNOW[1];
            }
            //土壤节点
            SS = SWSOIL + LWSOIL;
        }



        /// <summary>
        /// 坡度坡向分析
        /// </summary>
        /// <param name="cellsize"></param>
        /// <param name="dem"></param>
        public static void Aspectslopecal(double cellsize, double[][] dem) //参考arcgis，https://desktop.arcgis.com/zh-cn/arcmap/10.3/tools/spatial-analyst-toolbox/how-aspect-works.htm
        {
            int NX = dem.Length;
            int NY = dem[0].Length;
            double Slopezx = 0, Slopezy = 0;
            Aspect_rad = new double[NX][];
            Slope_rad = new double[NX][];
            for (int i = 0; i < NX; i++)
            {
                Aspect_rad[i] = new double[NY];
                Slope_rad[i] = new double[NY];
                for (int j = 0; j < NY; j++)
                {

                    int leftindex = Math.Max(i - 1, 0);
                    int rightindex = Math.Min(i + 1, NX - 1);
                    int bottomindex = Math.Min(j + 1, NY - 1);
                    int topindex = Math.Max(j - 1, 0);
                    Slopezx = ((dem[rightindex][topindex] + 2 * dem[rightindex][j] + dem[rightindex][bottomindex]) - (dem[leftindex][bottomindex] + dem[leftindex][topindex] + 2 * dem[leftindex][j])) / (8.0 * cellsize);
                    Slopezy = ((dem[leftindex][bottomindex] + 2 * dem[i][bottomindex] + dem[rightindex][bottomindex]) - (dem[leftindex][topindex] + 2 * dem[i][topindex] + dem[rightindex][topindex])) / (8.0 * cellsize);
                    //？Slope_rad[i][j] = Math.Atan(Math.Sqrt(Math.Pow(Slopezy, 2) + Math.Pow(Slopezx, 2))) / 180.0 * Math.PI;
                    Slope_rad[i][j] = Math.Atan(Math.Sqrt(Math.Pow(Slopezy, 2) + Math.Pow(Slopezx, 2)));//?本身就是弧度单位值了
                    if (Slopezx != 0)
                    {
                        //？Aspect_rad[i][j] = Math.Atan2(Slopezy, -1 * Slopezx) / 180.0 * Math.PI;
                        Aspect_rad[i][j] = Math.Atan2(Slopezy, -1 * Slopezx);
                        if (Aspect_rad[i][j] < 0)
                        {
                            Aspect_rad[i][j] = 2.0 * Math.PI + Aspect_rad[i][j];
                        }
                    }
                    else
                    {
                        if (Slopezy >= 0)
                        {
                            Aspect_rad[i][j] = Math.PI / 2.0;
                        }
                        else
                        {
                            Aspect_rad[i][j] = 2.0 * Math.PI - Math.PI / 2.0;
                        }
                    }
                }
            }
        }

        public static void Hillshadecal(double Altitude, double Azimuth, double[][] Aspect_rad, double[][] Slope_rad, ref double[][] Hillshade)
        {
            int NX = Aspect_rad.GetLength(0);
            int NY = Aspect_rad.GetLength(1);
            ///Hillshade = 255.0 * ((cos(Zenith_rad) * cos(Slope_rad)) +                  (sin(Zenith_rad) * sin(Slope_rad) * cos(Azimuth_rad - Aspect_rad)))
            ///
            //高度角转为天顶角
            double Zenith_deg = 90 - Altitude;
            //天顶角转为弧度
            double Zenith_rad = Zenith_deg * Math.PI / 180.0;
            //将天顶角从地理单位（罗盘方向）转换为数学单位（直角）
            double Azimuth_math = 360.0 - Azimuth + 90.0;
            if (Azimuth_math >= 360.0)
            {
                Azimuth_math = Azimuth_math - 360.0;
            }
            double Azimuth_rad = Azimuth_math * Math.PI / 180.0;
            for (int i = 0; i < NX; i++)
            {
                for (int j = 0; j < NY; j++)
                {
                    Hillshade[i][j] = 255.0 * ((Math.Cos(Zenith_rad * SHAWconst.RadDegTrans) * Math.Cos(Slope_rad[i][j] * SHAWconst.RadDegTrans)) + (Math.Sin(Zenith_rad * SHAWconst.RadDegTrans) * Math.Sin(Slope_rad[i][j] * SHAWconst.RadDegTrans) * Math.Cos((Azimuth_rad - Aspect_rad[i][j]) * SHAWconst.RadDegTrans)));
                }
            }
        }



    }
}
