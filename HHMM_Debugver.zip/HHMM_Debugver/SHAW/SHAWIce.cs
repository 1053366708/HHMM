﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace HHMM
{
    public class SHAWIce
    {
        /// <summary>
        /// 计算含冰量及土壤水分和水势的变化
        /// </summary>
        /// <param name="HHvar">HH模型变量</param>
        /// <param name="TVvar">TV模型变量</param>
        public static void Soilicecal(HHMMvar HHvar, SHAWvar TVvar)
        {

            for (int ic = 0; ic < HHvar.cuboidnum; ic++)
            {
                if (TVvar.heatphas.TS[ic] < 0.0)
                {
                    int ct = HHvar.cellsoiltype[ic];
                    Frozen(HHvar.soilwaterpara.soilwas[ct], HHvar.soilwaterpara.soilwar[ct], HHvar.soilwaterpara.avg[ct], HHvar.soilwaterpara.m[ct], HHvar.soilwaterpara.n[ct], TVvar.heatphas.TS[ic], ref TVvar.waterphas.VLC[ic], ref TVvar.waterphas.MAT[ic], ref TVvar.icephas.VIC[ic], ref TVvar.icephas.ICES[ic]);
                }

            }
        }
        /// <summary>
        /// 单个网格基于冰点水势计算含冰量，如果考虑不同溶质引起的水势变化，这部分算法要调整，因为土壤含水量变化后，盐分浓度会变化，进而引起水势的跌宕变化；
        /// </summary>
        /// <param name="soilTs">土壤温度</param>
        /// <param name="soilwa">土壤含水量</param>
        /// <param name="soilh">土壤水势</param>
        /// <param name="soilice">土壤含冰量</param>
        /// <param name="soilicesta">是否结冰</param>
        /// <param name="soilwas">土壤饱和含水率</param>
        /// <param name="soilwar">土壤残余含水率</param>
        /// <param name="soilavg">VG模型参数a</param>
        /// <param name="soilm">VG模型参数m</param>
        /// <param name="soiln">VG模型参数n</param>
        public static void Frozen(double soilwas, double soilwar, double soilavg, double soilm, double soiln, double soilTs, ref double soilwa, ref double soilh, ref double soilice, ref int soilicesta)
        {//计算单个网格的含冰量
            double TMP, TOTPOT, VLCmax, change;
            TMP = soilTs + SHAWconst.Tk0;//土壤温度，K
            TOTPOT = SHAWconst.LF * soilTs / TMP / SHAWconst.G;//水势。当存在冰的时候，总的水势等于基质势，通过温度来表述                      
            SHAWWater.Cellgy2q(soilwas, soilwar, soilavg, soilm, soiln, TOTPOT, 0, out VLCmax);//根据水势求土壤含水率            

            if (((soilwa + soilice * SHAWconst.RHOI / SHAWconst.RHOL) < VLCmax) || (TOTPOT >= 0))
            {
                change = Math.Min(soilice, SHAWconst.ICEstep);
                soilwa += change * SHAWconst.RHOI / SHAWconst.RHOL;
                soilice -= change;
                if (soilice <= 0.0)
                {
                    soilicesta = 0;//不结冰
                }
            }
            else
            {
                soilicesta = 1;//结冰
                change = Math.Max(Math.Min((soilwa - VLCmax) * SHAWconst.RHOL / SHAWconst.RHOI, SHAWconst.ICEstep), -1 * SHAWconst.ICEstep);
                soilice += change;
                soilwa -= change * SHAWconst.RHOI / SHAWconst.RHOL;

            }

            SHAWWater.Cellgq2y(soilwas, soilwar, soilavg, soilm, soiln, soilwa, soilice, out soilh);//求解水势

        }

        /// <summary>
        /// 冻结期间，含水量对于温度的变化
        /// </summary>
        /// <param name="CONC"></param>
        /// <param name="SOILT"></param>
        /// <param name="soilwa">土壤含水率</param>
        /// <param name="MAT"></param>
        /// <param name="SALTKQ"></param>
        /// <param name="soilwar">土壤残余含水率</param>
        /// <param name="soilm"></param>
        /// <param name="soiln"></param>
        /// <param name="soilavg"></param>
        /// <param name="RHOB">矿物质热容量</param>
        /// <param name="RHOL"></param>
        /// <param name="UGAS"></param>
        /// <param name="Tk0"></param>
        /// <param name="LF"></param>//冰熔解热 J/Kg
        /// <returns></returns>
        public static double FSLOPE(double soilt, double soilwa, double soilh, double soilwar, double soilavg, double soilm, double soiln, double RHOB)
        {
            //double[] CONC,
            // double[] SALTKQ,
            double DLDT = 0;
            double DKQ = 0, CNCGAS = 0.0, CRT = 0.0;
            double TMP = soilt + SHAWconst.Tk0;
            //int NSALT = SALTKQ.Length;
            /*
            for (int j = 0; j < NSALT; j++)
            {
                DKQ = SALTKQ[j] + soilwa * RHOL / RHOB;
                CNCGAS = CNCGAS + CONC[j]*UGAS;
                CRT = CRT + CONC[j] * UGAS * TMP * RHOL / RHOB / DKQ;
            }*/
            DLDT = (SHAWconst.LF / TMP + CNCGAS) / ((1 + Math.Pow(-1 * soilavg * soilh, soiln)) / (Math.Pow(-1 * soilavg * soilh, (soiln - 1)) * (soilm * soiln * soilavg) * (soilwa - soilwar)) - CRT);//冻结期间含水率计算
            return DLDT;
        }

        /// <summary>
        /// 调整冻土状态
        /// </summary>
        /// <param name="CONC"></param>
        /// <param name="soilwa">土壤含水率</param>
        /// <param name="soilh">土壤水势</param>
        /// <param name="soilt">土壤温度</param>
        /// <param name="soilice">土壤含冰量</param>
        /// <param name="soilicesta">是否结冰</param>
        /// <param name="CS">土壤热容</param>
        /// <param name="SALTKQ"></param>
        /// <param name="soilwas">土壤饱和含水率</param>
        /// <param name="soilwar">土壤残余含水率</param>
        /// <param name="soilavg"></param>
        /// <param name="soilm"></param>
        /// <param name="soiln"></param>
        /// <param name="RHOL">水密度</param>
        /// <param name="RHOB">矿物质热容量</param>
        /// <param name="UGAS"></param>
        /// <param name="Tk0">开尔文温度</param>
        /// <param name="LF">冰溶解热</param>
        /// <param name="G">重力加速度</param>
        public static void Adjust(ref double soilwa, ref double soilh, ref double soilt, ref double soilice, ref int soilicesta, double CS, double[] SALTKQ, double soilwas, double soilwar, double soilavg, double soilm, double soiln, double RHOL, double RHOI, double RHOB, double UGAS, double Tk0, double LF, double G)
        {
            // double[] CONC,
            //soilwa = soilwa + RHOL / RHOB * soilice;//土壤含水量计算 /？错了

            soilwa = soilwa + RHOI / RHOL * soilice;
            soilice = 0.0;
            SHAWWater.Cellgq2y(soilwas, soilwar, soilavg, soilm, soiln, soilwa, soilice, out soilh);//求解水势

            double TOTPOT = soilh;//水势
            double TMPFRZ = Tk0 * TOTPOT / (LF / G - TOTPOT);//冻结温度 ℃
            double TMPF = TMPFRZ + Tk0;//温度 K
            double ENERGY = CS * (TMPFRZ - soilt);//土壤热容*温差=能量  （可用于冻结水的能量)
                                                  // double DLDT = FSLOPE(soilt, soilwa, soilh, soilwar, soilavg, soilm, soiln, RHOB);//冻结期间，含水量随温度的变化//?温度错了
                                                  //double DLDT = FSLOPE(TMPFRZ, soilwa, soilh, soilwar, soilavg, soilm, soiln, RHOB);
            double DLDT = 0.0;
            double EFFECTS = CS + RHOL * LF * DLDT;//计算有效热容，包括潜热项
            soilt = TMPFRZ - ENERGY / EFFECTS;//调整土壤温度
            Frozen(soilwas, soilwar, soilavg, soilm, soiln, soilt, ref soilwa, ref soilh, ref soilice, ref soilicesta);//再通过温度的变化来计算含冰量
        }
    }
}
