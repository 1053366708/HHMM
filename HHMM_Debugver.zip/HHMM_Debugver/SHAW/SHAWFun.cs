﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CSparse;
using CSparse.Storage;
using CSparse.Double.Factorization;
using CSparse.IO;
using CSparse.Ordering;
using CSparse.Double;

namespace HHMM
{
    /// <summary>
    /// 方程求解
    /// </summary>
    public class SHAWFun
    {
        public static CompressedColumnStorage<double> spaccell = null;
        public static double[][] modelcell = null;
        public static double[] cellord = null;

        /// <summary>
        /// 创建稀疏矩阵
        /// </summary>
        /// <param name="TVvar"></param>
        public static void CSparsecreate(SHAWvar TVvar)
        {
            spaccell = null;
            modelcell = new double[TVvar.nnum][];
            for (int i = 0; i < TVvar.nnum; i++)
            {
                modelcell[i] = new double[TVvar.nnum];
            }
            for (int i = 0; i < TVvar.nznum; i++)
            {
                modelcell[TVvar.mumpsSHAW.irn[i]][TVvar.mumpsSHAW.jcn[i]] = i + 1;
            }
            spaccell = Converter.ToCompressedColumnStorage(modelcell);//列主序压缩稀疏矩阵
            cellord = (double[])spaccell.Values.Clone();
        }


        public static void SHAWheatcal(HHMMvar HHvar, SHAWvar TVvar, double Timestep, ref double[] hxc)
        {
            SHAWWater.Gq2k(HHvar, TVvar.waterphas.VLCDT, TVvar.icephas.VICDT, ref TVvar.waterphas.K);//求解土壤不饱和导水率K
            SHAWHeat.Soilheatcal(HHvar, TVvar, Timestep);
            hxc = new double[TVvar.nnum];
            for (int i = 0; i < TVvar.nznum; i++)
            {
                spaccell.Values[i] = TVvar.mumpsSHAW.a[(int)cellord[i] - 1];
            }
            if (TVvar.Nummethod == 1)
            {
                var lu = SparseLU.Create(spaccell, ColumnOrdering.MinimumDegreeAtPlusA, 1.0);
                lu.Solve(TVvar.mumpsSHAW.rhs, hxc);
            }
            else
            {
                var qr = SparseQR.Create(spaccell, ColumnOrdering.MinimumDegreeAtA);
                qr.Solve(TVvar.mumpsSHAW.rhs, hxc);
            }
        }

        public static void SHAWwatercal(string Richardmethod, HHMMvar HHvar, SHAWvar TVvar, double Timestep, ref double[] wxc)
        {
            SHAWWater.Soilwatercal(Richardmethod, HHvar, TVvar, Timestep);
            for (int i = 0; i < TVvar.nznum; i++)
            {
                spaccell.Values[i] = TVvar.mumpsSHAW.a[(int)cellord[i] - 1];
            }

            if (TVvar.Nummethod == 1)
            {
                var lu = SparseLU.Create(spaccell, ColumnOrdering.MinimumDegreeAtPlusA, 1.0);
                lu.Solve(TVvar.mumpsSHAW.rhs, wxc);
            }
            else
            {
                var qr = SparseQR.Create(spaccell, ColumnOrdering.MinimumDegreeAtA);
                qr.Solve(TVvar.mumpsSHAW.rhs, wxc);
            }
        }

        public static void SHAWsolutecal(HHMMvar HHvar, SHAWvar TVvar, double Timestep)
        {
            for (int soli = 0; soli < HHvar.solutenum; soli++)
            {
                for (int ic = 0; ic < HHvar.cuboidnum; ic++)
                {
                    TVvar.solutephas.soilsolunew[soli][ic] = TVvar.solutephas.soilsolunew[soli][ic] * TVvar.waterphas.VLCDT[ic] / (TVvar.waterphas.VLCDT[ic] + TVvar.waterphas.OUTWADT[ic] / (TVvar.Cellx * TVvar.Celly * TVvar.Cellz) + TVvar.waterphas.OUTWA2DT[ic] / (TVvar.Cellx * TVvar.Celly * TVvar.Cellz) + TVvar.waterphas.OUTE[ic] / (TVvar.Cellx * TVvar.Celly * TVvar.Cellz));//特殊处理

                }
                SHAWSolute.Soilsolute(soli, HHvar, TVvar, Timestep);
                double[] sxc = new double[TVvar.nnum];
                for (int i = 0; i < TVvar.nznum; i++)
                {
                    spaccell.Values[i] = TVvar.mumpsSHAW.a[(int)cellord[i] - 1];
                }

                if (TVvar.Nummethod == 1)
                {
                    var lu = SparseLU.Create(spaccell, ColumnOrdering.MinimumDegreeAtPlusA, 1.0);
                    lu.Solve(TVvar.mumpsSHAW.rhs, sxc);
                }
                else
                {
                    var qr = SparseQR.Create(spaccell, ColumnOrdering.MinimumDegreeAtA);
                    qr.Solve(TVvar.mumpsSHAW.rhs, sxc);
                }

                for (int ic = HHvar.startcell; ic < HHvar.endcell; ic++)
                {

                    TVvar.solutephas.soilsolunew[soli][ic] = sxc[ic];
                }
            }
        }
    }
}
