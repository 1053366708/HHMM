﻿using System;
using MPI;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CSparse;
using CSparse.Storage;
using CSparse.Double.Factorization;
using CSparse.IO;
using CSparse.Ordering;
using CSparse.Double;

//土壤水热盐冰运动模型
namespace HHMM
{
    public class SHAW
    {
        public static double Timestep = SHAWconst.Timestep;
        //public static int calnum = 0;
        public static string Richardmethod = "NewRap"; //Celia    
        /// <summary>
        /// 模型是一个多变量的7对角矩阵，基于稀疏矩阵求解相关变量
        /// 土壤水分是基于牛顿莱布尼茨方法迭代，求解土壤水势变化值；
        /// 土壤温度基于牛顿莱布尼茨方法迭代，求解温度的变化量；
        /// 土壤盐分浓度基于平衡方程求解，直接求解土壤盐分浓度；
        /// 含冰量基于冰点水势方程，利用土壤水势和温度求解计算，如果考虑土壤溶质的影响，需要迭代计算含冰量导致的浓度变化，进而影响土壤水势，发过来影响含冰量，需要反复迭代
        /// </summary>
        /// <param name="TVvar"></param>
        /// <param name="HHvar"></param>
        public static void SHAWrun(int di, int hi, SHAWvar TVvar, HHMMvar HHvar, SVCSvar SVvar, Intracommunicator comm)
        {
            //计算当前时刻太阳短波辐射和大气长波辐射,将融雪过程放在这里，开始就计算融雪
            SHAWFun.CSparsecreate(TVvar);//创建稀疏矩阵
            double[] hxc = new double[TVvar.nnum];
            double Timeleft = HHvar.Dtcal;
            int Ntimes = 0;
            SHAWTools.SUMDT(Ntimes, HHvar.NXCELL, HHvar.NYCELL, HHvar.upfaceid, TVvar.SNMatrix.NSP, Timestep, TVvar.WaEndata.VFLUX, TVvar.SNMatrix.QVSP, ref TVvar.SWSUMDT.TOPSNO, ref TVvar.SWSUMDT.EVAP1, ref TVvar.SWSUMDT.TQVSP);//初始化变量
            if (HHvar.tn % HHvar.stepphour == 1)
            {
                TVvar.Totalbot = 0.0;
                TVvar.Totalinterflow = 0.0;
                TVvar.Totalsoile = 0.0;
                TVvar.Totalcanopyt = 0.0;
                TVvar.Trenchflow = 0.0;

                for (int solu = 0; solu < HHvar.solutenum; solu++)
                {
                    TVvar.Solutebot[solu] = 0.0;
                    TVvar.Soluteinter[solu] = 0.0;
                    TVvar.SoluteCG[solu] = 0.0;
                }
            }

        stepchange:
            int numsc = 0;

            SHAWTools.BACKUP(Ntimes, TVvar, HHvar);//将时间步结束值设置回时间步开始时的值
            SHAWWater.Gq2k(HHvar, TVvar.waterphas.VLCDT, TVvar.icephas.VICDT, ref TVvar.waterphas.K);//求解导水率
            while (Timeleft > 0)
            {
                int Iter = 0;
            iteration:
                Iter++;
                int numiter = 0;


                if (HHvar.SEM > 0)
                {



                    SHAWSurfcal.WESurfcal(di, hi, Iter, Timestep, TVvar, HHvar); //地表能量平衡计算


                    for (int i = 0; i < HHvar.NXCELL; i++)
                    {
                        for (int j = 0; j < HHvar.NYCELL; j++)
                        {
                            double[] DELTA;
                            if ((HHvar.upfaceid[i][j] >= 0) & (TVvar.SNMatrix.NSP[i][j] > 0))
                            {

                                SHAWTools.TDMA(TVvar.SNMatrix.NSP[i][j], TVvar.SNMatrix.A1[i][j], TVvar.SNMatrix.B1[i][j], TVvar.SNMatrix.C1[i][j], TVvar.SNMatrix.D1[i][j], out DELTA);//基于消元方法求解稀疏矩阵
                                for (int l = 0; l < TVvar.SNMatrix.NSP[i][j]; l++)
                                {
                                    if ((Math.Abs(DELTA[l]) > 25) & ((Iter >= 10)))
                                    {
                                        //Timestep = Timestep / 1.3;
                                        //goto stepchange;
                                        numsc++;
                                    }

                                    if (TVvar.SNMatrix.ICESPT[i][j][l] == 0)
                                    {
                                        if (Math.Abs(DELTA[l]) > TVvar.Terror)
                                        {
                                            numiter++;
                                        }
                                        TVvar.SNMatrix.TSPDT[i][j][l] -= DELTA[l];
                                        if (TVvar.SNMatrix.TSPDT[i][j][l] > 0)
                                        {
                                            TVvar.SNMatrix.ICESPT[i][j][l] = 1;
                                            TVvar.SNMatrix.TSPDT[i][j][l] = 0.0;
                                        }
                                    }
                                    else
                                    {
                                        if (Math.Abs(DELTA[l]) / TVvar.SNMatrix.DZSP[i][j][l] > 0.001 * TVvar.Terror)
                                        {
                                            if (Math.Abs(DELTA[l]) > TVvar.SNMatrix.DLWDT[i][j][l] / 1000000)
                                                numiter++;
                                        }
                                        TVvar.SNMatrix.DLWDT[i][j][l] -= DELTA[l];
                                        if (TVvar.SNMatrix.DLWDT[i][j][l] < 0)
                                        {
                                            TVvar.SNMatrix.ICESPT[i][j][l] = 0;
                                            TVvar.SNMatrix.DLWDT[i][j][l] = 0.0;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (HHvar.FSM > 0)
                {


                    //冻土
                    for (int ic = 0; ic < HHvar.cuboidnum; ic++)
                    {
                        int ct = HHvar.cellsoiltype[ic];
                        if (TVvar.heatphas.TSDT[ic] < 0.0)//土壤温度小于0
                        {
                            //int ICE = TVvar.icephas.ICESDT[ic];//
                            SHAWIce.Frozen(HHvar.soilwaterpara.soilwas[ct], HHvar.soilwaterpara.soilwar[ct], HHvar.soilwaterpara.avg[ct], HHvar.soilwaterpara.m[ct], HHvar.soilwaterpara.n[ct], TVvar.heatphas.TSDT[ic], ref TVvar.waterphas.VLCDT[ic], ref TVvar.waterphas.MATDT[ic], ref TVvar.icephas.VICDT[ic], ref TVvar.icephas.ICESDT[ic]);

                            //if ((ICE == 0) & (TVvar.icephas.ICESDT[ic] == 1))//没冰但应该结冰
                            //{
                            //    SHAWIce.Adjust(ref TVvar.waterphas.VLCDT[ic], ref TVvar.waterphas.MATDT[ic], ref TVvar.heatphas.TSDT[ic], ref TVvar.icephas.VICDT[ic], ref TVvar.icephas.ICESDT[ic], TVvar.heatphas.Cssoil[ic], HHvar.soilsolutepara.kcq[ct], HHvar.soilwaterpara.soilwas[ct], HHvar.soilwaterpara.soilwar[ct], HHvar.soilwaterpara.avg[ct], HHvar.soilwaterpara.m[ct], HHvar.soilwaterpara.n[ct], SHAWconst.RHOL, SHAWconst.RHOI, HHvar.soilheatpara.csmine[ct], SHAWconst.UGAS, SHAWconst.Tk0, SHAWconst.LF, SHAWconst.G);//冻土状态调整，通过调整温度来调整含冰量的计算
                            //}

                        }
                        else//土壤温度大于0，化冰    
                        {
                            if (TVvar.icephas.ICESDT[ic] == 1)
                            {
                                double change = Math.Min(TVvar.icephas.VICDT[ic], SHAWconst.ICEstep);
                                TVvar.waterphas.VLCDT[ic] = Math.Min(HHvar.soilwaterpara.soilwas[ct], (TVvar.waterphas.VLCDT[ic] + SHAWconst.RHOI / SHAWconst.RHOL * change));
                                TVvar.icephas.VICDT[ic] -= change;
                                if (TVvar.icephas.VICDT[ic] <= 0.0) TVvar.icephas.ICESDT[ic] = 0;

                                SHAWWater.Cellgq2y(HHvar.soilwaterpara.soilwas[ct], HHvar.soilwaterpara.soilwar[ct], HHvar.soilwaterpara.avg[ct], HHvar.soilwaterpara.m[ct], HHvar.soilwaterpara.n[ct], TVvar.waterphas.VLCDT[ic], TVvar.icephas.VICDT[ic], out TVvar.waterphas.MATDT[ic]);//求解水势
                            }

                        }

                    }
                }

                if (HHvar.SSEM > 0)
                {


                    //热量计算            
                    SHAWFun.SHAWheatcal(HHvar, TVvar, Timestep, ref hxc);
                    if (Timestep > TVvar.Minstep)
                    {
                        for (int ic = HHvar.startcell; ic < HHvar.endcell; ic++)
                        {
                            if ((Math.Abs(hxc[ic]) > TVvar.Tchange) || (Iter >= 10) || (Double.IsNaN(hxc[ic])))
                            {
                                //Timestep = Timestep / 1.3;
                                //goto stepchange;
                                numsc++;
                            }
                        }
                    }

                    for (int ic = HHvar.startcell; ic < HHvar.endcell; ic++)
                    {
                        if (Math.Abs(hxc[ic]) > TVvar.Terror)
                        {
                            numiter++;
                        }
                        TVvar.heatphas.TSDT[ic] += hxc[ic];
                    }
                }

                SHAWWater.Gq2k(HHvar, TVvar.waterphas.VLCDT, TVvar.icephas.VICDT, ref TVvar.waterphas.K);//求解导水率


                if (comm.Size > 1)
                {
                    comm.Barrier();
                    HHMMtool.Sendreceive1D(comm, ref TVvar.waterphas.VLCDT, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    HHMMtool.Sendreceive1D(comm, ref TVvar.waterphas.MATDT, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    HHMMtool.Sendreceive1D(comm, ref TVvar.heatphas.TSDT, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    HHMMtool.Sendreceive1D(comm, ref TVvar.icephas.VICDT, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    HHMMtool.Sendreceive1Dint(comm, ref TVvar.icephas.ICESDT, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    HHMMtool.Sendreceive1D(comm, ref TVvar.waterphas.K, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                }

                if (HHvar.SSFM > 0)
                {
                    //水分计算
                    SHAWFun.SHAWwatercal(Richardmethod, HHvar, TVvar, Timestep, ref hxc);

                    if (Timestep > TVvar.Minstep)
                    {
                        double threshold = 0.0;
                        for (int ic = HHvar.startcell; ic < HHvar.endcell; ic++)
                        {
                            if (Richardmethod == "Celia")
                            {
                                threshold = Math.Abs(hxc[ic] - TVvar.waterphas.MATDT[ic]);
                            }
                            if (Richardmethod == "NewRap")
                            {
                                threshold = Math.Abs(hxc[ic]);
                            }

                            if ((Math.Abs(threshold) > TVvar.Hchange) || (Iter >= 10) || (Double.IsNaN(hxc[ic])))
                            {
                                //Timestep = Timestep / 1.3;
                                //Timestep = Math.Min(60, Timestep);
                                //goto stepchange;
                                numsc++;
                            }
                        }
                    }

                    for (int ic = HHvar.startcell; ic < HHvar.endcell; ic++)
                    {
                        if (Richardmethod == "Celia")
                        {
                            if ((Math.Abs(TVvar.waterphas.C[ic] * (hxc[ic] - TVvar.waterphas.MATDT[ic])) > TVvar.Werror))
                            {
                                numiter++;
                            }
                            TVvar.waterphas.MATDT[ic] = hxc[ic];
                        }
                        if (Richardmethod == "NewRap")
                        {

                            if ((Math.Abs(TVvar.waterphas.C[ic] * (hxc[ic])) > TVvar.Werror))
                            {
                                numiter++;
                            }

                            TVvar.waterphas.MATDT[ic] += hxc[ic];
                        }
                        int ct = HHvar.cellsoiltype[ic];
                        SHAWWater.Cellgy2q(HHvar.soilwaterpara.soilwas[ct], HHvar.soilwaterpara.soilwar[ct], HHvar.soilwaterpara.avg[ct], HHvar.soilwaterpara.m[ct], HHvar.soilwaterpara.n[ct], TVvar.waterphas.MATDT[ic], TVvar.icephas.VICDT[ic], out TVvar.waterphas.VLCDT[ic]);//根据水势求土壤含水率                    

                    }
                }

                if (comm.Size > 1)
                {
                    comm.Barrier();
                    numiter = comm.Reduce(numiter, Operation<int>.Max, 0);
                    comm.Broadcast(ref numiter, 0);
                    numsc = comm.Reduce(numsc, Operation<int>.Max, 0);
                    comm.Broadcast(ref numsc, 0);
                }
                if (numsc >= 1)
                {
                    Timestep = Timestep / 1.3;
                    Timestep = Math.Min(SHAWconst.Timestep, Timestep);
                    goto stepchange;
                }

                if ((numiter >= 1) && (Iter <= 10))
                {
                    goto iteration;
                }


                if (comm.Size > 1)
                {
                    comm.Barrier();
                    HHMMtool.Sendreceive1D(comm, ref TVvar.waterphas.VLCDT, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    HHMMtool.Sendreceive1D(comm, ref TVvar.waterphas.MATDT, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    HHMMtool.Sendreceive1Dint(comm, ref TVvar.icephas.ICESDT, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    HHMMtool.Sendreceive1D(comm, ref TVvar.waterphas.K, HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                }
                if (HHvar.SSSM > 0)
                {
                    //溶质计算
                    SHAWFun.SHAWsolutecal(HHvar, TVvar, Timestep);

                    //土壤蒸发的同位素分馏计算
                    //SHAWSolute.CGE(TVvar, HHvar, 0.9927, Timestep);//计算分馏出去的蒸发水同位素组成                
                }
                if (comm.Size > 1)
                {
                    comm.Barrier();
                    for (int i = 0; i < HHvar.solutenum; i++)
                    {
                        HHMMtool.Sendreceive1D(comm, ref TVvar.solutephas.soilsolunew[i], HHvar.conupfaceid, HHvar.NXCELL, HHvar.cuboidnum, HHvar.downfaceid, HHvar.upfaceid, HHvar.NYCELL);
                    }
                }

                //当前步长迭代结束输出
                for (int ic = 0; ic < HHvar.cuboidnum; ic++)
                {
                    TVvar.waterphas.VLC[ic] = TVvar.waterphas.VLCDT[ic];
                    TVvar.waterphas.OUTWA[ic] = TVvar.waterphas.OUTWADT[ic];//渗流
                    TVvar.waterphas.OUTWA2[ic] = TVvar.waterphas.OUTWA2DT[ic];//渗漏                     
                    TVvar.waterphas.OUTE[ic] = TVvar.waterphas.OUTEDT[ic];
                    TVvar.waterphas.OUTT[ic] = TVvar.waterphas.OUTTDT[ic];
                    TVvar.waterphas.MAT[ic] = TVvar.waterphas.MATDT[ic];
                    TVvar.heatphas.TS[ic] = TVvar.heatphas.TSDT[ic];
                    TVvar.icephas.VIC[ic] = TVvar.icephas.VICDT[ic];
                    TVvar.icephas.ICES[ic] = TVvar.icephas.ICESDT[ic];
                }

                //for (int i = 0; i < HHvar.NXCELL; i++)
                //{
                //    for (int j = 0; j < HHvar.NYCELL; j++)
                //    {
                //        if ((HHvar.upfaceid[i][j] >= 0) & (TVvar.SNMatrix.NSP[i][j] > 0))
                //        {

                //            for (int n = 0; n < TVvar.SNMatrix.NSP[i][j]; n++)
                //            {
                //                TVvar.SNMatrix.TSP[i][j][n] = TVvar.SNMatrix.TSPDT[i][j][n];
                //                TVvar.SNMatrix.DLW[i][j][n] = TVvar.SNMatrix.DLWDT[i][j][n];
                //            }

                //        }
                //        if (HHvar.upfaceid[i][j] >= 0)
                //        {
                //            for (int n = 0; n < 4; n++)
                //            {

                //                HHvar.soiltosurface[i][j][n] = HHvar.soiltosurfaceDT[i][j][n];

                //            }
                //        }
                //    }
                //}

                Ntimes += 1;

                SHAWTools.SUMDT(Ntimes, HHvar.NXCELL, HHvar.NYCELL, HHvar.upfaceid, TVvar.SNMatrix.NSP, Timestep, TVvar.WaEndata.VFLUX, TVvar.SNMatrix.QVSP, ref TVvar.SWSUMDT.TOPSNO, ref TVvar.SWSUMDT.EVAP1, ref TVvar.SWSUMDT.TQVSP);

                Timeleft -= Timestep;  //剩余时间


                if (Iter <= 2)
                {
                    Timestep *= 1.3;
                    Timestep = Math.Min(SHAWconst.Timestep, Timestep);
                }

                if ((Timestep >= Timeleft) && (Timeleft > 0))
                {
                    Timestep = Timeleft;
                }

                //统计过程量以满足一小时时间步长的聚合
                for (int ic = HHvar.startcell; ic < HHvar.endcell; ic++)
                {
                    int ct0 = HHvar.cellsoiltype[ic];//不同土壤类型编号
                    TVvar.Totalbot += TVvar.waterphas.OUTWA2[ic];
                    TVvar.Totalinterflow += TVvar.waterphas.OUTWA[ic];
                    TVvar.Totalsoile += TVvar.waterphas.OUTE[ic];
                    TVvar.Totalcanopyt += TVvar.waterphas.OUTT[ic];

                    for (int solu = 0; solu < HHvar.solutenum; solu++)
                    {
                        TVvar.Solutebot[solu] += TVvar.solutephas.OUTSODT2[solu][ic];
                        TVvar.Soluteinter[solu] += TVvar.solutephas.OUTSODT[solu][ic];
                        TVvar.SoluteCG[solu] += TVvar.waterphas.OUTE[ic] * SHAWconst.RHOL * TVvar.solutephas.soilsolunew[solu][ic];//没考虑分馏的情况

                    }
                }

            }



            /*
           for (int i = 0; i < HHvar.NXCELL; i++)
           {
               for(int j = 0; j < HHvar.NYCELL; j++)
               {
                   if (HHvar.upfaceid[i][j] >= 0)
                   {
                       SVvar.h[i][j + 1] += HHvar.soiltosurface[i][j][0];
                       SVvar.h[i+1][j] += HHvar.soiltosurface[i][j][1];
                       SVvar.h[i+1][j+2] += HHvar.soiltosurface[i][j][2];
                       SVvar.h[i+2][j + 1] += HHvar.soiltosurface[i][j][3];
                       HHvar.soiltosurface[i][j][0] = 0.0;
                       HHvar.soiltosurface[i][j][1] = 0.0;
                       HHvar.soiltosurface[i][j][2] = 0.0;
                       HHvar.soiltosurface[i][j][3] = 0.0;
                   }
               }
           }
           */

            /*
           //Panola山坡的TRENCH范围
           for (int i = 6; i < 26; i++)
           {
               int layernum = HHvar.downfaceid[i][47] - HHvar.upfaceid[i][47] + 1;//?土壤层数
               int coni = HHvar.conupfaceid[i][47];//连续网格的层数

               for (int lli = 0; lli < layernum; lli++)
               {
                   int ct = HHvar.cellsoiltype[coni + lli];  //那一类型的土壤
                   if (ct < HHvar.rocknum - 1)
                   {
                       TVvar.Trenchflow += TVvar.waterphas.OUTWA[coni + lli];
                   }

               }

           }
            */

        }
    }
}