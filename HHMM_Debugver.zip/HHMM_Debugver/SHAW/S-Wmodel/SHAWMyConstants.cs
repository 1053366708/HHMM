﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHMM

{
    public class SHAWMyConstants
    {
        public const double Isotope = 0; // 1代表考虑同位素
        public const double lwc_measurement = 0; // 1代表有叶片水分测量值
        public const double Flooding = 0; // 1代表湿地  0代表其它 
        public const double C3 = 1; // 1代表C3植物   0代表C4植物
        public const double Kr = 0.5; // 0.6
        public const double rss_v = 0.2; // 1
        public const double Zu_m = 30;  //Wind speed measurement height[m]
        public const double Zt_m = 30; //Temperature measurement height[m]
        public const double g_min_c = 0.15; //cuticular conductance for CO2 (mm/s) 0.4
        public const double D0 = 0.2; // 0.25
        public const double cd = 0.1;      //Maruyama(2008,2010); =0.1 Meyers and Paw et al. (1987) 
        public const double z0s = 0.01;     //0.001 in?the effective roughness length of the soil substrate 0.01
        public const double Km = 2.5;    // 
        public const double dl = 0.068;    //leaf wide0.068
        public const double AK_0 = 28;    //同位素C-G模型中的εk

        public const double G_measurement = 1; // 1代表有地热通量测量值
        public const double PAR_measurement = 1; // 1代表有光合有效辐射测量值
        public const double ustar_measurement = 1; // 1代表有摩擦速度测量值
        public const double Rn_measurement = 1; // 1代表有净辐射测量值
        public const double SWC2_measurement = 1; // 1代表有根部土壤区含水率测量值

    }
}
