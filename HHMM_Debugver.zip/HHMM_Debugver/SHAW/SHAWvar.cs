﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace HHMM
{
    public class SHAWvar
    {
        public int IFIRST;
        public int NXCELL, NYCELL, NZCELL;
        public double Cellx, Celly, Cellz;
        public double Minstep, Werror, Hchange, Terror, Tchange;
        public int Nummethod = 1;
        public int nnum, nznum;//有效网格数、稀疏矩阵非零元素个数
        public double Totalsoilwatervolume;
        public double Totalrockwatervolume;
        public double[] Totalsoilsolute;
        public double Totalbot;//土壤水分运动向下渗漏的量
        public double Totalinterflow;//壤中流
        public double Totalsoile;//裸土蒸发-地表蒸发（包括积雪表面和裸土）
        public double Totalcanopyt;//植被蒸腾
        public double Totalsoilice;//含冰量/冰水当量
        public double Totalsnow;//总雪水当量
        public double TotalDLW;//雪层中的液态水
        public double[] Soluteinter;//壤中流溶质浓度
        public double[] Solutebot;//底层渗漏溶质浓度
        public double[] SoluteCG;//分馏出去的溶质

        //all: 并行总量
        public double Totalsoilwatervolumeall;
        public double Totalrockwatervolumeall;
        public double[] Totalsoilsoluteall;
        public double Totalbotall;
        public double Totalinterflowall;
        public double Totalsoileall;
        public double Totalcanopytall;
        public double Totalsoiliceall;
        public double Totalsnowall;
        public double TotalDLWall;
        public double[] Soluteinterall;
        public double[] Solutebotall;
        public double[] SoluteCGall;
        public double Trenchflow;//临时panola
        public struct cellsizepara
        {
            public int[][] celltopo;//[有效网格n][x、y、z、左、后、上、下、前、右]（沿坡脚向上看）  （左右前后上下有效网格（如果存在）的编号）
        }

        public struct SnowMatrix
        {
            public int[][] NSP;//积雪层数
            public int[][][] ICESPT;//
            public double[][][] DZSP;//雪层厚度
            public double[][][] ZSP;//雪层距雪面的深度
            public double[][][] SWSNOW;//雪接收的短波辐射
            public double[][][] LWSNOW;//雪接收的长波辐射
            public double[][][] SSP;//雪层的source项
            public double[][][] TSP;//温度，摄氏度
            public double[][][] TSPDT;
            public double[][][] QVSP;//雪层间的水汽通量
            public double[][][] DLW;//雪层液态水
            public double[][][] DLWDT;
            public double[][][] DL;//添加存储时间步长后的雪层液态水
            public double[][][] RHOSP;//地表积雪密度
            public double[][][] WLAG;//滞后过程中液态水的量
            public double[][] STORE;//存储的多余水。雪层中储存的液态水（已经滞后）的量
            public double[][] SNOWEX;//多余的雪 snow excess
            public double[][] TOPSNO;//
            public double[][][] A1;//线性方程组（一维）的系数A、B、C、D项
            public double[][][] B1;//
            public double[][][] C1;//
            public double[][][] D1;//            
        }

        public struct Radiation
        {
            public double[][] Direct;//直接辐射
            public double[][] Diffuse;//散射辐射
            public double[][] LWSOIL;//土壤接收的长波辐射
            public double[][] SWSOIL;//土壤接收的短波辐射
            public double ABOVE;//大气长波辐射
        }

        public struct WaterEngry
        {
            public double[][] ZM;//随动量分布的表面粗糙参数
            public double[][] ZH;//随温度分布的表面粗糙参数
            public double[][] ZERO;//零平面位移
            public double[][] HFLUX;//感热通量
            public double[][] VFLUX;//潜热通量
        }

        public struct cellwaterphas
        {
            public double[] K;//土壤导水率
            public double[] C;//比水容量C
            public double[] VLC;//土壤含水率
            public double[] VLCDT;
            public double[] OUTWA;//壤中流的水
            public double[] OUTWADT;
            public double[] OUTWA2;//渗漏的水
            public double[] OUTWA2DT;
            public double[] OUTET;
            public double[] OUTETDT;
            public double[] OUTE;//地表蒸发的水
            public double[] OUTEDT;
            public double[] OUTT;//
            public double[] OUTTDT;
            public double[] MAT;//土壤水势
            public double[] MATDT;

        }

        public struct cellheatphas
        {
            public double[] Kssoil;//土壤热传导
            public double[] Cssoil;//土壤热容
            public double[] TS;//土壤温度
            public double[] TSDT;
        }

        public struct cellicephas
        {
            public int[] ICES;//
            public int[] ICESDT; //           
            public double[] VIC;//冰的体积
            public double[] VICDT;
        }

        public struct cellsolutephas
        {
            public double[][] soilsolunew;//溶质浓度
            public double[][] OUTSODT;//渗漏的溶质
            public double[][] OUTSODT2;//渗流的溶质
            public double[][] ESODT;//蒸发的溶质
        }

        public struct mumps
        {
            public int[] irn;//用来求稀疏矩阵
            public int[] jcn;//用来求稀疏矩阵
            public double[] a;//线性方程组左边的系数（系数项，元素个数=有效网格数*7）
            public double[] rhs;//线性方程组右边的系数（常数项）
            public double[] WMatrixadd;//水量B项，左边系数增加项
            public double[] WaterBaadd;//水量D项，右边系数增加项
            public double[] EMatrixadd;//能量B项增加
            public double[] EnergBaadd;//能量D项增加
        }

        public struct SHAWSumdt
        {
            public double[][] TOPSNO;//顶层雪需要蒸发的水量
            public double[][] EVAP1;//
            public double[][][] TQVSP;//累积一个小时的各雪层的水汽通量
        }

        public cellsizepara cellsize;
        public cellwaterphas waterphas;
        public cellheatphas heatphas;
        public cellicephas icephas;
        public cellsolutephas solutephas;
        public WaterEngry WaEndata;
        public Radiation raddata;
        public SnowMatrix SNMatrix;
        public mumps mumpsSHAW;
        public SHAWSumdt SWSUMDT;

        public SHAWvar(HHMMvar HHvar)
        {
            NXCELL = HHvar.NXCELL;
            NYCELL = HHvar.NYCELL;
            NZCELL = HHvar.NZCELL;
            Cellx = HHvar.DX;
            Celly = HHvar.DY;
            Cellz = HHvar.DZ;
            IFIRST = 0;
            SHAWvardefine(HHvar);
        }
        public void SHAWvardefine(HHMMvar HHvar)
        {
            int Dimindex;  //判断维度确定数值

            if (NXCELL * NYCELL == 1 | NXCELL * NZCELL == 1 | NYCELL * NZCELL == 1)
            {
                Dimindex = 3;
            }
            else if (NXCELL == 1 | NYCELL == 1 | NZCELL == 1)
            {
                Dimindex = 5;
            }
            else
            {
                Dimindex = 7;
            }
            //Dimindex = 7;
            waterphas.K = new double[HHvar.cuboidnum];
            waterphas.C = new double[HHvar.cuboidnum];
            waterphas.VLC = new double[HHvar.cuboidnum];
            waterphas.VLCDT = new double[HHvar.cuboidnum];
            waterphas.OUTWA = new double[HHvar.cuboidnum];
            waterphas.OUTWADT = new double[HHvar.cuboidnum];
            waterphas.OUTWA2 = new double[HHvar.cuboidnum];
            waterphas.OUTWA2DT = new double[HHvar.cuboidnum];
            waterphas.OUTE = new double[HHvar.cuboidnum];
            waterphas.OUTEDT = new double[HHvar.cuboidnum];
            waterphas.OUTT = new double[HHvar.cuboidnum];
            waterphas.OUTTDT = new double[HHvar.cuboidnum];
            waterphas.OUTET = new double[HHvar.cuboidnum];
            waterphas.OUTETDT = new double[HHvar.cuboidnum];
            waterphas.MAT = new double[HHvar.cuboidnum];
            waterphas.MATDT = new double[HHvar.cuboidnum];

            heatphas.Kssoil = new double[HHvar.cuboidnum];
            heatphas.Cssoil = new double[HHvar.cuboidnum];
            heatphas.TS = new double[HHvar.cuboidnum];
            heatphas.TSDT = new double[HHvar.cuboidnum];

            icephas.ICES = new int[HHvar.cuboidnum];
            icephas.ICESDT = new int[HHvar.cuboidnum];
            icephas.VIC = new double[HHvar.cuboidnum];
            icephas.VICDT = new double[HHvar.cuboidnum];

            solutephas.soilsolunew = new double[HHvar.solutenum][];
            solutephas.OUTSODT = new double[HHvar.solutenum][];
            solutephas.OUTSODT2 = new double[HHvar.solutenum][];
            solutephas.ESODT = new double[HHvar.solutenum][];

            mumpsSHAW.irn = new int[Dimindex * HHvar.cuboidnum];
            mumpsSHAW.jcn = new int[Dimindex * HHvar.cuboidnum];
            mumpsSHAW.a = new double[Dimindex * HHvar.cuboidnum];
            mumpsSHAW.rhs = new double[HHvar.cuboidnum];
            mumpsSHAW.WMatrixadd = new double[HHvar.cuboidnum];
            mumpsSHAW.WaterBaadd = new double[HHvar.cuboidnum];
            mumpsSHAW.EMatrixadd = new double[HHvar.cuboidnum];
            mumpsSHAW.EnergBaadd = new double[HHvar.cuboidnum];
            cellsize.celltopo = new int[HHvar.cuboidnum][];
            for (int i = 0; i < HHvar.cuboidnum; i++)
            {
                cellsize.celltopo[i] = new int[9];
            }
            for (int i = 0; i < HHvar.solutenum; i++)
            {
                solutephas.soilsolunew[i] = new double[HHvar.cuboidnum];
                solutephas.OUTSODT[i] = new double[HHvar.cuboidnum];
                solutephas.OUTSODT2[i] = new double[HHvar.cuboidnum];
                solutephas.ESODT[i] = new double[HHvar.cuboidnum];
            }
            Totalsoilsolute = new double[HHvar.solutenum];
            Solutebot = new double[HHvar.solutenum];
            Soluteinter = new double[HHvar.solutenum];
            SoluteCG = new double[HHvar.solutenum];

            Totalsoilsoluteall = new double[HHvar.solutenum];
            Solutebotall = new double[HHvar.solutenum];
            Soluteinterall = new double[HHvar.solutenum];
            SoluteCGall = new double[HHvar.solutenum];

            raddata.Direct = new double[NXCELL][];
            raddata.Diffuse = new double[NXCELL][];
            raddata.LWSOIL = new double[NXCELL][];
            raddata.SWSOIL = new double[NXCELL][];

            WaEndata.ZM = new double[NXCELL][];
            WaEndata.ZH = new double[NXCELL][];
            WaEndata.ZERO = new double[NXCELL][];
            WaEndata.HFLUX = new double[NXCELL][];
            WaEndata.VFLUX = new double[NXCELL][];

            SNMatrix.NSP = new int[NXCELL][];
            SNMatrix.DZSP = new double[NXCELL][][];
            SNMatrix.ZSP = new double[NXCELL][][];
            SNMatrix.SWSNOW = new double[NXCELL][][];
            SNMatrix.LWSNOW = new double[NXCELL][][];
            SNMatrix.SSP = new double[NXCELL][][];
            SNMatrix.TSP = new double[NXCELL][][];
            SNMatrix.TSPDT = new double[NXCELL][][];
            SNMatrix.QVSP = new double[NXCELL][][];
            SNMatrix.RHOSP = new double[NXCELL][][];
            SNMatrix.DLW = new double[NXCELL][][];
            SNMatrix.DLWDT = new double[NXCELL][][];
            SNMatrix.DL = new double[NXCELL][][];//添加存储雨雪分离后的雪层中的液态水含量
            SNMatrix.ICESPT = new int[NXCELL][][];
            SNMatrix.WLAG = new double[NXCELL][][];
            SNMatrix.STORE = new double[NXCELL][];
            SNMatrix.SNOWEX = new double[NXCELL][];
            SNMatrix.TOPSNO = new double[NXCELL][];
            SNMatrix.A1 = new double[NXCELL][][];
            SNMatrix.B1 = new double[NXCELL][][];
            SNMatrix.C1 = new double[NXCELL][][];
            SNMatrix.D1 = new double[NXCELL][][];

            SWSUMDT.TOPSNO = new double[NXCELL][];
            SWSUMDT.EVAP1 = new double[NXCELL][];
            SWSUMDT.TQVSP = new double[NXCELL][][];

            for (int i = 0; i < NXCELL; i++)
            {
                raddata.Direct[i] = new double[NYCELL];
                raddata.Diffuse[i] = new double[NYCELL];
                raddata.LWSOIL[i] = new double[NYCELL];
                raddata.SWSOIL[i] = new double[NYCELL];

                WaEndata.ZM[i] = new double[NYCELL];
                WaEndata.ZH[i] = new double[NYCELL];
                WaEndata.ZERO[i] = new double[NYCELL];
                WaEndata.HFLUX[i] = new double[NYCELL];
                WaEndata.VFLUX[i] = new double[NYCELL];

                SNMatrix.NSP[i] = new int[NYCELL];
                SNMatrix.ICESPT[i] = new int[NYCELL][];
                SNMatrix.DZSP[i] = new double[NYCELL][];
                SNMatrix.ZSP[i] = new double[NYCELL][];
                SNMatrix.SWSNOW[i] = new double[NYCELL][];
                SNMatrix.LWSNOW[i] = new double[NYCELL][];
                SNMatrix.SSP[i] = new double[NYCELL][];
                SNMatrix.TSP[i] = new double[NYCELL][];
                SNMatrix.TSPDT[i] = new double[NYCELL][];
                SNMatrix.QVSP[i] = new double[NYCELL][];
                SNMatrix.RHOSP[i] = new double[NYCELL][];
                SNMatrix.DLW[i] = new double[NYCELL][];
                SNMatrix.DLWDT[i] = new double[NYCELL][];
                SNMatrix.DL[i] = new double[NYCELL][];//添加存储雨雪分离后雪层的液态水
                SNMatrix.WLAG[i] = new double[NYCELL][];
                SNMatrix.STORE[i] = new double[NYCELL];
                SNMatrix.SNOWEX[i] = new double[NYCELL];
                SNMatrix.TOPSNO[i] = new double[NYCELL];
                SNMatrix.A1[i] = new double[NYCELL][];
                SNMatrix.B1[i] = new double[NYCELL][];
                SNMatrix.C1[i] = new double[NYCELL][];
                SNMatrix.D1[i] = new double[NYCELL][];

                SWSUMDT.TOPSNO[i] = new double[NYCELL];
                SWSUMDT.EVAP1[i] = new double[NYCELL];
                SWSUMDT.TQVSP[i] = new double[NYCELL][];
                for (int j = 0; j < NYCELL; j++)
                {
                    SNMatrix.WLAG[i][j] = new double[11];//
                }

            }
        }

    }
}
