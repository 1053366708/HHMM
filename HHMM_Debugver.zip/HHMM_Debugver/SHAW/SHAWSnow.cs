﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HHMM
{
    public class SHAWSnow
    {

        /// <summary>
        /// 雨雪过程
        /// </summary>
        /// <param name="Timestep"></param>
        /// <param name="AVGTA"></param>
        /// <param name="TRAIN0"></param>
        /// <param name="rain"></param>
        /// <param name="SNOTMP"></param>
        /// <param name="TVvar"></param>
        /// <param name="HHvar"></param>
        public static void PRECP(double Timestep, double AVGTA, double TRAIN0, ref double rain, double SNOTMP, SHAWvar TVvar, HHMMvar HHvar)
        {//AVGTA:平均温度 TRAIN:湿球温度 SNOTMP:出现雪的温度
         // double rain = RAIN;//添加降雨的赋值。。。需要考虑雪的出流是否是会使得每个网格的RAIN一样，不然最后传出的RAIN就是最后一个网格的融雪量；不添加这部分会使得前一个网格的融雪量是下一个网格的初始RAIN
            double RAINSUM = 0.0;// 剩下的雨总和
            for (int i = 0; i < HHvar.NXCELL; i++)
            {
                for (int j = 0; j < HHvar.NYCELL; j++)
                {
                    int coni = HHvar.conupfaceid[i][j];
                    double TRAIN = TRAIN0;
                    if (coni >= 0)
                    {
                        int ct = HHvar.cellsoiltype[coni];


                        double SNOW = 0.0, MELT = 0.0, SCOUT = 0.0, WE = 0.0;
                        double SNOWEX = TVvar.SNMatrix.SNOWEX[i][j];//SNOW EXCESS
                        List<double> DLWDT = null, DLW = null, TSPDT = null, TQVSP = null, RHOSP = null, DZSP = null, ZSP = null, WLAG = null, DL = null;//List<T>泛型类创建集合
                        List<int> ICESPT = null;
                        if (TVvar.SNMatrix.NSP[i][j] > 0)
                        {
                            DLWDT = new List<double>(TVvar.SNMatrix.DLWDT[i][j]);
                            DLW = new List<double>(TVvar.SNMatrix.DL[i][j]);
                            DL = new List<double>(TVvar.SNMatrix.DL[i][j]);
                            TSPDT = new List<double>(TVvar.SNMatrix.TSPDT[i][j]);
                            TQVSP = new List<double>(TVvar.SWSUMDT.TQVSP[i][j]);
                            RHOSP = new List<double>(TVvar.SNMatrix.RHOSP[i][j]);
                            DZSP = new List<double>(TVvar.SNMatrix.DZSP[i][j]);
                            ZSP = new List<double>(TVvar.SNMatrix.ZSP[i][j]);
                            ICESPT = new List<int>(TVvar.SNMatrix.ICESPT[i][j]);
                        }
                        WLAG = new List<double>(TVvar.SNMatrix.WLAG[i][j]);
                        double RAIN = rain;//该网格的雨
                        //假定雨温等于湿球温度
                        if (RAIN > 0)
                        {
                            if (AVGTA <= SNOTMP)
                            {//温度小于出现雪的温度。降水假定为雪（加上因消除浅层积雪而剩余的雪）
                                SNOW = RAIN + SNOWEX;
                                SNOWEX = 0.0;
                                RAIN = 0.0;

                                if (TRAIN > 0)
                                {
                                    TRAIN = 0.0;
                                }
                                NWSNOW(ref TVvar.SNMatrix.NSP[i][j], TRAIN, SNOW, HHvar.DZ, HHvar.soilwaterpara.soilwas[ct], TVvar.waterphas.VLCDT[coni], TVvar.icephas.VICDT[coni], HHvar.soilheatpara.minedensity[ct], HHvar.soilheatpara.csmine[ct], ref MELT, ref TVvar.heatphas.Cssoil[coni], ref TVvar.heatphas.TS[coni], ref TSPDT, ref ZSP, ref RHOSP, ref DZSP, ref ICESPT, ref DLW, ref DLWDT, ref TQVSP);//根据降雪调整积雪层数
                                if (TVvar.SNMatrix.NSP[i][j] <= 0.0)
                                {
                                    TRAIN = 0.0;
                                }
                            }
                            else
                            {//降水假设为雨-不允许雨水温度<0.0
                                if (TRAIN < 0.0)
                                {
                                    TRAIN = 0.0;
                                }
                            }
                        }
                        //积雪对降雨的吸收与融雪量的计算
                        if (TVvar.SNMatrix.NSP[i][j] > 0)
                        {
                            WBSNOW(Timestep, ref TVvar.SNMatrix.NSP[i][j], RAIN, TRAIN, ref TVvar.SWSUMDT.EVAP1[i][j], ref TVvar.SWSUMDT.TOPSNO[i][j], ref TQVSP, ref SCOUT, ref TVvar.SNMatrix.STORE[i][j], ref DLWDT, ref DLW, ref TSPDT, ref RHOSP, ref DZSP, ref ZSP, ref WLAG, ref ICESPT);//积雪的水量平衡，调整密度，检查雪层是否消失或超出规定的厚度
                            RAIN = SCOUT;
                            TRAIN = 0.0;
                        }
                        //如果温度低于冰点，不要渗入积水或多余的雪（SNOWEX）
                        if (((RAIN + MELT) > 0.0) & (TRAIN >= 0.0))
                        {//？把融化的雪放回雨中
                            RAIN += MELT;
                            RAIN += SNOWEX;
                            SNOWEX = 0.0;
                        }
                        //计算水当量-如果足够小，假设整个积雪都消失了
                        if (TVvar.SNMatrix.NSP[i][j] > 0)
                        {
                            WE = 0.0;
                            for (int l = 0; l < TVvar.SNMatrix.NSP[i][j]; l++)
                            {
                                WE += DZSP[l] * RHOSP[l] / SHAWconst.RHOL + DLWDT[l];//水当量计算
                            }
                        }
                        if (WE < 0.0005)
                        {//水当量足够小，假设积雪消失了
                            SCOUT = WE;
                            TVvar.SNMatrix.NSP[i][j] = 0;
                            //将当前滞后的水添加到积雪流出
                            SNOMLT(ref TVvar.SNMatrix.NSP[i][j], Timestep, ref SCOUT, ref TVvar.SNMatrix.STORE[i][j], ref WLAG, ref ICESPT, ref TSPDT, ref RHOSP, ref DZSP, ref DLWDT);//积雪流出量
                            SNOWEX += SCOUT;//将多余雪水（SNOWEX）设置为积雪中剩余的总水量当量——这将添加到降水量中，或允许在稍后的时间步进行渗透
                            RAIN += SNOWEX;
                            SNOWEX = 0.0;
                        }
                        else
                        {//积雪仍然存在——定义底部边界的温度
                            TSPDT[TVvar.SNMatrix.NSP[i][j]] = TVvar.heatphas.TS[coni];
                        }
                        TVvar.SNMatrix.SNOWEX[i][j] = SNOWEX;

                        if (TVvar.SNMatrix.NSP[i][j] > 0)
                        {
                            if (RHOSP[0] > 300)
                            {

                            }
                            TVvar.SNMatrix.DLWDT[i][j] = DLWDT.ToArray();//ToArray( ) 把List内的元素拷贝到一个新的数组内
                            TVvar.SNMatrix.DLW[i][j] = DLWDT.ToArray();
                            TVvar.SNMatrix.DL[i][j] = DLWDT.ToArray();
                            TVvar.SNMatrix.TSPDT[i][j] = TSPDT.ToArray();
                            TVvar.SNMatrix.TSP[i][j] = TSPDT.ToArray();
                            TVvar.SWSUMDT.TQVSP[i][j] = TQVSP.ToArray();
                            TVvar.SNMatrix.RHOSP[i][j] = RHOSP.ToArray();
                            TVvar.SNMatrix.DZSP[i][j] = DZSP.ToArray();
                            TVvar.SNMatrix.ZSP[i][j] = ZSP.ToArray();
                            TVvar.SNMatrix.WLAG[i][j] = WLAG.ToArray();
                            TVvar.SNMatrix.ICESPT[i][j] = ICESPT.ToArray();

                        }
                        RAINSUM += RAIN;
                    }
                }
            }
            rain = RAINSUM / HHvar.globalvd;
        }

        /// <summary>
        /// 计算湿球温度
        /// </summary>
        /// <param name="TA"></param>
        /// <param name="TADT"></param>
        /// <param name="HUM"></param>
        /// <param name="HUMDT"></param>
        /// <param name="PRESUR"></param>
        /// <param name="AVGTA"></param>
        /// <param name="TRAIN"></param>
        public static void TRAINFUN(double TA, double TADT, double HUM, double HUMDT, double PRESUR, ref double AVGTA, ref double TRAIN)
        {
            AVGTA = SHAWconst.WT * TA + SHAWconst.WDT * TADT;
            double AVGHUM = SHAWconst.WT * HUM + SHAWconst.WDT * HUMDT;
            TRAIN = AVGTA;
            SHAWTools.WTBULB(PRESUR, AVGTA, AVGHUM, ref TRAIN);
        }

        /// <summary>
        /// 积雪的水量平衡模型
        /// </summary>
        /// <param name="Timestep"></param>
        /// <param name="NSP"></param>
        /// <param name="RAIN"></param>
        /// <param name="TRAIN"></param>
        /// <param name="EVAP1"></param>
        /// <param name="TOPSNO"></param>
        /// <param name="TQVSP"></param>
        /// <param name="SCOUT"></param>
        /// <param name="STORE"></param>
        /// <param name="DLWDT"></param>
        /// <param name="DLW"></param>
        /// <param name="TSPDT"></param>
        /// <param name="RHOSP"></param>
        /// <param name="DZSP"></param>
        /// <param name="ZSP"></param>
        /// <param name="WLAG"></param>
        /// <param name="ICESPT"></param>
        public static void WBSNOW(double Timestep, ref int NSP, double RAIN, double TRAIN, ref double EVAP1, ref double TOPSNO, ref List<double> TQVSP, ref double SCOUT, ref double STORE, ref List<double> DLWDT, ref List<double> DLW, ref List<double> TSPDT, ref List<double> RHOSP, ref List<double> DZSP, ref List<double> ZSP, ref List<double> WLAG, ref List<int> ICESPT)
        {//雪盖中的水量平衡。通过水汽通量和融化调整密度。检查是否有雪层因融化而消失或者超出可接受的厚度

            int i, j, l, ll;
            double CHANGE, EXCESS, ABOVE, FREEZE, TDEPTH, WE, WEI, WENL, WEL;
            double ZZ, DZ1;
            int NEXT = 0, NL;
            CHANGE = (TOPSNO - TQVSP[0]) / RHOSP[0];//单位m  
            DZSP[0] += CHANGE;//单位m
            if ((DZSP[0] <= 0.0) && (NSP == 1))
            {//雪堆失去升华——调整TOPSNO和EVAP1，使水平衡并返回调用子程序
                TOPSNO -= DZSP[0] * RHOSP[0];
                EVAP1 -= DZSP[0] * RHOSP[0] / SHAWconst.RHOL;//
                NSP = 0;
                return;
            }
            for (i = 1; i < NSP; i++)
            {
                CHANGE = (TQVSP[i - 1] - TQVSP[i]) / DZSP[i];//雪密度的变化  kg/m3
                RHOSP[i] += CHANGE; //雪密度的调整  kg/m3
            }
            //因为融化和降雨调整雪层
            NL = NSP;
            ABOVE = RAIN;//来自上层的雨水或融水
            EXCESS = RAIN * (SHAWconst.CL * TRAIN + SHAWconst.LF) / SHAWconst.LF;//如果上面的冰层中有足够的冰来吸收所有的能量，那么上面的冰层就会产生融水。（对于第一层，这个术语包括雨水传递的能量。）


            for (i = 0; i < NSP; i++)
            {
                if (ICESPT[i] == 0)//不结冰
                {//温度是未知的——上面一层多余的液态水必须被冻结。
                    if (EXCESS != 0)//融水不为0
                    {//计算冻结量，以便将温度升高到零摄氏度。（使用冰的比热，CI）
                        WEL = RHOSP[i] * DZSP[i] / SHAWconst.RHOL;
                        FREEZE = -1.0 * TSPDT[i] * WEL * SHAWconst.CI / SHAWconst.LF;//计算冻结量
                        if (EXCESS > FREEZE)
                        {//融水量超过冻结
                            TSPDT[i] = 0;
                            WEL += FREEZE;
                            RHOSP[i] = SHAWconst.RHOL * WEL / DZSP[i];//雪密度。
                            EXCESS -= FREEZE;//融水减去冻结量。
                            ABOVE -= FREEZE;
                            ICESPT[i] = 1;
                        }
                        else
                        {//融水全部冻结
                            TSPDT[i] += (EXCESS * SHAWconst.LF) / (SHAWconst.CI * WEL);//雪的温度。
                            WEL += EXCESS;//冻结厚度。
                            RHOSP[i] = SHAWconst.RHOL * WEL / DZSP[i];//雪密度。
                            ABOVE -= EXCESS;//上层融水和雨水减掉冻结的量。
                            EXCESS = 0.0;
                        }
                    }
                }

                DLWDT[i] += EXCESS;//液态水。
                CHANGE = DLWDT[i] - DLW[i] - ABOVE;
                //CHANGE = DLWDT[i] - DLW[i];

                if (Math.Abs(CHANGE) < 0.0000001)
                {//精度限制
                    ABOVE = 0.0;
                    EXCESS = 0.0;
                }
                else
                {
                    if (CHANGE <= 0.0)
                    {//一些液态水结冰了。添加到层的冰含量。
                        WEL = RHOSP[i] * DZSP[i] / SHAWconst.RHOL;//结冰量
                        WEL = WEL - CHANGE;
                        RHOSP[i] = SHAWconst.RHOL * WEL / DZSP[i];
                        ABOVE = 0.0;
                        EXCESS = 0.0;
                    }
                    else
                    {//发生融化，从冰含量中减去
                        WEL = RHOSP[i] * DZSP[i] / SHAWconst.RHOL;//雪层含冰量
                        //如果融化超过了雪层的冰含量——层就消失了。
                        if (CHANGE >= WEL)
                        {//层不见了。将液态水添加到下面的层中（excess）。该层的含冰量加上液态水不能从下一层中提取，但仍然添加到下一层的液态水含量（above）中。
                            NL = NL - 1;
                            ABOVE += WEL + DLW[i];
                            EXCESS = DLWDT[i];
                            DZSP[i] = 0.0;
                        }
                        else
                        {//层还在
                            WEL -= CHANGE;
                            DZSP[i] = SHAWconst.RHOL * WEL / RHOSP[i];
                            ABOVE = 0.0;
                            EXCESS = 0.0;
                        }
                    }
                }
            }
            //检查是否整个积雪都消失了。
            if (NL <= 0)
            {
                NSP = 0;
                WE = 0;
                TDEPTH = 0.0;
                SCOUT = ABOVE;
                SNOMLT(ref NSP, Timestep, ref SCOUT, ref STORE, ref WLAG, ref ICESPT, ref TSPDT, ref RHOSP, ref DZSP, ref DLWDT);//根据这一时期液态水的变化和积雪的物理特征，确定每个时期的积雪流出量
            }
            //消除已消失的层
            if (NL != NSP)
            {
                for (i = 0; i < NSP; i++)
                {
                    if (DZSP[i] > 0)
                    {
                        continue;
                    }
                    NEXT = i + 1;
                    for (j = NEXT; j < NSP; j++)
                    {
                        int L = j - 1;
                        DZSP[L] = DZSP[j];
                        RHOSP[L] = RHOSP[j];
                        TSPDT[L] = TSPDT[j];
                        DLWDT[L] = DLWDT[j];
                        ICESPT[L] = ICESPT[j];
                    }
                    NSP -= 1;
                    if (NSP == NL)
                    {
                        break;
                    }
                }
                //DLWDT[NSP] = DLWDT[NSP] + ABOVE;
                DLWDT[NSP - 1] = DLWDT[NSP - 1] + ABOVE;

                for (j = NSP; j < DLWDT.Count; j++)
                {
                    DZSP.RemoveAt(j);//RemoveAt( ) 移除指定索引的元素
                    RHOSP.RemoveAt(j);
                    TSPDT.RemoveAt(j);
                    DLWDT.RemoveAt(j);
                    ICESPT.RemoveAt(j);
                }
            }
            //检查每层的厚度。如果不在规定的范围内，则分割（如果太大）或添加到相邻层（如果太小）。
            TDEPTH = 0.0;
            i = 0;
            if (NSP == 1)
            {
                goto SML;
            }
        NL:
            ZZ = TDEPTH + DZSP[i] * 0.5;
            //计算层的所需厚度
            DZ1 = SHAWconst.THICK;
            if (ZZ > 0.3)
            {
                DZ1 = SHAWconst.THICK * (ZZ - 0.30) + SHAWconst.THICK;
            }
            //对照所需厚度检查实际厚度
            if (DZSP[i] > 1.55 * DZ1)
            {
                goto SD;
            }
            if ((DZSP[i] < 0.55 * DZ1) && (NSP > 1))
            {
                goto MU;
            }
            TDEPTH += DZSP[i];
            goto LAL;
        SD://厚度大于规定极限。细分层，从而创建一个新层。两个图层的特性相同。向下移动其他层。
            NEXT = i + 1;
            if (NEXT <= NSP)
            {
                DZSP.Add(0);//Add( ) 在List中添加一个对象的公有方法
                RHOSP.Add(0);
                TSPDT.Add(0);
                DLWDT.Add(0);
                ICESPT.Add(0);
                //for (j = NEXT; j < NSP; j++)
                for (j = NEXT; j < NSP + 1; j++)
                {
                    l = NSP - j + NEXT;
                    ll = l + 1;
                    DZSP[ll] = DZSP[l];
                    RHOSP[ll] = RHOSP[l];
                    TSPDT[ll] = TSPDT[l];
                    DLWDT[ll] = DLWDT[l];
                    ICESPT[ll] = ICESPT[l];
                }
            }
            TDEPTH = TDEPTH + DZSP[i];
            DZSP[NEXT] = DZSP[i] * 0.5;
            RHOSP[NEXT] = RHOSP[i];
            TSPDT[NEXT] = TSPDT[i];
            DLWDT[NEXT] = DLWDT[i] * 0.5;
            ICESPT[NEXT] = ICESPT[i];
            DZSP[i] = DZSP[i] * 0.5;
            DLWDT[i] = DLWDT[i] * 0.5;

            //TDEPTH = TDEPTH + DZSP[i];
            //DZSP[i] = DZSP[i] * 0.5;
            //RHOSP[i] = RHOSP[i];
            //TSPDT[i] = TSPDT[i];
            //DLWDT[i] = DLWDT[i] * 0.5;
            //ICESPT[i] = ICESPT[i];
            //DZSP[i] = DZSP[i] * 0.5;
            //DLWDT[i] = DLWDT[i] * 0.5;
            i += 1;
            NSP = NSP + 1;
            goto LAL;
        MU://厚度小于规定极限。添加到最小的相邻层，从而丢失一层。新层的性质是前两层的加权平均数。向上移动其他层。
            if ((i == 0) | (i == (NSP - 1)))
            {
                if (i == 0)
                {
                    NL = 2;

                }
                else
                {
                    NL = NSP - 1;

                }
            }
            else
            {
                NL = i;
                if (DZSP[i + 1] < DZSP[i - 1])
                {
                    NL = i + 2;
                }
            }
            //NL是最小的相邻层-将层I添加到层NL-1
            WEI = RHOSP[i] * DZSP[i] / SHAWconst.RHOL;
            WENL = RHOSP[NL - 1] * DZSP[NL - 1] / SHAWconst.RHOL;
            WEL = WEI + WENL;
            DZSP[NL - 1] = DZSP[NL - 1] + DZSP[i];
            RHOSP[NL - 1] = SHAWconst.RHOL * WEL / DZSP[NL - 1];
            DLWDT[NL - 1] = DLWDT[NL - 1] + DLWDT[i];
            TSPDT[NL - 1] = (WENL * TSPDT[NL - 1] + WEI * TSPDT[i]) / WEL;

            if (ICESPT[i] != ICESPT[NL - 1])
            {//unknown是不同的。计算新层的unknown
                FREEZE = 1.0 * (TSPDT[NL - 1] * SHAWconst.CI * RHOSP[NL - 1] * DZSP[NL - 1]) / (SHAWconst.LF * SHAWconst.RHOL);
                if (DLWDT[NL - 1] <= FREEZE)
                {//温度未知
                    TSPDT[NL - 1] = TSPDT[NL - 1] + (DLWDT[NL - 1] * SHAWconst.LF * SHAWconst.RHOL) / (SHAWconst.CI * RHOSP[NL - 1] * DZSP[NL - 1]);
                    WEL = WEL + DLWDT[NL - 1];
                    RHOSP[NL - 1] = SHAWconst.RHOL * WEL / DZSP[NL - 1];
                    ICESPT[NL - 1] = 0;
                }
                else
                {//液态水未知
                    DLWDT[NL - 1] = DLWDT[NL - 1] - FREEZE;
                    WEL = WEL + FREEZE;
                    RHOSP[NL - 1] = SHAWconst.RHOL * WEL / DZSP[NL - 1];
                    ICESPT[NL - 1] = 1;
                }
            }
            if (ICESPT[NL - 1] == 1)
            {
                TSPDT[NL - 1] = 0.0;
            }
            if (ICESPT[NL - 1] == 0)
            {
                DLWDT[NL - 1] = 0.0;
            }
            //if (NL < 1)
            if (NL < i + 1)
            {
                TDEPTH += DZSP[i];
            }

            NEXT = i + 1;//

            if (NEXT <= NSP - 1)
            {
                for (j = NEXT; j < NSP; j++)
                {
                    //l = j; //关注
                    l = j - 1;
                    DZSP[l] = DZSP[j];
                    RHOSP[l] = RHOSP[j];
                    TSPDT[l] = TSPDT[j];
                    DLWDT[l] = DLWDT[j];
                    ICESPT[l] = ICESPT[j];
                }
            }
            i = i - 1;
            //NSP = NSP - 1;
            DZSP.RemoveAt(NSP - 1);//RemoveAt( ) 移除指定索引的元素
            RHOSP.RemoveAt(NSP - 1);
            TSPDT.RemoveAt(NSP - 1);
            DLWDT.RemoveAt(NSP - 1);
            ICESPT.RemoveAt(NSP - 1);
            NSP = NSP - 1;

        LAL://开始下一层
            if (i < (NSP - 1))
            {
                i = i + 1;
                goto NL;
            }
        SML://调整密度计算融雪
            META(NSP, Timestep, ref RHOSP, ref DZSP, ref TSPDT, ref DLWDT);//计算由沉淀作用、压实作用和液态水的存在引起的积雪密度变化。
            SNOMLT(ref NSP, Timestep, ref SCOUT, ref STORE, ref WLAG, ref ICESPT, ref TSPDT, ref RHOSP, ref DZSP, ref DLWDT);//雪盖的出流量计算

            if (ZSP.Count < NSP)
            {
                for (i = ZSP.Count; i <= NSP; i++)
                    ZSP.Add(0);
            }
            //计算每个节点的深度
            ZSP[0] = 0.0;
            TDEPTH = DZSP[0];//表层雪的厚度。
            WE = DZSP[0] * RHOSP[0] / SHAWconst.RHOL + DLWDT[0];
            for (i = 1; i < NSP; i++)
            {
                ZSP[i] = TDEPTH + DZSP[i] / 2;
                TDEPTH += DZSP[i];
                WE += DZSP[i] * RHOSP[i] / SHAWconst.RHOL + DLWDT[i];//水当量。
            }
            ZSP[NSP] = TDEPTH;
        }

        /// <summary>
        /// 计算能量平衡Newton-Raphson的雪部分的雅可比矩阵系数
        /// </summary>
        /// <param name="B"></param>
        /// <param name="D"></param>
        /// <param name="ITER"></param>
        /// <param name="N"></param>
        /// <param name="NSP"></param>
        /// <param name="NR"></param>
        /// <param name="DT"></param>
        /// <param name="PRESSUR"></param>
        /// <param name="VAPSP"></param>
        /// <param name="VAPSPDT"></param>
        /// <param name="SSP"></param>
        /// <param name="ZSP"></param>
        /// <param name="DZSP"></param>
        /// <param name="TSP"></param>
        /// <param name="TSPDT"></param>
        /// <param name="DLW"></param>
        /// <param name="DLWDT"></param>
        /// <param name="ICESPT"></param>
        /// <param name="RHOSP"></param>
        /// <param name="soilwater"></param>
        /// <param name="soilice"></param>
        /// <param name="soilwar"></param>
        /// <param name="soilwas"></param>
        /// <param name="dt"></param>
        /// <param name="DZ"></param>
        /// <param name="QVSP"></param>
        /// <param name="A1"></param>
        /// <param name="B1"></param>
        /// <param name="C1"></param>
        /// <param name="D1"></param>
        public static void EBSNOW(double B, double D, int ITER, int N, int NSP, int NR, double DT, double PRESSUR, double VAPSP, double VAPSPDT, double[] SSP, double[] ZSP, double[] DZSP, double[] TSP, double[] TSPDT, double[] DLW, double[] DLWDT, int[] ICESPT, double[] RHOSP, double soilwater, double soilice, double soilwar, double soilwas, double dt, double DZ, out double[] QVSP, ref double[] A1, ref double[] B1, ref double[] C1, ref double[] D1)
        {//计算能量平衡Newton-Raphson的雪部分的雅可比矩阵系数
            double[] QVSPT = new double[NSP + 1];
            double[] QVSPDT = new double[NSP + 1];
            double[] SLOPE = new double[NSP + 1];
            double[] CSPT = new double[NSP + 1];
            double[] CSPDT = new double[NSP + 1];
            double[] CSP = new double[NSP + 1];
            double[] TK = new double[NSP + 1];
            double[] CON = new double[NSP + 1];
            double[] CONV = new double[NSP + 1];
            QVSP = new double[NSP + 1];
            int NSP1;
            //确定节点之间的水汽通量         
            if (ITER == 1)
                QVSNOW(NSP, PRESSUR, VAPSP, ZSP, TSP, ref SLOPE, ref CONV, ref QVSPT);
            QVSNOW(NSP, PRESSUR, VAPSPDT, ZSP, TSPDT, ref SLOPE, ref CONV, ref QVSPDT);
            if (NR > 0)
                SLOPE[NSP + 1] = 0.0;
            SHAWTools.WEIGHT(NSP, ref QVSP, QVSPT, QVSPDT);
            QVSP[NSP - 1] = Math.Min((soilwas - soilice - soilwater) * DZ / dt * SHAWconst.RHOL, Math.Max(QVSP[NSP - 1], (-soilwater + SHAWconst.LWcon * soilwar) * DZ / dt * SHAWconst.RHOL));
            if (ITER == 1)
            {//密度和热导率随时间步长保持不变
                //计算每个节点的热导率
                SHAWSnow.SNOWTK(NSP, RHOSP, ref TK);
                TK[NSP] = TK[NSP - 1];
                //计算节点间的热导
                NSP1 = NSP + 1;
                SHAWTools.CONDUC(NSP1, ZSP, TK, ref CON);
            }
            //计算每个节点的热容
            if (ITER == 1)
                SHAWSnow.SNOWHT(NSP, TSP, RHOSP, ref CSPT);

            SHAWSnow.SNOWHT(NSP, TSPDT, RHOSP, ref CSPDT);
            SHAWTools.WEIGHT(NSP, ref CSP, CSPT, CSPT);

            //确定表层的系数
            //D1[N] = D1[N] - CON[0] * (SHAWconst.WT * (TSP[0] - TSP[1]) + SHAWconst.WDT * (TSPDT[0] - TSPDT[1])) + SSP[0]
            //    - CSP[0] * (TSPDT[0] - TSP[0]) * DZSP[0] / DT
            //    - SHAWconst.RHOL * SHAWconst.LF * (DLWDT[0] - DLW[0]) / DT - SHAWconst.LS * QVSP[1];
            D1[N] = D1[N] - CON[0] * (SHAWconst.WT * (TSP[0] - TSP[1]) + SHAWconst.WDT * (TSPDT[0] - TSPDT[1])) + SSP[0]
               - CSP[0] * (TSPDT[0] - TSP[0]) * DZSP[0] / DT
               - SHAWconst.RHOL * SHAWconst.LF * (DLWDT[0] - DLW[0]) / DT - SHAWconst.LS * QVSP[0] + D;
            if (ICESPT[0] == 0)
            {//层没有融化-能量平衡基于温度
                A1[N + 1] = SHAWconst.WDT * (CON[0] + CONV[0] * SHAWconst.LS * SLOPE[0]);
                B1[N] = B1[N] - SHAWconst.WDT * (CON[0] + CONV[0] * SHAWconst.LS * SLOPE[0]) - DZSP[0] * CSP[0] / DT + B;
            }
            else
            {//层融化了，能量平衡基于含水量
                A1[N + 1] = 0;
                B1[N] = B1[N] - SHAWconst.RHOL * SHAWconst.LF / DT + B;
                if (N > 0)
                {//如果雪不是第一个材料，将最后一个节点导数设置为0.0
                    C1[N - 1] = 0.0;
                }
            }
            //确定积雪剩余部分的系数
            for (int i = N + 1; i < N + NSP; i++)
            {
                int j = i - N + 1 - 1;
                D1[i] = CON[j - 1] * (SHAWconst.WT * (TSP[j - 1] - TSP[j])
                + SHAWconst.WDT * (TSPDT[j - 1] - TSPDT[j]))
      - CON[j] * (SHAWconst.WT * (TSP[j] - TSP[j + 1])
                + SHAWconst.WDT * (TSPDT[j] - TSPDT[j + 1])) + SSP[j]
      - CSP[j] * (TSPDT[j] - TSP[j]) * DZSP[j] / DT
      - SHAWconst.RHOL * SHAWconst.LF * (DLWDT[j] - DLW[j]) / DT - SHAWconst.LS * (QVSP[j] - QVSP[j - 1]);
                if (ICESPT[j] == 0)
                {//层没有融化-能量平衡基于温度
                    A1[i + 1] = SHAWconst.WDT * (CON[j] + CONV[j] * SHAWconst.LS * SLOPE[j]);
                    B1[i] = -SHAWconst.WDT * (CON[j - 1] + CON[j])
                          - SHAWconst.WDT * SHAWconst.LS * SLOPE[j] * (CONV[j - 1] + CONV[j])
                          - DZSP[j] * CSP[j] / DT;
                    C1[i - 1] = SHAWconst.WDT * (CON[j - 1] + CONV[j - 1] * SHAWconst.LS * SLOPE[j]);
                }
                else
                {//层融化了，能量平衡基于含水量
                    A1[i + 1] = 0.0;
                    B1[i] = -SHAWconst.RHOL * SHAWconst.LF / DT;
                    C1[i - 1] = 0.0;
                }
            }
            //确定下一材质顶层的边界条件
            N = N + NSP;
            if (NR > 0)
            {//雪在残积物上
                //检查最后一个雪节点是否正在融化 - 如果是，能量平衡是基于含水量，而不是温度和A1（N）= 0.0
                if (ICESPT[NSP - 1] == 0) A1[N] = SHAWconst.WDT * CON[NSP - 1];
                B1[N] = -SHAWconst.WDT * CON[NSP - 1];
                C1[N - 1] = C1[N - 1] + SHAWconst.WDT * CON[NSP - 1];
                D1[N] = CON[NSP] * (SHAWconst.WT * (TSP[NSP - 1] - TSP[NSP])
                                + SHAWconst.WDT * (TSPDT[NSP - 1] - TSPDT[NSP]));
            }
            else
            {//雪是在裸土上-包括潜热传递和水汽通量依赖于土壤表面的温度

                //检查最后一个雪节点是否正在融化 - 如果是，能量平衡是基于含水量，而不是温度和A1（N）= 0.0
                if (ICESPT[NSP - 1] > 0)
                    A1[N] = SHAWconst.WDT * (CON[NSP - 1] + CONV[NSP - 1] * SHAWconst.LV * SLOPE[NSP - 1]);
                B1[N] = -1.0 * SHAWconst.WDT * (CON[NSP - 1] + CONV[NSP - 1] * SHAWconst.LV * SLOPE[NSP]);
                C1[N - 1] = SHAWconst.WDT * (CON[NSP - 1] + CONV[NSP - 1] * SHAWconst.LS * SLOPE[NSP]);
                D1[N] = CON[NSP] * (SHAWconst.WT * (TSP[NSP - 1] - TSP[NSP])
                           + SHAWconst.WDT * (TSPDT[NSP - 1] - TSPDT[NSP])) + SHAWconst.LV * QVSP[NSP - 1];
            }
        }

        /// <summary>
        /// 计算雪面的反照率、消光系数和每层吸收的太阳辐射量
        /// </summary>
        /// <param name="RHOSP"></param>
        /// <param name="ZSP"></param>
        /// <param name="ALBNXT"></param>
        /// <returns></returns>
        public static double SNOALB(double RHOSP, double ZSP, double ALBNXT)
        {//计算雪面的反照率、消光系数和每层吸收的太阳辐射量
            double ALBSNO = 0.0;
            double SPGRAV = RHOSP / SHAWconst.RHOL;
            double GRAIN = SHAWconst.G1 + SHAWconst.G2 * Math.Pow(SPGRAV, 2) + SHAWconst.G3 * Math.Pow(SPGRAV, 4);//冰晶粒度直径
            ALBSNO = Math.Max(0.35, 1.0 - 0.206 * SHAWconst.EXTSP * Math.Sqrt(GRAIN));//雪面的反照率
            if (ZSP <= 0.04)
            {
                double ABS = 1.0 - ALBNXT;
                double W = 2.0 * (1.0 - ALBSNO) / (1.0 + ALBSNO);
                double EXC = SHAWconst.EXTSP * SPGRAV * Math.Sqrt(1.0 / GRAIN) * 100.0;//雪的消光系数、辐射穿透雪层的衰减系数
                double Y = Math.Exp(-1.0 * EXC * ZSP) * (ABS + W * (ABS / 2.0 - 1.0)) / (W * (ABS / 2.0 - 1.0) * Math.Cosh(EXC * ZSP) - ABS * Math.Sinh(EXC * ZSP));
                ALBSNO = (1.0 - W * (1.0 - Y) / 2.0) / (1.0 + W * (1.0 - Y) / 2.0);//薄雪层的反照率
            }
            if (ZSP <= SHAWconst.SNOCOF)
            {
                ALBSNO = ALBNXT + (ALBSNO - ALBNXT) * Math.Pow((ZSP / SHAWconst.SNOCOF), SHAWconst.SNOEXP);//雪太薄没有覆盖全部地面时的反照率
            }
            return ALBSNO;
        }

        /// <summary>
        /// 雪接受的短波辐射
        /// </summary>
        /// <param name="NSP"></param>
        /// <param name="ALBSNO"></param>
        /// <param name="DZSP"></param>
        /// <param name="RHOSP"></param>
        /// <param name="DIRECT"></param>
        /// <param name="DIFFUS"></param>
        /// <param name="SWSNOW"></param>
        public static void SWRSNO(int NSP, double ALBSNO, double[] DZSP, double[] RHOSP, ref double DIRECT, ref double DIFFUS, ref double[] SWSNOW)
        {//雪接受的短波辐射
            double TOTAL = (DIRECT + DIFFUS) * (1.0 - ALBSNO);
            for (int i = 0; i < NSP; i++)
            {
                double SPGRAV = RHOSP[i] / SHAWconst.RHOL;
                double GRAIN = SHAWconst.G1 + SHAWconst.G2 * Math.Pow(SPGRAV, 2) + SHAWconst.G3 * Math.Pow(SPGRAV, 4);//冰晶粒度直径
                double EXC = SHAWconst.EXTSP * SPGRAV * Math.Sqrt(1.0 / GRAIN) * 100.0;//雪的消光系数
                double PERCAB = 1.0 - Math.Exp(-1.0 * EXC * DZSP[i]);
                // PERCAB = 0.8;
                SWSNOW[i] = TOTAL * PERCAB;//雪吸收的短波辐射
                TOTAL = TOTAL - SWSNOW[i];//穿过来的太阳辐射
            }
            DIFFUS = TOTAL;
            DIRECT = 0.0;
        }

        /// <summary>
        /// 计算由破坏性（等温）变质作用（沉淀）、压实作用和液态水的存在引起的积雪密度变化。
        /// </summary>
        /// <param name="Timestep"></param>
        /// <param name="RHOSP"></param>
        /// <param name="DZSP"></param>
        /// <param name="TSPDT"></param>
        /// <param name="DLWDT"></param>
        /// <param name="SWweight"></param>
        /// <param name="CMET1"></param>
        /// <param name="CMET2"></param>
        /// <param name="CMET3"></param>
        /// <param name="CMET4"></param>
        /// <param name="CMET5"></param>
        /// <param name="SNOMAX"></param>
        /// <param name="RHOI"></param>
        /// <param name="RHOL"></param>
        public static void META(int NSP, double Timestep, ref List<double> RHOSP, ref List<double> DZSP, ref List<double> TSPDT, ref List<double> DLWDT)
        {//计算由破坏性（等温）变质作用（沉淀）、压实作用和液态水的存在引起的积雪密度变化。
            double SWweight = 0.0;//层上方的水当量（CM）。
            //int NSP = DZSP.Count;
            double WEL, TERM, T1, T2;

            if ((SHAWconst.CMET1 <= 0.0) || (SHAWconst.CMET3 <= 0.0))
            {
                if (SHAWconst.CMET5 <= 0.0)
                {
                    return;
                }
            }
            for (int i = 0; i < NSP; i++)
            {// IF DENSITY IS THAT OF ICE, DO NOT INCREASE IT ANY MORE      如果密度是冰的密度，不再增加
                if (RHOSP[i] >= SHAWconst.RHOI)
                {
                    continue;
                }
                else
                {
                    WEL = RHOSP[i] * DZSP[i] / SHAWconst.RHOL;
                    //DESTRUCTIVE METAMORPHISM TERM.   沉淀
                    TERM = Math.Exp(SHAWconst.CMET4 * TSPDT[i]);
                    if (RHOSP[i] <= SHAWconst.SNOMAX)
                    {
                        T1 = TERM * SHAWconst.CMET3;
                    }
                    else
                    {
                        T1 = TERM * SHAWconst.CMET3 * Math.Exp(-46.0 * (RHOSP[i] - SHAWconst.SNOMAX) / SHAWconst.RHOL);
                    }
                    //COMPACTION TERM   压实
                    TERM = Math.Exp(0.08 * TSPDT[i]);
                    T2 = SWweight * SHAWconst.CMET1 * Math.Exp(-1.0 * SHAWconst.CMET2 * RHOSP[i] / SHAWconst.RHOL) * TERM;
                    //LIQUID-WATER TERM.   液态水
                    //if (DLWDT[i] >= 0)
                    if (DLWDT[i] > 0)//有液态水的时候需要乘以参数CMET5
                    {
                        T1 = SHAWconst.CMET5 * T1;
                    }
                    RHOSP[i] = RHOSP[i] * (1.0 + Timestep * (T1 + T2) / 3600.0);//经过沉淀（T1)和挤压（T2)后的雪的密度。
                    DZSP[i] = SHAWconst.RHOL * WEL / RHOSP[i];
                    SWweight = SWweight + (WEL + DLWDT[i]) * 100.0;//雪当量（用水当量表示）cm

                }
            }
        }

        /// <summary>
        /// 根据这一时期液态水的变化和积雪的物理特征，确定每个时期的积雪流出量
        /// </summary>
        /// <param name="NSP"></param>
        /// <param name="DT"></param>
        /// <param name="SCOUT"></param>
        /// <param name="STORE"></param>
        /// <param name="WLAG"></param>
        /// <param name="ICESPT"></param>
        /// <param name="TSPDT"></param>
        /// <param name="RHOSP"></param>
        /// <param name="DZSP"></param>
        /// <param name="DLWDT"></param>
        public static void SNOMLT(ref int NSP, double DT, ref double SCOUT, ref double STORE, ref List<double> WLAG, ref List<int> ICESPT, ref List<double> TSPDT, ref List<double> RHOSP, ref List<double> DZSP, ref List<double> DLWDT)
        {//根据这一时期液态水的变化和积雪的物理特征，确定每个时期的积雪流出量
            int NLAG = 0, IDT, NI, FN, FJ;
            double EXCESS = 0.0, BOTTOM = 0.0, FREEZE = 0.0, DENSE, FLAG, FLMAX;
            double OUTHR = 0.0, EXCSHR, HOURS;
            double WEL, PLW, WMAX, W, WE, TDEPTH, POR, WINC;
            int i, j, k;
            /*
            if (IFIRST == 0)
            {
                double JDT = SHAWconst.CLAG1 + 0.01;
                NLAG = (int)JDT + 2;
                NLAG = Math.Min(11, NLAG);
                IFIRST = 1;
            }
            */
            //STORE是雪层中储存的液态水（已经滞后）的量。    WLAG是滞后过程中液态水的量。NLAG是使用的数组元素数
            NLAG = Math.Min(11, ((int)(SHAWconst.CLAG1 + 0.01) + 2));
            if (NSP <= 0)
            {//积雪消失
                for (j = 0; j < NLAG; j++)
                {
                    SCOUT += WLAG[j];
                    WLAG[j] = 0.0;
                }
                SCOUT += STORE;//STORE是雪层中储存的液态水（已经滞后）的量
                STORE = 0.0;
                return;
            }
            //确定在这段时间内产生的过量液态水（超过液态水保持能力）。
            EXCESS = 0.0;
            //底层多余的水不会被排出。
            if (NSP > 1)
            {
                BOTTOM = 0.0;
                if (ICESPT[NSP - 1] == 1)
                {
                    WEL = RHOSP[NSP - 1] * DZSP[NSP - 1] / SHAWconst.RHOL;
                    PLW = (SHAWconst.PLWMAX - SHAWconst.PLWHC) * (SHAWconst.PLWDEN - RHOSP[NSP - 1]) / SHAWconst.PLWDEN + SHAWconst.PLWHC;//积雪的体积含水率（PLW）计算 m3/m3.
                    if (RHOSP[NSP - 1] >= SHAWconst.PLWDEN)
                    {
                        PLW = SHAWconst.PLWHC;
                    }
                    WMAX = PLW * WEL;//积雪的水含量 m.
                    if (DLWDT[NSP - 1] > WMAX)
                    {
                        BOTTOM = DLWDT[NSP - 1] - WMAX;
                    }
                }
            }
            WE = 0.0;
            TDEPTH = 0.0;
            for (i = 0; i < NSP; i++)
            {
                WEL = RHOSP[i] * DZSP[i] / SHAWconst.RHOL;
                if (ICESPT[i] == 0)//结冰
                {//层低于零摄氏度
                    if (EXCESS == 0.0)
                    {
                        goto DJ;
                    }
                    //一部分液态水结冰
                    FREEZE = -1.0 * TSPDT[i] * SHAWconst.CI * WEL / SHAWconst.LF;
                    if (EXCESS <= FREEZE)
                    {//excess全部结冰
                        TSPDT[i] = TSPDT[i] + (EXCESS * SHAWconst.LF * SHAWconst.RHOL) / (SHAWconst.CI * WEL * SHAWconst.RHOL);
                        WEL += EXCESS;
                        EXCESS = 0.0;
                        RHOSP[i] = SHAWconst.RHOL * WEL / DZSP[i];
                        goto DJ;
                    }
                    else
                    {//excess超过结冰量
                        TSPDT[i] = 0.0;
                        WEL += FREEZE;
                        RHOSP[i] = SHAWconst.RHOL * WEL / DZSP[i];
                        EXCESS = EXCESS - FREEZE;
                        ICESPT[i] = 1;
                    }
                }
                PLW = (SHAWconst.PLWMAX - SHAWconst.PLWHC) * (SHAWconst.PLWDEN - RHOSP[i]) / SHAWconst.PLWDEN + SHAWconst.PLWHC;
                if (RHOSP[i] >= SHAWconst.PLWDEN)
                {
                    PLW = SHAWconst.PLWHC;
                }
                WMAX = PLW * WEL;//积雪中能含有的水量。
                W = DLWDT[i] + EXCESS;//目前液态水量
                if (W <= WMAX)
                {
                    DLWDT[i] = W;
                    EXCESS = 0.0;
                }
                else
                {
                    DLWDT[i] = WMAX;
                    EXCESS = W - WMAX;
                }
            DJ: WE += WEL;
                TDEPTH += DZSP[i];
            }

            if (NSP == 1)
            {//如果积雪中只有一个节点，水不会滞后
                SCOUT = EXCESS;
                for (j = 0; j < NLAG; j++)
                {
                    SCOUT += WLAG[j];
                    WLAG[j] = 0.0;
                }
                SCOUT += STORE;
                STORE = 0.0;
                return;
            }

            EXCESS -= BOTTOM;
            if (ICESPT[NSP - 1] == 0)
            {//不要让任何水滞后或储存离开积雪（excess必须等于0.0）
                OUTHR = 0.0;
                SCOUT = 0.0;
                return;
            }
            //把多余的水穿过积雪。      经验滞后和衰减方程-使用一小时时间步长。
            EXCSHR = EXCESS * 3600.0 / DT;
            IDT = Math.Max(1, (int)Math.Ceiling(DT / 3600.0));
            HOURS = 1.0;

            DENSE = WE / TDEPTH;
            SCOUT = 0.0;
            for (int IHR = 1; IHR <= IDT; IHR++)
            {
                if (IHR == IDT)
                {//如果这是最后一个时间增量，说明时间步长中剩余的部分小时
                    HOURS = DT / 3600 - (IDT - 1);
                }
                EXCESS = EXCSHR * HOURS;
                OUTHR = 0.0;
                //深度、密度和过量水的滞后函数
                if (EXCSHR >= 0.00001)
                {
                    NI = Math.Max(1, (int)Math.Ceiling(Math.Pow(EXCSHR * 10000.0, 0.3) + 0.5));
                    FN = NI;
                    FLMAX = SHAWconst.CLAG1 * (1.0 - Math.Exp(-0.25 * TDEPTH / DENSE));//最大滞后系数 h
                    for (j = 1; j <= NI; j++)
                    {
                        FJ = j;
                        FLAG = FLMAX / (SHAWconst.CLAG2 * EXCSHR * 100.0 * (FJ - 0.5) / FN + 1.0);//实际液态水的滞后时间 h
                        //k = (int)Math.Ceiling(FLAG + 1.0);
                        //k = FLAG + 1.0;
                        k = (int)Math.Ceiling(FLAG);
                        POR = k - FLAG;
                        WINC = 1.0 / FN;
                        WLAG[k - 1] += EXCESS * WINC * POR;
                        WLAG[k] += EXCESS * WINC * (1.0 - POR);
                    }
                }
                else
                {
                    WLAG[0] += EXCESS;
                }
                //ATTENUATION-FUNCTION OF DENSITY AND PREVIOUS OUTFLOW.密度和PREVIOUS OUTFLOW的衰减函数
                if ((STORE + WLAG[0]) != 0.0)
                {
                    double R = 1.0 / (SHAWconst.CLAG3 * Math.Exp(-SHAWconst.CLAG4 * WLAG[0] * DENSE / TDEPTH) + 1.0);
                    OUTHR = (STORE + WLAG[0]) * R;//雪盖的出流
                    STORE = STORE + (WLAG[0] - OUTHR) * HOURS;//出流以小时为单位
                    SCOUT = SCOUT + OUTHR * HOURS;
                    if (STORE <= 0.00001)
                    {
                        OUTHR = OUTHR + STORE;
                        SCOUT = SCOUT + STORE;
                        STORE = 0.0;
                    }
                }
                NI = NLAG - 1;
                for (j = 0; j < NI; j++)
                {
                    WLAG[j] = WLAG[j] * (1.0 - HOURS) + WLAG[j + 1] * HOURS;
                    //if (WLAG[j + 1] <= 0.0000001)
                    if (WLAG[j + 1] <= 0.000001)
                    {//滞后深度太小--将整个深度传递给下一个滞后
                        WLAG[j] = WLAG[j] + WLAG[j + 1] + WLAG[j + 1] * (1.0 - HOURS);
                        WLAG[j + 1] = 0.0;
                    }
                }
                WLAG[NLAG - 1] = 0.0;
            }
            SCOUT += BOTTOM;

        }

        /// <summary>
        /// 因为新降雪而增加雪的层数
        /// </summary>
        /// <param name="NSP"></param>
        /// <param name="TWBULB"></param>
        /// <param name="SNOW"></param>
        /// <param name="ZS"></param>
        /// <param name="soilwas"></param>
        /// <param name="soilwa"></param>
        /// <param name="soilice"></param>
        /// <param name="mineden"></param>
        /// <param name="Csmine"></param>
        /// <param name="MELT"></param>
        /// <param name="Cssoil"></param>
        /// <param name="TSDT"></param>
        /// <param name="TSPDT"></param>
        /// <param name="ZSP"></param>
        /// <param name="RHOSP"></param>
        /// <param name="DZSP"></param>
        /// <param name="ICESPT"></param>
        /// <param name="DLW"></param>
        /// <param name="DLWDT"></param>
        /// <param name="TQVSP"></param>
        public static void NWSNOW(ref int NSP, double TWBULB, double SNOW, double ZS, double soilwas, double soilwa, double soilice, double mineden, double Csmine, ref double MELT, ref double Cssoil, ref double TSDT, ref List<double> TSPDT, ref List<double> ZSP, ref List<double> RHOSP, ref List<double> DZSP, ref List<int> ICESPT, ref List<double> DLW, ref List<double> DLWDT, ref List<double> TQVSP)
        {//ADDS SNOW LAYERS FOR NEWLY FALLEN SNOW 因为新降雪而增加雪的层数
            double DENSTY = 0.0, DEPTH = 0.0, DNS = 0.0, FREEZE, EXTRA, DOWN;
            int NWLAYR = 0;
            if (TWBULB <= -15.0)//湿球温度＜-15.0
            {
                DENSTY = 50.0;
            }
            else
            {
                DENSTY = 50.0 + 1.7 * Math.Pow((TWBULB + 15.0), 1.5);//新的降雪的密度
            }
            DEPTH = SNOW * SHAWconst.RHOL / DENSTY;//新的降雪的厚度（降雨的深度转换而来）

            MELT = 0.0;

            if (NSP == 0)
            {//积雪不存在——融化一些雪，使下面的物质达到0度
                if (TSDT <= 0.0)
                {//不需要融化
                    MELT = 0.0;
                }
                else
                {
                    SHAWHeat.Cellcscal(soilwas, soilwa, soilice, mineden, Csmine, SHAWconst.RHOL, SHAWconst.CL, SHAWconst.RHOA, SHAWconst.CA, SHAWconst.RHOI, SHAWconst.CI, out Cssoil);
                    MELT = Cssoil * ZS * TSDT / (SHAWconst.RHOL * SHAWconst.LF - SHAWconst.RHOL * SHAWconst.CI * TWBULB);//融雪，mm
                    SNOW = SNOW - MELT;
                    DEPTH = DEPTH - MELT * SHAWconst.RHOL / DENSTY;//融雪后调整雪深
                    if (SNOW <= 0.0)
                    {//雪全部融化。所有落下的雪都被融化了——调整土壤温度以获得融化雪所需的能量
                        MELT += SNOW;
                        TSDT = TSDT - (SHAWconst.RHOL * SHAWconst.LF - SHAWconst.RHOL * SHAWconst.CI * TWBULB) * MELT / (Cssoil * ZS);
                        return;
                    }
                    TSDT = 0.0;//雪水混合
                }
            }
            else
            {//新雪落在旧雪上——检查新雪是否导致表层厚度超过指定的深度限制。
                if ((DZSP[0] + DEPTH) <= (1.55 * SHAWconst.THICK))
                {//没有超出规定的表层厚度，将所有新雪并入旧的表层
                    DNS = DEPTH;//？新增的厚度。表层新雪的厚度
                    DEPTH = 0.0;
                    NWLAYR = 0;
                }
                else
                {//超出规定的表层厚度，确定应与旧表层结合多少
                    if (DZSP[0] >= SHAWconst.THICK)
                    {//表层旧雪就已经超出厚度，不要添加新的雪到旧的表面层
                        DNS = 0.0;
                        goto NAS;
                    }
                    DNS = SHAWconst.THICK - DZSP[0];
                    DEPTH = DEPTH - DNS;//超出表层厚度的多余的雪
                }
                //将新雪合并到旧表层——定义特性
                double WEI = RHOSP[0] * DZSP[0] / SHAWconst.RHOL;//表层旧雪化成水的话，水的厚度
                double WENS = DENSTY * DNS / SHAWconst.RHOL;//表层新雪化成水的话，水的厚度
                double WEL = WEI + WENS;//表层雪化成水的话，水的厚度
                DZSP[0] = DZSP[0] + DNS;//现在的表层雪（旧雪+新雪）厚度
                RHOSP[0] = SHAWconst.RHOL * WEL / DZSP[0];//表层雪的密度
                TSPDT[0] = (WENS * TWBULB + WEI * TSPDT[0]) / WEL;//表层雪的温度（新雪旧雪温度加权平均）
                if (ICESPT[0] == 1)
                {//新层可能存在液态水和低于冰点的温度
                    FREEZE = -1.0 * (TSPDT[0] * SHAWconst.CI * RHOSP[0] * WEL) / (SHAWconst.LF * SHAWconst.RHOL);//冻结温度                 
                    if (DLWDT[0] < FREEZE)
                    {
                        TSPDT[0] += DLWDT[0] * SHAWconst.LF * SHAWconst.RHOL / (SHAWconst.CI * WEL);
                        WEL += DLWDT[0];
                        RHOSP[0] = SHAWconst.RHOL * WEL / DZSP[0];
                        DLWDT[0] = 0.0;
                        ICESPT[0] = 0;
                    }
                    else
                    {
                        DLWDT[0] = DLWDT[0] - FREEZE;
                        WEL = WEL + FREEZE;
                        RHOSP[0] = SHAWconst.RHOL * WEL / DZSP[0];
                        TSPDT[0] = 0.0;
                    }
                }
            }

        NAS://计算具有全新雪的层数
            NWLAYR = (int)Math.Floor(DEPTH / SHAWconst.THICK);//层数
            EXTRA = DEPTH - NWLAYR * SHAWconst.THICK;//不足以构成一整层的多余雪
            if (EXTRA >= 0.55 * SHAWconst.THICK) NWLAYR += 1;
            if ((EXTRA >= 0.0) & (NWLAYR == 0)) NWLAYR = 1;
            //if ((EXTRA > 0.0) & (NWLAYR == 0)) NWLAYR = 1;
            //增加层数
            if (NSP > 0)
            {
                DOWN = DEPTH + DNS;//所有的新雪
                if (NWLAYR == 0)
                {
                    ZSP[0] = 0.0;
                    for (int i = 1; i < NSP + 1; i++)
                    {
                        ZSP[i] = ZSP[i] + DOWN;
                    }
                    return;
                }
                else
                {
                    //for (int i = 0; i < NWLAYR + 1; i++)
                    for (int i = 0; i < NWLAYR; i++)
                    {
                        ZSP.Add(0);
                        TSPDT.Add(0);
                        RHOSP.Add(0);
                        DLW.Add(0);
                        DLWDT.Add(0);
                        ICESPT.Add(0);
                        DZSP.Add(0);
                        TQVSP.Add(0);
                    }
                    ZSP[NSP + NWLAYR] = ZSP[NSP] + DOWN;
                    TSPDT[NSP + NWLAYR] = TSPDT[NSP];
                    for (int i = NSP - 1; i >= 0; i--)
                    {
                        RHOSP[NWLAYR + i] = RHOSP[i];
                        TSPDT[NWLAYR + i] = TSPDT[i];
                        DLW[NWLAYR + i] = DLW[i];
                        DLWDT[NWLAYR + i] = DLWDT[i];
                        ICESPT[NWLAYR + i] = ICESPT[i];
                        ZSP[NWLAYR + i] = ZSP[i] + DOWN;
                        DZSP[NWLAYR + i] = DZSP[i];
                        TQVSP[NWLAYR + i] = TQVSP[i];
                    }
                    ZSP[NWLAYR] = ZSP[NWLAYR] + DZSP[NWLAYR] / 2.0;

                }
            }

            if (NSP <= 0)
            {
                ZSP = new List<double>();
                TSPDT = new List<double>();
                RHOSP = new List<double>();
                DLWDT = new List<double>();
                DLW = new List<double>();
                ICESPT = new List<int>();
                DZSP = new List<double>();
                TQVSP = new List<double>();
                for (int i = 0; i < NWLAYR + 1; i++)
                {
                    ZSP.Add(0);
                    TSPDT.Add(0);
                    RHOSP.Add(0);
                    DLW.Add(0);
                    DLWDT.Add(0);
                    ICESPT.Add(0);
                    DZSP.Add(0);
                    TQVSP.Add(0);
                }
            }

            EXTRA = DEPTH - (NWLAYR - 1) * SHAWconst.THICK;//添加的行，以便厚度在一层与两次之间的以一层的厚度存在
            ZSP[0] = 0.0;
            DZSP[0] = EXTRA;
            RHOSP[0] = DENSTY;
            TSPDT[0] = TWBULB;
            DLW[0] = 0.0;
            DLWDT[0] = 0.0;
            ICESPT[0] = 0;
            TQVSP[0] = 0.0;
            double TDEPTH = DZSP[0];

            for (int j = 1; j < NWLAYR; j++)
            {
                DZSP[j] = SHAWconst.THICK;
                ZSP[j] = TDEPTH + DZSP[j] / 2.0;
                TDEPTH = TDEPTH + DZSP[j];
                RHOSP[j] = DENSTY;
                TSPDT[j] = TWBULB;
                DLW[j] = 0.0;
                DLWDT[j] = 0.0;
                ICESPT[j] = 0;
                TQVSP[j] = 0.0;
            }
            if (NSP == 0)
            {
                ZSP[NWLAYR] = TDEPTH;
            }
            NSP += NWLAYR;
        }

        /// <summary>
        /// 积雪中的水汽扩散
        /// </summary>
        /// <param name="NSP"></param>
        /// <param name="PRESSUR"></param>
        /// <param name="VAPSP"></param>
        /// <param name="ZSP"></param>
        /// <param name="TSP"></param>
        /// <param name="SLOPE"></param>
        /// <param name="CONV"></param>
        /// <param name="QVSP"></param>
        public static void QVSNOW(int NSP, double PRESSUR, double VAPSP, double[] ZSP, double[] TSP, ref double[] SLOPE, ref double[] CONV, ref double[] QVSP)
        {//积雪中的水汽扩散
            double[] VAPSNO = new double[NSP + 1];
            double[] VAPICE = new double[NSP + 1];
            double TMP, SATV, HUMID;
            for (int i = 0; i < NSP; i++)
            {//确定每个节点的水汽扩散率、密度和梯度
                VAPSNO[i] = SHAWconst.VDIFSP * (SHAWconst.P0 / PRESSUR) * Math.Pow((1.0 + TSP[i] / SHAWconst.Tk0), SHAWconst.VAPSPX);
                SHAWTools.VSLOPE(TSP[i], out SATV, out SLOPE[i]);
                TMP = TSP[i] + SHAWconst.Tk0;
                HUMID = Math.Exp(0.018 / (SHAWconst.UGAS * TMP) * SHAWconst.LF * TSP[i] / TMP);
                VAPICE[i] = HUMID * SATV;
                SLOPE[i] = HUMID * SLOPE[i];
            }
            VAPICE[NSP] = VAPSP;
            VAPSNO[NSP] = VAPSNO[NSP - 1];
            SHAWTools.VSLOPE(TSP[NSP], out SATV, out SLOPE[NSP]);
            SLOPE[NSP] = SLOPE[NSP] * VAPSP / SATV;
            //确定节点间的传导系数
            int NSP1 = NSP + 1;
            SHAWTools.CONDUC(NSP1, ZSP, VAPSNO, ref CONV);
            for (int i = 0; i < NSP; i++)
            {//计算节点间的水汽通量
                QVSP[i] = CONV[i] * (VAPICE[i] - VAPICE[i + 1]);
            }
        }

        /// <summary>
        /// 计算雪层的导热系数
        /// </summary>
        /// <param name="NSP"></param>
        /// <param name="RHOSP"></param>
        /// <param name="TK"></param>
        public static void SNOWTK(int NSP, double[] RHOSP, ref double[] TK)
        {//计算雪层的导热系数
            for (int i = 0; i < NSP; i++)
            {
                TK[i] = SHAWconst.TKSPA + SHAWconst.TKSPB * Math.Pow((RHOSP[i] / SHAWconst.RHOL), SHAWconst.TKSPEX);
                // TK[i] = 0.3;
            }
        }

        /// <summary>
        /// 计算雪的体积比热
        /// </summary>
        /// <param name="NSP"></param>
        /// <param name="TSP"></param>
        /// <param name="RHOSP"></param>
        /// <param name="CSP"></param>
        public static void SNOWHT(int NSP, double[] TSP, double[] RHOSP, ref double[] CSP)
        {//计算雪的体积比热
            double SHPEAT, SATV, S;
            for (int i = 0; i < NSP; i++)
            {
                SHPEAT = 92.96 + 7.37 * (TSP[i] + SHAWconst.Tk0);//雪的体积热容
                SHAWTools.VSLOPE(TSP[i], out SATV, out S);
                CSP[i] = RHOSP[i] * SHPEAT + (1.0 - RHOSP[i] / SHAWconst.RHOI) * SHAWconst.LS * S;
            }
        }

        /// <summary>
        /// 计算积雪长波辐射
        /// </summary>
        /// <param name="TSP"></param>
        /// <param name="TSPDT"></param>
        /// <param name="IN"></param>
        /// <param name="LWRTOP"></param>
        /// <param name="LWRBOT"></param>
        public static void LWRSNO(double TSP, double TSPDT, ref double IN, ref double LWRTOP, ref double LWRBOT)
        {//计算积雪长波辐射
            double TSPK = TSP + SHAWconst.Tk0;
            LWRTOP = LWRTOP + SHAWconst.EMITSP * IN;//接收
            double OUT = SHAWconst.EMITSP * SHAWconst.STEFAN * (Math.Pow(TSPK, 4) + 4.0 * SHAWconst.WDT * Math.Pow(TSPK, 3) * (TSPDT - TSP));//发射
            LWRBOT = LWRBOT - OUT;
            IN = OUT;
        }

        /// <summary>
        /// 建立了有积雪时土壤系统水量平衡的上边界条件
        /// </summary>
        /// <param name="NSP"></param>
        /// <param name="PRESUR"></param>
        /// <param name="TSPDTn"></param>
        /// <param name="ZSP"></param>
        /// <param name="ICESDT"></param>
        /// <param name="VAPSPT"></param>
        /// <param name="QVSPn"></param>
        /// <param name="TSDT0"></param>
        /// <param name="B20"></param>
        /// <param name="D20"></param>
        public static void SNOWBC(int NSP, double PRESUR, double TSPDTn, double[] ZSP, int ICESDT, double VAPSPT, double QVSPn, double TSDT0, ref double B20, ref double D20)//建立了有积雪时土壤系统水量平衡的上边界条件
        {
            //确定底部积雪节点的水汽扩散率
            double VDIF = SHAWconst.VDIFSP * (SHAWconst.P0 / PRESUR) * Math.Pow((1.0 + TSPDTn / SHAWconst.Tk0), SHAWconst.VAPSPX);
            double CON = VDIF / (ZSP[NSP] - ZSP[NSP - 1]);
            //定义系数
            if (ICESDT == 0)
            {//土壤表面无冰-基质势未知
                B20 = -1.0 * SHAWconst.WDT * CON * VAPSPT * 0.018 * SHAWconst.G / (SHAWconst.UGAS * (TSDT0 + SHAWconst.Tk0)) / SHAWconst.RHOL;
            }
            else
            {//土壤表面存在冰-冰含量未知
                B20 = 0.0;
            }
            //D20 = Math.Max((-soilwater + SHAWconst.LWcon * soilwar) * DZ / dt, QVSPn / SHAWconst.RHOL);
            D20 = QVSPn / SHAWconst.RHOL;
        }
    }
}
