﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using MPI;

namespace HHMM
{
    public class HHMMout
    {

        #region

        /// <summary>
        /// 模型输出
        /// </summary>
        /// <param name="datapath"></param>
        /// <param name="HHvar"></param>
        /// <param name="TVvar"></param>
        /// <param name="SVvar"></param>
        /// <param name="comm"></param>
        public static void Concluresult(string datapath, HHMMvar HHvar, SHAWvar TVvar, SVCSvar SVvar, Intracommunicator comm)
        {
            comm.Barrier();
            resultallrank(HHvar, TVvar, SVvar, comm);//利用reduce方法整合所有rank的统计结果到rank0
            if (HHvar.tn == 0)
            {
                rfopen(datapath, HHvar.solutenum, out HHvar.resultfile);

                if (comm.Rank == 0) rfopen(@"..\..\output\", HHvar.solutenum, out HHvar.resultfileall);
                //HHMMout.soilparavtkout(datapath, HHvar, TVvar);
            }
            HHMMout.cubvtkout(datapath, HHvar);//地表水深
            HHMMout.soilwatervtkout(datapath, HHvar, TVvar);//地下层含水率
            HHMMout.soiltempervtkout(datapath, HHvar, TVvar);//地下层温度
            HHMMout.soilsolutevtkout(datapath, HHvar, TVvar);//地下层溶质
            HHMMout.soilhvtkout(datapath, HHvar, TVvar);//地下层水势
            HHMMout.soilicevtkout(datapath, HHvar, TVvar);//冻土

            rfwrite(HHvar.resultfile, SVvar.Totalrain, TVvar.Totalsnow, TVvar.TotalDLW, SVvar.Totalwatervolume, SVvar.Totalinfil, SVvar.Totalrecharge, SVvar.Total_volume_outflow, SVvar.Meanheight, TVvar.Totalinterflow, TVvar.Totalsoilwatervolume, TVvar.Totalrockwatervolume, TVvar.Totalbot, TVvar.Totalsoile, TVvar.Totalcanopyt, TVvar.Totalsoilice, TVvar.Totalsoilsolute, TVvar.Solutebot, TVvar.Soluteinter, TVvar.SoluteCG, HHvar.regionpara.Altitu);

            if (comm.Rank == 0) rfwrite(HHvar.resultfileall, SVvar.Totalrainall, TVvar.Totalsnowall, TVvar.TotalDLWall, SVvar.Totalwatervolumeall, SVvar.Totalinfilall, SVvar.Totalrechargeall, SVvar.Total_volume_outflowall, SVvar.Meanheightall, TVvar.Totalinterflowall, TVvar.Totalsoilwatervolumeall, TVvar.Totalrockwatervolumeall, TVvar.Totalbotall, TVvar.Totalsoileall, TVvar.Totalcanopytall, TVvar.Totalsoiliceall, TVvar.Totalsoilsoluteall, TVvar.Solutebotall, TVvar.Soluteinterall, TVvar.SoluteCGall, HHvar.regionpara.Altituall);

        }

        /// <summary>
        /// 利用reduce方法整合所有rank的统计结果到rank0
        /// </summary>
        /// <param name="HHvar"></param>
        /// <param name="TVvar"></param>
        /// <param name="SVvar"></param>
        /// <param name="comm"></param>
        public static void resultallrank(HHMMvar HHvar, SHAWvar TVvar, SVCSvar SVvar, Intracommunicator comm)
        {
            SVvar.Totalrainall = comm.Reduce(SVvar.Totalrain, Operation<double>.Add, 0);
            TVvar.Totalsnowall = comm.Reduce(TVvar.Totalsnow, Operation<double>.Add, 0);
            TVvar.TotalDLWall = comm.Reduce(TVvar.TotalDLW, Operation<double>.Add, 0);
            SVvar.Totalwatervolumeall = comm.Reduce(SVvar.Totalwatervolume, Operation<double>.Add, 0);
            SVvar.Totalinfilall = comm.Reduce(SVvar.Totalinfil, Operation<double>.Add, 0);
            SVvar.Totalrechargeall = comm.Reduce(SVvar.Totalrecharge, Operation<double>.Add, 0);
            SVvar.Total_volume_outflowall = comm.Reduce(SVvar.Total_volume_outflow, Operation<double>.Add, 0);
            SVvar.Meanheightall = comm.Reduce(SVvar.Meanheight, Operation<double>.Add, 0);
            SVvar.Meanheightall /= comm.Size;
            TVvar.Totalinterflowall = comm.Reduce(TVvar.Totalinterflow, Operation<double>.Add, 0);
            TVvar.Totalsoilwatervolumeall = comm.Reduce(TVvar.Totalsoilwatervolume, Operation<double>.Add, 0);
            TVvar.Totalrockwatervolumeall = comm.Reduce(TVvar.Totalrockwatervolume, Operation<double>.Add, 0);
            TVvar.Totalbotall = comm.Reduce(TVvar.Totalbot, Operation<double>.Add, 0);
            TVvar.Totalsoileall = comm.Reduce(TVvar.Totalsoile, Operation<double>.Add, 0);
            TVvar.Totalcanopytall = comm.Reduce(TVvar.Totalcanopyt, Operation<double>.Add, 0);
            TVvar.Totalsoiliceall = comm.Reduce(TVvar.Totalsoilice, Operation<double>.Add, 0);
            for (int i = 0; i < HHvar.solutenum; i++)
            {
                TVvar.Totalsoilsoluteall[i] = comm.Reduce(TVvar.Totalsoilsolute[i], Operation<double>.Add, 0);
                TVvar.Solutebotall[i] = comm.Reduce(TVvar.Solutebot[i], Operation<double>.Add, 0);
                TVvar.Soluteinterall[i] = comm.Reduce(TVvar.Soluteinter[i], Operation<double>.Add, 0);
                TVvar.SoluteCGall[i] = comm.Reduce(TVvar.SoluteCG[i], Operation<double>.Add, 0);
            }
            HHvar.regionpara.Altituall = comm.Reduce(HHvar.regionpara.Altitu, Operation<double>.Add, 0);
            HHvar.regionpara.Altituall /= comm.Size;

        }

        /// <summary>
        /// 地下层溶质
        /// </summary>
        /// <param name="datapath"></param>
        /// <param name="HHvar"></param>
        /// <param name="TVvar"></param>
        public static void soilsolutevtkout(string datapath, HHMMvar HHvar, SHAWvar TVvar)
        {
            // int pointnum = (HHvar.NXCELL + 1) * (HHvar.NYCELL + 1) * (HHvar.NZCELL + 1);
            StreamWriter fvtk = new StreamWriter(System.IO.Path.Combine(datapath, "soilsolute" + Convert.ToString(1000 + HHvar.tn) + ".vtk"));
            fvtk.WriteLine("# vtk DataFile Version 2.0");
            fvtk.WriteLine("Unstructured Grid Example");
            fvtk.WriteLine("ASCII");
            fvtk.WriteLine("DATASET UNSTRUCTURED_GRID");
            fvtk.WriteLine("POINTS {0} float", HHvar.validpoint.Length);
            int pl;
            if (HHvar.validpoint.Length % 5 == 0)
            {
                pl = 5;
            }
            else if (HHvar.validpoint.Length % 4 == 0)
            {
                pl = 4;
            }
            else if (HHvar.validpoint.Length % 3 == 0)
            {
                pl = 3;
            }
            else if (HHvar.validpoint.Length % 2 == 0)
            {
                pl = 2;
            }
            else
            {
                pl = 1;
            }
            string content1 = "";
            for (int pointi = 0; pointi < HHvar.validpoint.Length; pointi++)
            {
                if ((pointi > 0) & ((pointi % pl) == 0))
                {
                    content1 = "";
                }
                content1 += string.Format("{0} ", HHvar.validpoint[pointi][0]);
                content1 += string.Format("{0} ", HHvar.validpoint[pointi][1]);
                content1 += string.Format("{0}     ", HHvar.validpoint[pointi][2]);
                if ((pointi % pl) == (pl - 1))
                {
                    fvtk.WriteLine("{0}", content1);
                }
            }

            fvtk.WriteLine("CELLS {0} {1}", HHvar.cuboidnum, HHvar.cuboidnum + 8 * HHvar.cuboidnum);
            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                string content = string.Format("{0} ", 8);
                for (int cci = 0; cci < 8; cci++)
                {
                    content += string.Format("{0} ", HHvar.cuboid[cuboidi][cci]);
                }
                fvtk.WriteLine("{0}", content);
            }
            fvtk.WriteLine("CELL_TYPES {0}", HHvar.cuboidnum);
            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                fvtk.WriteLine("11");
            }

            fvtk.WriteLine("CELL_DATA {0}", HHvar.cuboidnum);
            fvtk.WriteLine("SCALARS soilsolute float");
            fvtk.WriteLine("LOOKUP_TABLE soilsolute");

            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                fvtk.WriteLine("{0}", TVvar.solutephas.soilsolunew[0][cuboidi]);
            }
            fvtk.Flush();
            fvtk.Close();
        }

        /// <summary>
        /// 地下层温度
        /// </summary>
        /// <param name="datapath"></param>
        /// <param name="HHvar"></param>
        /// <param name="TVvar"></param>
        public static void soiltempervtkout(string datapath, HHMMvar HHvar, SHAWvar TVvar)
        {
            // int pointnum = (HHvar.NXCELL + 1) * (HHvar.NYCELL + 1) * (HHvar.NZCELL + 1);
            StreamWriter fvtk = new StreamWriter(System.IO.Path.Combine(datapath, "soiltemper" + Convert.ToString(1000 + HHvar.tn) + ".vtk"));
            fvtk.WriteLine("# vtk DataFile Version 2.0");
            fvtk.WriteLine("Unstructured Grid Example");
            fvtk.WriteLine("ASCII");
            fvtk.WriteLine("DATASET UNSTRUCTURED_GRID");
            fvtk.WriteLine("POINTS {0} float", HHvar.validpoint.Length);
            int pl;
            if (HHvar.validpoint.Length % 5 == 0)
            {
                pl = 5;
            }
            else if (HHvar.validpoint.Length % 4 == 0)
            {
                pl = 4;
            }
            else if (HHvar.validpoint.Length % 3 == 0)
            {
                pl = 3;
            }
            else if (HHvar.validpoint.Length % 2 == 0)
            {
                pl = 2;
            }
            else
            {
                pl = 1;
            }
            string content1 = "";
            for (int pointi = 0; pointi < HHvar.validpoint.Length; pointi++)
            {
                if ((pointi > 0) & ((pointi % pl) == 0))
                {
                    content1 = "";
                }
                content1 += string.Format("{0} ", HHvar.validpoint[pointi][0]);
                content1 += string.Format("{0} ", HHvar.validpoint[pointi][1]);
                content1 += string.Format("{0}     ", HHvar.validpoint[pointi][2]);
                if ((pointi % pl) == (pl - 1))
                {
                    fvtk.WriteLine("{0}", content1);
                }
            }

            fvtk.WriteLine("CELLS {0} {1}", HHvar.cuboidnum, HHvar.cuboidnum + 8 * HHvar.cuboidnum);
            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                string content = string.Format("{0} ", 8);
                for (int cci = 0; cci < 8; cci++)
                {
                    content += string.Format("{0} ", HHvar.cuboid[cuboidi][cci]);
                }
                fvtk.WriteLine("{0}", content);
            }
            fvtk.WriteLine("CELL_TYPES {0}", HHvar.cuboidnum);
            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                fvtk.WriteLine("11");
            }

            fvtk.WriteLine("CELL_DATA {0}", HHvar.cuboidnum);
            fvtk.WriteLine("SCALARS soiltemper float");
            fvtk.WriteLine("LOOKUP_TABLE soiltemper");

            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                fvtk.WriteLine("{0}", TVvar.heatphas.TS[cuboidi]);
            }
            fvtk.Flush();
            fvtk.Close();
        }

        /// <summary>
        /// 冻土
        /// </summary>
        /// <param name="datapath"></param>
        /// <param name="HHvar"></param>
        /// <param name="TVvar"></param>
        public static void soilicevtkout(string datapath, HHMMvar HHvar, SHAWvar TVvar)
        {
            // int pointnum = (HHvar.NXCELL + 1) * (HHvar.NYCELL + 1) * (HHvar.NZCELL + 1);
            StreamWriter fvtk = new StreamWriter(System.IO.Path.Combine(datapath, "soilice" + Convert.ToString(1000 + HHvar.tn) + ".vtk"));
            fvtk.WriteLine("# vtk DataFile Version 2.0");
            fvtk.WriteLine("Unstructured Grid Example");
            fvtk.WriteLine("ASCII");
            fvtk.WriteLine("DATASET UNSTRUCTURED_GRID");
            fvtk.WriteLine("POINTS {0} float", HHvar.validpoint.Length);
            int pl;
            if (HHvar.validpoint.Length % 5 == 0)
            {
                pl = 5;
            }
            else if (HHvar.validpoint.Length % 4 == 0)
            {
                pl = 4;
            }
            else if (HHvar.validpoint.Length % 3 == 0)
            {
                pl = 3;
            }
            else if (HHvar.validpoint.Length % 2 == 0)
            {
                pl = 2;
            }
            else
            {
                pl = 1;
            }
            string content1 = "";
            for (int pointi = 0; pointi < HHvar.validpoint.Length; pointi++)
            {
                if ((pointi > 0) & ((pointi % pl) == 0))
                {
                    content1 = "";
                }
                content1 += string.Format("{0} ", HHvar.validpoint[pointi][0]);
                content1 += string.Format("{0} ", HHvar.validpoint[pointi][1]);
                content1 += string.Format("{0}     ", HHvar.validpoint[pointi][2]);
                if ((pointi % pl) == (pl - 1))
                {
                    fvtk.WriteLine("{0}", content1);
                }
            }

            fvtk.WriteLine("CELLS {0} {1}", HHvar.cuboidnum, HHvar.cuboidnum + 8 * HHvar.cuboidnum);
            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                string content = string.Format("{0} ", 8);
                for (int cci = 0; cci < 8; cci++)
                {
                    content += string.Format("{0} ", HHvar.cuboid[cuboidi][cci]);
                }
                fvtk.WriteLine("{0}", content);
            }
            fvtk.WriteLine("CELL_TYPES {0}", HHvar.cuboidnum);
            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                fvtk.WriteLine("11");
            }

            fvtk.WriteLine("CELL_DATA {0}", HHvar.cuboidnum);
            fvtk.WriteLine("SCALARS soilice float");
            fvtk.WriteLine("LOOKUP_TABLE soilice");

            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                fvtk.WriteLine("{0}", TVvar.icephas.VIC[cuboidi]);
            }
            fvtk.Flush();
            fvtk.Close();
        }

        public static void soilparavtkout(string datapath, HHMMvar HHvar, SHAWvar TVvar)
        {
            // int pointnum = (HHvar.NXCELL + 1) * (HHvar.NYCELL + 1) * (HHvar.NZCELL + 1);
            StreamWriter fvtk = new StreamWriter(System.IO.Path.Combine(datapath, "soilpara" + ".vtk"));
            fvtk.WriteLine("# vtk DataFile Version 2.0");
            fvtk.WriteLine("Unstructured Grid Example");
            fvtk.WriteLine("ASCII");
            fvtk.WriteLine("DATASET UNSTRUCTURED_GRID");
            fvtk.WriteLine("POINTS {0} float", HHvar.validpoint.Length);
            int pl;
            if (HHvar.validpoint.Length % 5 == 0)
            {
                pl = 5;
            }
            else if (HHvar.validpoint.Length % 4 == 0)
            {
                pl = 4;
            }
            else if (HHvar.validpoint.Length % 3 == 0)
            {
                pl = 3;
            }
            else if (HHvar.validpoint.Length % 2 == 0)
            {
                pl = 2;
            }
            else
            {
                pl = 1;
            }
            string content1 = "";
            for (int pointi = 0; pointi < HHvar.validpoint.Length; pointi++)
            {
                if ((pointi > 0) & ((pointi % pl) == 0))
                {
                    content1 = "";
                }
                content1 += string.Format("{0} ", HHvar.validpoint[pointi][0]);
                content1 += string.Format("{0} ", HHvar.validpoint[pointi][1]);
                content1 += string.Format("{0}     ", HHvar.validpoint[pointi][2]);
                if ((pointi % pl) == (pl - 1))
                {
                    fvtk.WriteLine("{0}", content1);
                }

            }

            fvtk.WriteLine("CELLS {0} {1}", HHvar.cuboidnum, HHvar.cuboidnum + 8 * HHvar.cuboidnum);
            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                string content = string.Format("{0} ", 8);
                for (int cci = 0; cci < 8; cci++)
                {

                    content += string.Format("{0} ", HHvar.cuboid[cuboidi][cci]);

                }
                fvtk.WriteLine("{0}", content);
            }
            fvtk.WriteLine("CELL_TYPES {0}", HHvar.cuboidnum);
            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                fvtk.WriteLine("11");
            }

            fvtk.WriteLine("CELL_DATA {0}", HHvar.cuboidnum);
            fvtk.WriteLine("SCALARS soilwas float");
            fvtk.WriteLine("LOOKUP_TABLE soilwas");
            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                int ct = HHvar.cellsoiltype[cuboidi];
                fvtk.WriteLine("{0}", HHvar.soilwaterpara.soilwas[ct]);
            }

            fvtk.WriteLine("SCALARS soilwar float");
            fvtk.WriteLine("LOOKUP_TABLE soilwar");
            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                int ct = HHvar.cellsoiltype[cuboidi];
                fvtk.WriteLine("{0}", HHvar.soilwaterpara.soilwar[ct]);
            }
            fvtk.WriteLine("SCALARS soilKs float");
            fvtk.WriteLine("LOOKUP_TABLE soilKs");
            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                int ct = HHvar.cellsoiltype[cuboidi];
                fvtk.WriteLine("{0}", HHvar.soilwaterpara.Ks[ct]);
            }
            fvtk.Flush();
            fvtk.Close();
        }

        /// <summary>
        /// 地下层含水率
        /// </summary>
        /// <param name="datapath"></param>
        /// <param name="HHvar"></param>
        /// <param name="TVvar"></param>
        public static void soilwatervtkout(string datapath, HHMMvar HHvar, SHAWvar TVvar)
        {
            // int pointnum = (HHvar.NXCELL + 1) * (HHvar.NYCELL + 1) * (HHvar.NZCELL + 1);
            StreamWriter fvtk = new StreamWriter(System.IO.Path.Combine(datapath, "soilmoisture" + Convert.ToString(1000 + HHvar.tn) + ".vtk"));
            fvtk.WriteLine("# vtk DataFile Version 2.0");
            fvtk.WriteLine("Unstructured Grid Example");
            fvtk.WriteLine("ASCII");
            fvtk.WriteLine("DATASET UNSTRUCTURED_GRID");
            fvtk.WriteLine("POINTS {0} float", HHvar.validpoint.Length);
            int pl;
            if (HHvar.validpoint.Length % 5 == 0)
            {
                pl = 5;
            }
            else if (HHvar.validpoint.Length % 4 == 0)
            {
                pl = 4;
            }
            else if (HHvar.validpoint.Length % 3 == 0)
            {
                pl = 3;
            }
            else if (HHvar.validpoint.Length % 2 == 0)
            {
                pl = 2;
            }
            else
            {
                pl = 1;
            }
            string content1 = "";
            for (int pointi = 0; pointi < HHvar.validpoint.Length; pointi++)
            {
                if ((pointi > 0) & ((pointi % pl) == 0))
                {
                    content1 = "";
                }
                content1 += string.Format("{0} ", HHvar.validpoint[pointi][0]);
                content1 += string.Format("{0} ", HHvar.validpoint[pointi][1]);
                content1 += string.Format("{0}     ", HHvar.validpoint[pointi][2]);
                if ((pointi % pl) == (pl - 1))
                {
                    fvtk.WriteLine("{0}", content1);
                }
            }

            fvtk.WriteLine("CELLS {0} {1}", HHvar.cuboidnumself, HHvar.cuboidnumself + 8 * HHvar.cuboidnumself);
            for (int cuboidi = HHvar.startcell; cuboidi < HHvar.endcell; cuboidi++)
            {
                string content = string.Format("{0} ", 8);
                for (int cci = 0; cci < 8; cci++)
                {
                    content += string.Format("{0} ", HHvar.cuboid[cuboidi][cci]);
                }
                fvtk.WriteLine("{0}", content);
            }
            fvtk.WriteLine("CELL_TYPES {0}", HHvar.cuboidnumself);
            for (int cuboidi = HHvar.startcell; cuboidi < HHvar.endcell; cuboidi++)
            {
                fvtk.WriteLine("11");
            }

            fvtk.WriteLine("CELL_DATA {0}", HHvar.cuboidnumself);
            fvtk.WriteLine("SCALARS soilmoisture float");
            fvtk.WriteLine("LOOKUP_TABLE soilmoisture");

            for (int cuboidi = HHvar.startcell; cuboidi < HHvar.endcell; cuboidi++)
            {
                fvtk.WriteLine("{0}", TVvar.waterphas.VLC[cuboidi]);
            }
            fvtk.Flush();
            fvtk.Close();
        }

        /// <summary>
        /// 地下层水势
        /// </summary>
        /// <param name="datapath"></param>
        /// <param name="HHvar"></param>
        /// <param name="TVvar"></param>
        public static void soilhvtkout(string datapath, HHMMvar HHvar, SHAWvar TVvar)
        {
            // int pointnum = (HHvar.NXCELL + 1) * (HHvar.NYCELL + 1) * (HHvar.NZCELL + 1);
            StreamWriter fvtk = new StreamWriter(System.IO.Path.Combine(datapath, "soilh" + Convert.ToString(1000 + HHvar.tn) + ".vtk"));
            fvtk.WriteLine("# vtk DataFile Version 2.0");
            fvtk.WriteLine("Unstructured Grid Example");
            fvtk.WriteLine("ASCII");
            fvtk.WriteLine("DATASET UNSTRUCTURED_GRID");
            fvtk.WriteLine("POINTS {0} float", HHvar.validpoint.Length);
            int pl;
            if (HHvar.validpoint.Length % 5 == 0)
            {
                pl = 5;
            }
            else if (HHvar.validpoint.Length % 4 == 0)
            {
                pl = 4;
            }
            else if (HHvar.validpoint.Length % 3 == 0)
            {
                pl = 3;
            }
            else if (HHvar.validpoint.Length % 2 == 0)
            {
                pl = 2;
            }
            else
            {
                pl = 1;
            }
            string content1 = "";
            for (int pointi = 0; pointi < HHvar.validpoint.Length; pointi++)
            {
                if ((pointi > 0) & ((pointi % pl) == 0))
                {
                    content1 = "";
                }
                content1 += string.Format("{0} ", HHvar.validpoint[pointi][0]);
                content1 += string.Format("{0} ", HHvar.validpoint[pointi][1]);
                content1 += string.Format("{0}     ", HHvar.validpoint[pointi][2]);
                if ((pointi % pl) == (pl - 1))
                {
                    fvtk.WriteLine("{0}", content1);
                }
            }

            fvtk.WriteLine("CELLS {0} {1}", HHvar.cuboidnum, HHvar.cuboidnum + 8 * HHvar.cuboidnum);
            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                string content = string.Format("{0} ", 8);
                for (int cci = 0; cci < 8; cci++)
                {
                    content += string.Format("{0} ", HHvar.cuboid[cuboidi][cci]);
                }
                fvtk.WriteLine("{0}", content);
            }
            fvtk.WriteLine("CELL_TYPES {0}", HHvar.cuboidnum);
            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                fvtk.WriteLine("11");
            }

            fvtk.WriteLine("CELL_DATA {0}", HHvar.cuboidnum);
            fvtk.WriteLine("SCALARS soilh float");
            fvtk.WriteLine("LOOKUP_TABLE soilh");

            for (int cuboidi = 0; cuboidi < HHvar.cuboidnum; cuboidi++)
            {
                fvtk.WriteLine("{0}", TVvar.waterphas.MAT[cuboidi]);
            }
            fvtk.Flush();
            fvtk.Close();
        }
        /*
        public static void trianvktout(string datapath, HHMMvar HHvar)
        {
            StreamWriter fpoly = new StreamWriter(System.IO.Path.Combine(datapath, "gwwatertrian" + Convert.ToString(HHvar.calstep) + ".vtk"));
            fpoly.WriteLine("# vtk DataFile Version 4.1");
            fpoly.WriteLine("vtk output");
            fpoly.WriteLine("ASCII");
            fpoly.WriteLine("DATASET POLYDATA");
            fpoly.WriteLine("POINTS {0} float", HHvar.globalvd);
            int hl;
            if (HHvar.globalvd % 5 == 0)
            {
                hl = 5;
            }
            else if (HHvar.globalvd % 4 == 0)
            {
                hl = 4;
            }
            else if (HHvar.globalvd % 3 == 0)
            {
                hl = 3;
            }
            else if (HHvar.globalvd % 2 == 0)
            {
                hl = 2;
            }
            else
            {
                hl = 1;
            }
            string content0 = "";
            for (int gpi = 0; gpi < HHvar.globalvd; gpi++)
            {
                if ((gpi > 0) & ((gpi % hl) == 0))
                {
                    content0 = "";
                }
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][0]);
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][1]);
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][2] + HHvar.validwaterdepth[gpi]);
                if ((gpi % hl) == (hl - 1))
                {
                    fpoly.WriteLine("{0}", content0);
                }

            }
            fpoly.WriteLine();

            fpoly.WriteLine("POLYGONS {0} {1}", HHvar.tricor.GetLength(0), HHvar.tricor.GetLength(0) * 4);

            for (int tri = 0; tri < HHvar.tricor.GetLength(0); tri++)
            {
                string content = string.Format("{0} ", 3);
                for (int pci = 0; pci < 3; pci++)
                {

                    content += string.Format("{0} ", HHvar.tricor[tri][pci]);

                }
                fpoly.WriteLine("{0}", content);
            }

            fpoly.WriteLine("POINT_DATA {0}", HHvar.globalvd);
            fpoly.WriteLine("SCALARS waterheight float");
            fpoly.WriteLine("LOOKUP_TABLE waterheight");

            for (int gpi = 0; gpi < HHvar.globalvd; gpi++)
            {
                fpoly.WriteLine("{0}",HHvar.validwaterdepth[gpi]);
            }

            fpoly.Flush();
            fpoly.Close();
        }
       */
        public static void retanvktout(string datapath, HHMMvar HHvar)
        {
            StreamWriter fpoly = new StreamWriter(System.IO.Path.Combine(datapath, "gwwaterretan" + Convert.ToString(HHvar.calstep) + ".vtk"));
            fpoly.WriteLine("# vtk DataFile Version 4.1");
            fpoly.WriteLine("vtk output");
            fpoly.WriteLine("ASCII");
            fpoly.WriteLine("DATASET POLYDATA");
            fpoly.WriteLine("POINTS {0} float", HHvar.globalvd * 4);

            string content0 = "";
            for (int gpi = 0; gpi < HHvar.globalvd; gpi++)
            {
                content0 = "";

                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][0]);
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][1]);
                content0 += string.Format("{0}    ", HHvar.swtripoint[gpi][2] + HHvar.validwaterdepth[gpi]);

                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][0]);
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][1]);
                content0 += string.Format("{0}    ", HHvar.swtripoint[gpi][2] + HHvar.validwaterdepth[gpi]);

                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][0]);
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][1]);
                content0 += string.Format("{0}    ", HHvar.swtripoint[gpi][2] + HHvar.validwaterdepth[gpi]);

                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][0]);
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][1]);
                content0 += string.Format("{0}    ", HHvar.swtripoint[gpi][2] + HHvar.validwaterdepth[gpi]);

                fpoly.WriteLine("{0}", content0);
            }
            fpoly.WriteLine();

            fpoly.WriteLine("POLYGONS {0} {1}", HHvar.globalvd, HHvar.globalvd * 5);

            for (int polyi = 0; polyi < HHvar.globalvd; polyi++)
            {
                string content = string.Format("{0} ", 4);
                for (int pci = 0; pci < 4; pci++)
                {
                    content += string.Format("{0} ", polyi * 4 + pci);
                }
                fpoly.WriteLine("{0}", content);
            }

            fpoly.WriteLine("CELL_DATA {0}", HHvar.globalvd);
            fpoly.WriteLine("SCALARS waterheight float");
            fpoly.WriteLine("LOOKUP_TABLE waterheight");

            for (int gpi = 0; gpi < HHvar.globalvd; gpi++)
            {
                fpoly.WriteLine("{0}", HHvar.validwaterdepth[gpi]);
            }
            fpoly.Flush();
            fpoly.Close();
        }


        /// <summary>
        /// 地表积水深输出
        /// </summary>
        /// <param name="datapath"></param>
        /// <param name="HHvar"></param>
        public static void cubvtkout(string datapath, HHMMvar HHvar)
        {
            StreamWriter fvtk = new StreamWriter(System.IO.Path.Combine(datapath, "waterheight" + Convert.ToString(1000 + HHvar.tn) + ".vtk"));
            fvtk.WriteLine("# vtk DataFile Version 2.0");
            fvtk.WriteLine("Unstructured Grid Example");
            fvtk.WriteLine("ASCII");
            fvtk.WriteLine("DATASET UNSTRUCTURED_GRID");
            fvtk.WriteLine("POINTS {0} float", HHvar.globalvd * 8);
            string content0;
            for (int gpi = 0; gpi < HHvar.globalvd; gpi++)
            {
                content0 = "";
                double validwd = Math.Max(HHvar.validwaterdepth[gpi], 0.001);
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][0] - 0.5 * HHvar.DX);
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][1] - 0.5 * HHvar.DY);
                content0 += string.Format("{0}    ", HHvar.swtripoint[gpi][2]);

                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][0] + 0.5 * HHvar.DX);
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][1] - 0.5 * HHvar.DY);
                content0 += string.Format("{0}    ", HHvar.swtripoint[gpi][2]);

                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][0] - 0.5 * HHvar.DX);
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][1] + 0.5 * HHvar.DY);
                content0 += string.Format("{0}    ", HHvar.swtripoint[gpi][2]);

                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][0] + 0.5 * HHvar.DX);
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][1] + 0.5 * HHvar.DY);
                content0 += string.Format("{0}    ", HHvar.swtripoint[gpi][2]);

                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][0] - 0.5 * HHvar.DX);
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][1] - 0.5 * HHvar.DY);
                content0 += string.Format("{0}    ", HHvar.swtripoint[gpi][2] + validwd);

                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][0] + 0.5 * HHvar.DX);
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][1] - 0.5 * HHvar.DY);
                content0 += string.Format("{0}    ", HHvar.swtripoint[gpi][2] + validwd);

                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][0] - 0.5 * HHvar.DX);
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][1] + 0.5 * HHvar.DY);
                content0 += string.Format("{0}    ", HHvar.swtripoint[gpi][2] + validwd);

                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][0] + 0.5 * HHvar.DX);
                content0 += string.Format("{0} ", HHvar.swtripoint[gpi][1] + 0.5 * HHvar.DY);
                content0 += string.Format("{0}    ", HHvar.swtripoint[gpi][2] + validwd);
                fvtk.WriteLine("{0}", content0);
            }

            fvtk.WriteLine("CELLS {0} {1}", HHvar.globalvdself, HHvar.globalvdself + 8 * HHvar.globalvdself);
            for (int cuboidi = HHvar.startgrid; cuboidi < HHvar.endgrid; cuboidi++)
            {
                string content = string.Format("{0} ", 8);
                for (int cci = 0; cci < 8; cci++)
                {

                    content += string.Format("{0} ", cuboidi * 8 + cci);

                }
                fvtk.WriteLine("{0}", content);
            }

            fvtk.WriteLine("CELL_TYPES {0}", HHvar.globalvdself);
            for (int cuboidi = HHvar.startgrid; cuboidi < HHvar.endgrid; cuboidi++)
            {
                fvtk.WriteLine("11");
            }

            fvtk.WriteLine("CELL_DATA {0}", HHvar.globalvdself);
            fvtk.WriteLine("SCALARS waterheight float");
            fvtk.WriteLine("LOOKUP_TABLE waterheight");

            for (int cuboidi = HHvar.startgrid; cuboidi < HHvar.endgrid; cuboidi++)
            {
                fvtk.WriteLine("{0}", HHvar.validwaterdepth[cuboidi]);
            }
            fvtk.Flush();
            fvtk.Close();
        }

        #endregion
        /// <summary>
        /// 定义空间点的坐标
        /// </summary>
        /// <param name="NXCELL"></param>
        /// <param name="NYCELL"></param>
        /// <param name="NZCELL"></param>
        /// <param name="DX"></param>
        /// <param name="DY"></param>
        /// <param name="DZ"></param>
        /// <param name="Novalue"></param>
        /// <param name="xleft"></param>
        /// <param name="ytop"></param>
        /// <param name="ztop"></param>
        /// <param name="cuboidnum"></param>
        /// <param name="upfaceid"></param>
        /// <param name="downfaceid"></param>
        /// <param name="cuboidtrue"></param>
        /// <param name="validpoint"></param>
        public static void cubicdefine(int NXCELL, int NYCELL, int NZCELL, double DX, double DY, double DZ, double Novalue, double xleft, double ytop, double ztop, int cuboidnum, int[][] upfaceid, int[][] downfaceid, out int[][] cuboidtrue, out double[][] validpoint)
        {//考虑可能的二维数据提取因此对函数进行细化
            int pointnum = (NXCELL + 1) * (NYCELL + 1) * (NZCELL + 1);
            //确定点的坐标，六面体对应的节点编码
            int[] pointtrue = new int[pointnum];
            double[][] point = new double[pointnum][];  //点的坐标
            for (int npi = 0; npi < pointnum; npi++)
            {
                point[npi] = new double[3];   //点的三维坐标
                pointtrue[npi] = -9999;
            }
            int[][] cuboid = new int[cuboidnum][];  //有效六面体对应的8个节点
            for (int nci = 0; nci < cuboidnum; nci++)
            {
                cuboid[nci] = new int[8];
            }

            //点坐标,基础三维数据点坐标，全部值
            for (int pxi = 0; pxi <= NXCELL; pxi++)
            {
                for (int pyi = 0; pyi <= NYCELL; pyi++)
                {
                    for (int pzi = 0; pzi <= NZCELL; pzi++)
                    {
                        int pointi = pxi * (NYCELL + 1) * (NZCELL + 1) + pyi * (NZCELL + 1) + pzi;//第几个点
                        point[pointi][0] = xleft + pxi * DX;
                        point[pointi][1] = ytop - pyi * DY;
                        point[pointi][2] = ztop - pzi * DZ;
                    }
                }
            }
            //cuboid位置
            int cuboidi = 0;
            int validpointnum = 0;
            for (int cxi = 0; cxi < NXCELL; cxi++)
            {
                for (int cyi = 0; cyi < NYCELL; cyi++)
                {
                    if (upfaceid[cxi][cyi] >= 0)
                    {
                        for (int czi = upfaceid[cxi][cyi]; czi <= downfaceid[cxi][cyi]; czi++)
                        {
                            int starpointi = cxi * (NYCELL + 1) * (NZCELL + 1) + cyi * (NZCELL + 1) + czi;//第几个点
                            cuboid[cuboidi][0] = starpointi + 1 + (NZCELL + 1);
                            cuboid[cuboidi][1] = starpointi + 1 + (NYCELL + 1) * (NZCELL + 1) + (NZCELL + 1);
                            cuboid[cuboidi][2] = starpointi + 1;
                            cuboid[cuboidi][3] = starpointi + 1 + (NYCELL + 1) * (NZCELL + 1);

                            cuboid[cuboidi][4] = starpointi + (NZCELL + 1);
                            cuboid[cuboidi][5] = starpointi + (NYCELL + 1) * (NZCELL + 1) + (NZCELL + 1);
                            cuboid[cuboidi][6] = starpointi;
                            cuboid[cuboidi][7] = starpointi + (NYCELL + 1) * (NZCELL + 1);          //六面体八个点标出   
                            for (int pi = 0; pi < 8; pi++)
                            {
                                if (pointtrue[cuboid[cuboidi][pi]] <= 0)
                                {
                                    pointtrue[cuboid[cuboidi][pi]] = 1;          //判断某个点是否被用到
                                    validpointnum += 1;
                                }
                            }
                            cuboidi += 1;
                        }
                    }

                }
            }

            Dictionary<int, int> pointlist = new Dictionary<int, int>();   //创建一个字典，建立所有点的顺序和实际用到点顺序的对应码
            Dictionary<int, int> pointorder = new Dictionary<int, int>();   //创建一个字典，建立所有点的顺序和实际用到点顺序的对应码
            int validpointi = 0;
            for (int pi = 0; pi < pointnum; pi++)
            {
                if (pointtrue[pi] > 0)
                {
                    pointlist.Add(validpointi, pi);
                    pointorder.Add(pi, validpointi);
                    validpointi += 1;
                }
            }
            validpoint = new double[validpointnum][];  //点的坐标

            for (int npi = 0; npi < validpointnum; npi++)  //将有效点坐标，按照顺序输出
            {
                validpoint[npi] = new double[3];   //点的三维坐标
                for (int cori = 0; cori < 3; cori++)
                {
                    validpoint[npi][cori] = point[pointlist[npi]][cori];
                }
            }
            cuboidtrue = new int[cuboidnum][];
            for (int nci = 0; nci < cuboidnum; nci++)   //将有效长方体坐标，输出对应的数据点
            {
                cuboidtrue[nci] = new int[8];
                for (int ndir = 0; ndir < 8; ndir++)
                {
                    cuboidtrue[nci][ndir] = pointorder[cuboid[nci][ndir]];
                }
            }
        }
        /// <summary>
        /// 定义平面点的坐标
        /// </summary>
        /// <param name="NXCELL"></param>
        /// <param name="NYCELL"></param>
        /// <param name="DX"></param>
        /// <param name="DY"></param>
        /// <param name="DZ"></param>
        /// <param name="Novalue"></param>
        /// <param name="xleft"></param>
        /// <param name="ytop"></param>
        /// <param name="ztop"></param>
        /// <param name="globalvd"></param>
        /// <param name="Upfaceid"></param>
        /// <param name="Tdemvalue"></param>
        /// <param name="gwpoint"></param>
        public static void platedefine(int NXCELL, int NYCELL, double DX, double DY, double DZ, double Novalue, double xleft, double ytop, double ztop, int globalvd, int[][] Upfaceid, double[][] Tdemvalue, out double[][] gwpoint)
        {
            //globalvd,有效平面网格数目
            gwpoint = new double[globalvd][];
            int gwpointi = 0;
            for (int gwpxi = 0; gwpxi < NXCELL; gwpxi++)
            {
                for (int gwpyi = 0; gwpyi < NYCELL; gwpyi++)
                {
                    if (Upfaceid[gwpxi][gwpyi] >= Novalue + 10)
                    {
                        gwpoint[gwpointi] = new double[3];
                        gwpoint[gwpointi][0] = xleft + 0.5 * DX + gwpxi * DX;
                        gwpoint[gwpointi][1] = ytop - 0.5 * DY - gwpyi * DY;
                        gwpoint[gwpointi][2] = ztop - Upfaceid[gwpxi][gwpyi] * DZ;
                        gwpointi += 1;
                    }
                }
            }
        }


        /// <summary>
        /// 输出三角形的
        /// </summary>
        /// <param name="datapath"></param>
        /// <param name="STNX"></param>
        /// <param name="STNY"></param>
        /// <param name="NXCELL"></param>
        /// <param name="NYCELL"></param>
        /// <param name="DX"></param>
        /// <param name="DY"></param>
        /// <param name="xleft"></param>
        /// <param name="ytop"></param>
        /// <param name="Novalue"></param>
        /// <param name="Upfaceid"></param>
        /// <param name="globalvd"></param>
        /// <param name="gwpoint"></param>
        /// <param name="tricor"></param>
        public static void triplatedefine(string datapath, int STNX, int STNY, int NXCELL, int NYCELL, double DX, double DY, double Novalue, double xleft, double ytop, int globalvd, int[][] Upfaceid, out double[][] gwpoint, out int[][] tricor)
        {
            //globalvd,有效平面网格数目
            gwpoint = new double[NXCELL * NYCELL][];
            char[] spi = new char[] { ' ', ',', '\t' };
            int gwpointi = 0;
            for (int gwpxi = STNX; gwpxi < STNX + NXCELL; gwpxi++)
            {
                for (int gwpyi = STNY; gwpyi < STNY + NYCELL; gwpyi++)
                {
                    if (Upfaceid[gwpxi][gwpyi] >= Novalue + 10)
                    {
                        gwpoint[gwpointi] = new double[3];
                        gwpoint[gwpointi][0] = xleft + 0.5 * DX + gwpxi * DX;
                        gwpoint[gwpointi][1] = ytop - 0.5 * DY - gwpyi * DY;
                        gwpointi += 1;
                    }
                }
            }
            //确定地下水位位置
            StreamWriter fnode = new StreamWriter(System.IO.Path.Combine(datapath, "waterheight.node"));
            fnode.WriteLine("# test.node");
            fnode.WriteLine("#");
            fnode.WriteLine("# A set of fifteen points in 2D, no attributes, no boundary markers.");
            fnode.WriteLine("{0} 2 0 0", globalvd);
            fnode.WriteLine("# And here are the fifteen points.");

            for (int gpi = 0; gpi < globalvd; gpi++)
            {
                string content = string.Format("{0} ", gpi + 1);
                for (int pci = 0; pci < 2; pci++)
                {
                    content += string.Format("{0} ", gwpoint[gpi][pci]);
                }
                fnode.WriteLine("{0}", content);
            }
            fnode.Flush();
            fnode.Close();

            string exeFile = System.IO.Path.Combine(datapath, "triangle");
            string inputpar = System.IO.Path.Combine(datapath, "waterheight");

            using (Process process = new System.Diagnostics.Process())
            {
                process.StartInfo.FileName = exeFile;
                process.StartInfo.CreateNoWindow = true;
                process.StartInfo.Arguments = inputpar;
                process.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                process.Start();
                process.WaitForExit();
            }
            string topofile = (inputpar + ".1.ele");
            StreamReader basinattf = File.OpenText(topofile);
            String topos = basinattf.ReadLine();
            int trinum = Convert.ToInt32(topos.Split(spi, StringSplitOptions.RemoveEmptyEntries)[0]);
            tricor = new int[trinum][];
            for (int tri = 0; tri < trinum; tri++)
            {
                tricor[tri] = new int[3];
                topos = basinattf.ReadLine();
                for (int trii = 0; trii < 3; trii++)
                {
                    tricor[tri][trii] = Convert.ToInt32(topos.Split(spi, StringSplitOptions.RemoveEmptyEntries)[trii + 1]) - 1;
                }
            }
        }

        public static void rectplatedefine(int NXCELL, int NYCELL, double DX, double DY, double Novalue, double xleft, double ytop, int globalvd, int[][] Upfaceid, out double[][] gwpolypoint, out int[][] gwpoly)
        {
            gwpolypoint = new double[globalvd * 4][];
            gwpoly = new int[globalvd][];
            for (int gpi = 0; gpi < globalvd * 4; gpi++)
            {
                gwpolypoint[gpi] = new double[3];
            }
            for (int gpi = 0; gpi < globalvd; gpi++)
            {
                gwpoly[gpi] = new int[4];
            }

            int gwpolyi = 0;
            for (int gwpxi = 0; gwpxi < NXCELL; gwpxi++)
            {
                for (int gwpyi = 0; gwpyi < NYCELL; gwpyi++)
                {
                    if (Upfaceid[gwpxi][gwpyi] >= Novalue + 10)
                    {
                        gwpolypoint[gwpolyi * 4 + 0][0] = xleft + gwpxi * DX;
                        gwpolypoint[gwpolyi * 4 + 0][1] = ytop - (gwpyi + 1) * DY;

                        gwpolypoint[gwpolyi * 4 + 1][0] = xleft + (gwpxi + 1) * DX;
                        gwpolypoint[gwpolyi * 4 + 1][1] = ytop - (gwpyi + 1) * DY;

                        gwpolypoint[gwpolyi * 4 + 2][0] = xleft + (gwpxi + 1) * DX;
                        gwpolypoint[gwpolyi * 4 + 2][1] = ytop - gwpyi * DY;

                        gwpolypoint[gwpolyi * 4 + 3][0] = xleft + gwpxi * DX;
                        gwpolypoint[gwpolyi * 4 + 3][1] = ytop - gwpyi * DY;

                        gwpoly[gwpolyi][0] = gwpolyi * 4 + 0;
                        gwpoly[gwpolyi][1] = gwpolyi * 4 + 1;
                        gwpoly[gwpolyi][2] = gwpolyi * 4 + 2;
                        gwpoly[gwpolyi][3] = gwpolyi * 4 + 3;
                        gwpolyi += 1;
                    }
                }
            }
        }



        public static void rfopen(string filedir, int solutenum, out StreamWriter resultfile)
        {
            if (!System.IO.Directory.Exists(filedir)) System.IO.Directory.CreateDirectory(filedir);//如果不存在输出文件夹，创建文件夹
            resultfile = new StreamWriter(System.IO.Path.Combine(filedir, "hydraulicresult.txt"));
            string content0 = "totalrain" + "\t" + "totalsnow" + "\t" + "totalDLW" + "\t" + "surfacewatervolume" + "\t" + "totalinfil" + "\t" + "recharge" + "\t" + "outflow" + "\t" + "meanheith" + "\t" + "interflowvolume" + "\t" + "soilwatervolume" + "\t" + "rockwatervolume" + "\t" + "botvolume" + "\t" + "evaporation" + "\t" + "canopyT" + "\t" + "soilice" + "\t";
            for (int i = 0; i < solutenum; i++)
            {
                content0 += "solisolute" + i + 1 + "\t";
                content0 += "botsolute" + i + 1 + "\t";
                content0 += "intersolute" + i + 1 + "\t";
                content0 += "CGsolute" + i + 1 + "\t";
            }

            content0 += "altitu" + "\t";
            resultfile.WriteLine(content0);
        }

        /// <summary>
        /// 总量输出
        /// </summary>
        /// <param name="resultfile"></param>
        /// <param name="totalrain"></param>
        /// <param name="totalsnow"></param>
        /// <param name="totalDLW"></param>
        /// <param name="surfacewatervolume"></param>
        /// <param name="totalinfil"></param>
        /// <param name="totalrecharge"></param>
        /// <param name="outflow"></param>
        /// <param name="meanheith"></param>
        /// <param name="interflow"></param>
        /// <param name="soilwatervolume"></param>
        /// <param name="rockwatervolume"></param>
        /// <param name="totalbot"></param>
        /// <param name="soile"></param>
        /// <param name="canopyt"></param>
        /// <param name="soileice"></param>
        /// <param name="soilsolute"></param>
        /// <param name="solutebot"></param>
        /// <param name="soluteinter"></param>
        /// <param name="soluteCG"></param>
        /// <param name="Altitu"></param>
        public static void rfwrite(StreamWriter resultfile, double totalrain, double totalsnow, double totalDLW, double surfacewatervolume, double totalinfil, double totalrecharge, double outflow, double meanheith, double interflow, double soilwatervolume, double rockwatervolume, double totalbot, double soile, double canopyt, double soileice, double[] soilsolute, double[] solutebot, double[] soluteinter, double[] soluteCG, double Altitu)
        {
            string content0 = "";
            content0 += string.Format("{0:f6}\t", totalrain);
            content0 += string.Format("{0:f6}\t", totalsnow);
            content0 += string.Format("{0:f6}\t", totalDLW);
            content0 += string.Format("{0:f6}\t", surfacewatervolume);
            content0 += string.Format("{0:f6}\t", totalinfil);
            content0 += string.Format("{0:f6}\t", totalrecharge);
            content0 += string.Format("{0:f6}\t", outflow);
            content0 += string.Format("{0:f6}\t", meanheith);
            content0 += string.Format("{0:f6}\t", interflow);
            content0 += string.Format("{0:f6}\t", soilwatervolume);
            content0 += string.Format("{0:f6}\t", rockwatervolume);
            content0 += string.Format("{0:f6}\t", totalbot);
            content0 += string.Format("{0:f6}\t", soile);
            content0 += string.Format("{0:f6}\t", canopyt);
            content0 += string.Format("{0:f6}\t", soileice);

            for (int i = 0; i < soilsolute.Length; i++)
            {
                content0 += string.Format("{0:f6}\t", soilsolute[i]);
                content0 += string.Format("{0:f6}\t", solutebot[i]);
                content0 += string.Format("{0:f6}\t", soluteinter[i]);
                content0 += string.Format("{0:f6}\t", soluteCG[i]);
            }

            content0 += string.Format("{0:f6}\t", Altitu);
            resultfile.WriteLine("{0}", content0);

        }
        public static void rfclose(StreamWriter resultfile)
        {
            resultfile.Flush();
            resultfile.Close();
        }

    }

}
