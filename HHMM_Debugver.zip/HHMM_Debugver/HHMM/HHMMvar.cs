﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
namespace HHMM
{
    public class HHMMvar
    {
        public int EnvPro = Environment.ProcessorCount;
        public int SFM, IFM, SPM, SEM, FSM, SSEM, SSFM, SSSM;//控制模块开关，分别为 地表水、入渗、雪、地表能量、冻土、地下层能量、地下层水流、地下层溶质

        public static char[] spi = new char[] { ' ', ',', '\t' };
        public int SVCSon = 0;
        public int calstep = 0; //输出步长
        public int tn = 0;   //总的循环
        public int NX, NY;
        public double Novalue;
        public int NXCELL, NYCELL, NZCELL;
        public int NXzoom, NYzoom;
        public double DX, DY, DZ;
        public double xleft, ytop, ztop, cellsize;
        public int rocknum;//从这一编号开始是基岩层（起始值按1计算，也就是输入文件中soiltype的起始值）

        /// <summary>
        /// 时空结构
        /// </summary>
        public DateTime Dtstart; //模型开始计算时间；
        public DateTime Dtend;   //模型结束计算时间；
        public int Dtdays;  //模型模拟天数
        public double Tcal, Dtcal, Dtout;  //Tcal,计算总的历史天；Dtcal;Dtout,输出步长
        public int innernum;  //二维水动力和入渗计算最大分段数，一般以小时的秒数为准
        public int cuboidnum, globalvd;//有效网格数，有效平面网格  
        public int soiltypenum, solutenum; //土壤类，溶质类；
        public double soilthickmax;  //土壤最大厚度
        public double Demmin, Demmax;
        public int[][][] cellord; //三维网格在一维中的编号
        public double[][] Tdemvalue;
        public int[][] landuseindex; //每个网格的土地利用类型；
        public int[][] upfaceid, downfaceid, conupfaceid; //DEM在一维网格上的上边，下面，及其在三维一维化中的排序
        public int[] cellsoiltype; //每个网格的土壤类型,
        public int[][] soiltype;  //每种土壤的不同层土壤类型编号
        public double[][] soildepth; //每种土壤的不同层土壤厚度
        public double[][] validpoint; //空间点的坐标
        public int[][] cuboid;  // 立方体的点组成
        public double[][] swtripoint;//平面点的坐标 
                                     //  public int[][] tricor;     //三角平面的点组成        
        public double[] validwaterdepth; //有效水深 
        public StreamWriter resultfile;//集综文件输出
        public StreamReader weafile;
        public StreamWriter resultfileall;//并行整合文件输出


        public string[] weadatalist; //所有气象产品
        public int startcell, endcell;//自身需要计算的起止单元编号（endcell-1才是最后一个网格的编号）
        public int startcol, endcol;//自身需要计算的起止列，即起止X坐标
        public int colnum;//自身列数
        public int cuboidnumself, globalvdself;//自身的有效网格数和有效平面网格
        public int startgrid, endgrid;//自身需要计算的起止平面网格编号（endgrid-1才是最后一个网格的编号）

        public int stepphour, calpout;


        public double[][][] soiltosurface;//从地下渗流到地表的水230511 (左后前右)
        public double[][][] soiltosurfaceDT;

        public struct Sitepara
        {
            public double Latitude;  //当地纬度
            public double Elevation; //当地海拔
            public double Hrnoon;    //正午时刻
            public double Vegheight; //植被高度
            public double Insheight; //仪器安装高度
            public double ZMCM;      //风速粗糙参数
            public double ZMSPCM;      //积雪粗糙参数
            public double HEIGHT;     //气象测量位置高度
            public double SNOTMP;     //出现雪的温度
            public double Altitu;    //太阳高度角
            public double Altituall;    //太阳高度角.并行整合
            public double RAIN;//降雨单位：m/h
            public double Precipitation;//降雨单位：m/h
        }
        public Sitepara regionpara;

        public struct cellsoilwaterpara
        { //土壤水力参数
            public double[] soilwas;
            public double[] soilwar;
            public double[] l;
            public double[] m;
            public double[] n;
            public double[] ha;
            public double[] Ks;
            public double[] Ks9;
            public double[] avg;
            public double[] swinit;
        }
        public cellsoilwaterpara soilwaterpara;

        public struct cellsoilheatpara
        {//土壤热参数
            public double[] sand;
            public double[] silt;
            public double[] clay;
            public double[] orgran;
            public double[] minedensity;//干土密度
            public double[] ksmine;//矿物质热传导
            public double[] csmine;//矿物质热容量
            public double[] stinit;   //土壤初始温度         
            public double[] ALBDRY;   //干土的地表反射率
            public double[] ALBEXP;    //湿土的地表反射率
        }
        public cellsoilheatpara soilheatpara;

        public struct cellsoilsolutepara
        {//土壤溶质参数
            public double[][] kcq;
            public double[][] dh;
            public double[][] dm;
            public double[][] dhra; //溶质弥散扩散的垂向和横向比，一般垂向是横向的100倍左右
            public double[][] soinit;
        }
        public cellsoilsolutepara soilsolutepara;

        public struct Weather
        {
            public double temper;
            public double wind;
            public double hum;
            public double rain;  //降水
            public double radi;
            public double lai;
        }
        public Weather[] weadata;

        public HHMMvar(string datapath)
        {
            HHMMpar(datapath);
        }
        public void HHMMpar(string datapath)
        {
            string parafile = System.IO.Path.Combine(datapath, "HHpar.txt");
            string[] st = null;
            st = File.ReadAllLines(parafile);            
            DX = Convert.ToDouble(st[0].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]); //空间步长
            DY = Convert.ToDouble(st[1].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            DZ = Convert.ToDouble(st[2].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);            
            Dtcal = Convert.ToDouble(st[3].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);  //坡面汇流和土壤水分交互步长
            innernum = Convert.ToInt32(st[4].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);//计算输出步长内，坡面流和入渗交互次数
            int dtstyear, dtstmonth, dtstday;
            dtstyear = Convert.ToInt32(st[5].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            dtstmonth = Convert.ToInt32(st[5].Split(spi, StringSplitOptions.RemoveEmptyEntries)[2]);
            dtstday = Convert.ToInt32(st[5].Split(spi, StringSplitOptions.RemoveEmptyEntries)[3]);
            Dtstart = new DateTime(dtstyear, dtstmonth, dtstday);
            int dtenyear, dtenmonth, dtenday;
            dtenyear = Convert.ToInt32(st[6].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            dtenmonth = Convert.ToInt32(st[6].Split(spi, StringSplitOptions.RemoveEmptyEntries)[2]);
            dtenday = Convert.ToInt32(st[6].Split(spi, StringSplitOptions.RemoveEmptyEntries)[3]);
            Dtend = new DateTime(dtenyear, dtenmonth, dtenday);
            Dtdays = (Dtend - Dtstart).Days + 1;
            rocknum = Convert.ToInt32(st[7].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            Dtout = Convert.ToDouble(st[8].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            
            SFM = Convert.ToInt32(st[9].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            IFM = Convert.ToInt32(st[10].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            SPM = Convert.ToInt32(st[11].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            SEM = Convert.ToInt32(st[12].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            FSM = Convert.ToInt32(st[13].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            SSEM = Convert.ToInt32(st[14].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            SSFM = Convert.ToInt32(st[15].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            SSSM = Convert.ToInt32(st[16].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);

            string Sitefile = System.IO.Path.Combine(datapath, "Studysite.txt");
            string[] siteinfo = null;
            siteinfo = File.ReadAllLines(Sitefile);
            regionpara.Latitude = Convert.ToDouble(siteinfo[0].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]) * Math.PI / 180.0; //空间步长
            regionpara.Elevation = Convert.ToDouble(siteinfo[1].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            regionpara.Hrnoon = Convert.ToDouble(siteinfo[2].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            regionpara.Vegheight = Convert.ToDouble(siteinfo[3].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            regionpara.Insheight = Convert.ToDouble(siteinfo[4].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            regionpara.ZMCM = Convert.ToDouble(siteinfo[5].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);
            regionpara.ZMSPCM = Convert.ToDouble(siteinfo[6].Split(spi, StringSplitOptions.RemoveEmptyEntries)[1]);//
            string weatherfile = System.IO.Path.Combine(datapath, "weather.txt");
            weafile = new StreamReader(weatherfile);
            string wealine = weafile.ReadLine();
            stepphour = (int)(HHMMconst.SecondPerHour / Dtcal);
            calpout = (int)(Dtout / Dtcal);//每次输出时模型计算的次数
        }
    }
}