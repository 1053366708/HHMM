﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using MPI;


namespace HHMM
{
    public class HHMMtool
    {
        public static char[] spi = new char[] { ' ', ',', '\t' };

        /// <summary>
        /// 统计每天的气象数据
        /// </summary>
        /// <param name="weatherfile"></param>
        /// <param name="weadata"></param>
        /// <returns></returns>
        public static double weatherred(StreamReader weatherfile, ref HHMMvar.Weather[] weadata)
        {
            string[] weastr;
            double radiation = 0.0;
            for (int hi = 0; hi < 24; hi++)
            {
                string wealine = weatherfile.ReadLine();
                weastr = wealine.Split(spi, StringSplitOptions.RemoveEmptyEntries);
                weadata[hi].temper = Convert.ToDouble(weastr[4]);
                weadata[hi].wind = Convert.ToDouble(weastr[5]);
                weadata[hi].hum = Convert.ToDouble(weastr[6]) / 100.0;
                weadata[hi].rain = Convert.ToDouble(weastr[7]);
                weadata[hi].radi = Math.Max(0, Convert.ToDouble(weastr[8]));
                weadata[hi].lai = Convert.ToDouble(weastr[9]);
                radiation += weadata[hi].radi;
            }
            return radiation / 24.0;
        }


        /// <summary>
        /// 一维数据交互
        /// </summary>
        /// <param name="comm"></param>
        /// <param name="data1D"></param>
        /// <param name="conupfaceid"></param>
        /// <param name="NX"></param>
        /// <param name="cuboidnum"></param>
        /// <param name="downfaceid"></param>
        /// <param name="upfaceid"></param>
        /// <param name="NY"></param>
        public static void Sendreceive1D(Intracommunicator comm, ref double[] data1D, int[][] conupfaceid, int NX, int cuboidnum, int[][] downfaceid, int[][] upfaceid, int NY)
        {
            if (comm.Size > 1)
            {
                if (comm.Rank == 0)//第一块右边交互
                {
                    int sendlenth = conupfaceid[NX - 1][0] - conupfaceid[NX - 2][0];//发送数据的长度
                    int receivelenth = cuboidnum - conupfaceid[NX - 1][0];//接收数据的长度
                    double[] senddata = new double[sendlenth];//发送的数据
                    double[] receivedata = new double[receivelenth];//接收的数据
                    senddata = data1D.Skip(conupfaceid[NX - 2][0]).Take(sendlenth).ToArray();//提取发送的数据
                    comm.Send(senddata, 1, 0);//发送数据
                    comm.Receive(1, 0, ref receivedata);//接收数据

                    for (int i = conupfaceid[NX - 1][0]; i < cuboidnum; i++)
                    {
                        data1D[i] = receivedata[i - conupfaceid[NX - 1][0]];//更新接收的数据
                    }

                }
                else if (comm.Rank == comm.Size - 1)//最后一块左边交互
                {
                    int laynum = downfaceid[1][NY - 1] - upfaceid[1][NY - 1] + 1;
                    int sendlenth = conupfaceid[1][NY - 1] - conupfaceid[1][0] + laynum;//发送数据的长度
                    int receivelenth = conupfaceid[1][0];//接收数据的长度
                    double[] senddata = new double[sendlenth];//发送的数据
                    double[] receivedata = new double[receivelenth];//接收的数据
                    senddata = data1D.Skip(conupfaceid[1][0]).Take(sendlenth).ToArray();//提取发送的数据
                    comm.Send(senddata, comm.Rank - 1, 0);//发送数据
                    comm.Receive(comm.Rank - 1, 0, ref receivedata);//接收数据

                    for (int i = 0; i < conupfaceid[1][0]; i++)
                    {
                        data1D[i] = receivedata[i];//更新接收的数据
                    }
                }
                else//中间块两边交互
                {
                    //右边交互
                    int sendlenth1 = conupfaceid[NX - 1][0] - conupfaceid[NX - 2][0];//发送数据的长度
                    int receivelenth1 = cuboidnum - conupfaceid[NX - 1][0];//接收数据的长度
                    double[] senddata1 = new double[sendlenth1];//发送的数据
                    double[] receivedata1 = new double[receivelenth1];//接收的数据
                    senddata1 = data1D.Skip(conupfaceid[NX - 2][0]).Take(sendlenth1).ToArray();//提取发送的数据
                    comm.Send(senddata1, comm.Rank + 1, 0);//发送数据
                    comm.Receive(comm.Rank + 1, 0, ref receivedata1);//接收数据

                    for (int i = conupfaceid[NX - 1][0]; i < cuboidnum; i++)
                    {
                        data1D[i] = receivedata1[i - conupfaceid[NX - 1][0]];//更新接收的数据
                    }

                    //左边交互
                    int sendlenth2 = conupfaceid[2][0] - conupfaceid[1][0];//发送数据的长度
                    int receivelenth2 = conupfaceid[1][0];//接收数据的长度
                    double[] senddata2 = new double[sendlenth2];//发送的数据
                    double[] receivedata2 = new double[receivelenth2];//接收的数据
                    senddata2 = data1D.Skip(conupfaceid[1][0]).Take(sendlenth2).ToArray();//提取发送的数据
                    comm.Send(senddata2, comm.Rank - 1, 0);//发送数据
                    comm.Receive(comm.Rank - 1, 0, ref receivedata2);//接收数据

                    for (int i = 0; i < conupfaceid[1][0]; i++)
                    {
                        data1D[i] = receivedata2[i];//更新接收的数据
                    }

                }
            }

        }

        /// <summary>
        /// 一维整形数据交互
        /// </summary>
        /// <param name="comm"></param>
        /// <param name="data1D"></param>
        /// <param name="conupfaceid"></param>
        /// <param name="NX"></param>
        /// <param name="cuboidnum"></param>
        /// <param name="downfaceid"></param>
        /// <param name="upfaceid"></param>
        /// <param name="NY"></param>
        public static void Sendreceive1Dint(Intracommunicator comm, ref int[] data1D, int[][] conupfaceid, int NX, int cuboidnum, int[][] downfaceid, int[][] upfaceid, int NY)
        {
            if (comm.Size > 1)
            {
                if (comm.Rank == 0)//第一块右边交互
                {
                    int sendlenth = conupfaceid[NX - 1][0] - conupfaceid[NX - 2][0];//发送数据的长度
                    int receivelenth = cuboidnum - conupfaceid[NX - 1][0];//接收数据的长度
                    int[] senddata = new int[sendlenth];//发送的数据
                    int[] receivedata = new int[receivelenth];//接收的数据
                    senddata = data1D.Skip(conupfaceid[NX - 2][0]).Take(sendlenth).ToArray();//提取发送的数据
                    comm.Send(senddata, 1, 0);//发送数据
                    comm.Receive(1, 0, ref receivedata);//接收数据

                    for (int i = conupfaceid[NX - 1][0]; i < cuboidnum; i++)
                    {
                        data1D[i] = receivedata[i - conupfaceid[NX - 1][0]];//更新接收的数据
                    }

                }
                else if (comm.Rank == comm.Size - 1)//最后一块左边交互
                {
                    int laynum = downfaceid[1][NY - 1] - upfaceid[1][NY - 1] + 1;
                    int sendlenth = conupfaceid[1][NY - 1] - conupfaceid[1][0] + laynum;//发送数据的长度
                    int receivelenth = conupfaceid[1][0];//接收数据的长度
                    int[] senddata = new int[sendlenth];//发送的数据
                    int[] receivedata = new int[receivelenth];//接收的数据
                    senddata = data1D.Skip(conupfaceid[1][0]).Take(sendlenth).ToArray();//提取发送的数据
                    comm.Send(senddata, comm.Rank - 1, 0);//发送数据
                    comm.Receive(comm.Rank - 1, 0, ref receivedata);//接收数据

                    for (int i = 0; i < conupfaceid[1][0]; i++)
                    {
                        data1D[i] = receivedata[i];//更新接收的数据
                    }
                }
                else//中间块两边交互
                {
                    //右边交互
                    int sendlenth1 = conupfaceid[NX - 1][0] - conupfaceid[NX - 2][0];//发送数据的长度
                    int receivelenth1 = cuboidnum - conupfaceid[NX - 1][0];//接收数据的长度
                    int[] senddata1 = new int[sendlenth1];//发送的数据
                    int[] receivedata1 = new int[receivelenth1];//接收的数据
                    senddata1 = data1D.Skip(conupfaceid[NX - 2][0]).Take(sendlenth1).ToArray();//提取发送的数据
                    comm.Send(senddata1, comm.Rank + 1, 0);//发送数据
                    comm.Receive(comm.Rank + 1, 0, ref receivedata1);//接收数据

                    for (int i = conupfaceid[NX - 1][0]; i < cuboidnum; i++)
                    {
                        data1D[i] = receivedata1[i - conupfaceid[NX - 1][0]];//更新接收的数据
                    }

                    //左边交互
                    int sendlenth2 = conupfaceid[2][0] - conupfaceid[1][0];//发送数据的长度
                    int receivelenth2 = conupfaceid[1][0];//接收数据的长度
                    int[] senddata2 = new int[sendlenth2];//发送的数据
                    int[] receivedata2 = new int[receivelenth2];//接收的数据
                    senddata2 = data1D.Skip(conupfaceid[1][0]).Take(sendlenth2).ToArray();//提取发送的数据
                    comm.Send(senddata2, comm.Rank - 1, 0);//发送数据
                    comm.Receive(comm.Rank - 1, 0, ref receivedata2);//接收数据

                    for (int i = 0; i < conupfaceid[1][0]; i++)
                    {
                        data1D[i] = receivedata2[i];//更新接收的数据
                    }

                }
            }

        }

        /// <summary>
        /// 二维数据交互
        /// </summary>
        /// <param name="comm"></param>
        /// <param name="data2D"></param>
        /// <param name="NX"></param>
        /// <param name="NY"></param>
        public static void Sendreceive2D(Intracommunicator comm, ref double[][] data2D, int NX, int NY)
        {
            if (comm.Size > 1)
            {
                if (comm.Rank == 0)//第一块右边交互
                {
                    comm.Send(data2D[NX - 1], 1, 0);//发送数据
                    comm.Receive(1, 0, ref data2D[NX]);//接收数据
                }
                else if (comm.Rank == comm.Size - 1)//最后一块左边交互
                {
                    comm.Send(data2D[2], comm.Rank - 1, 0);//发送数据
                    comm.Receive(comm.Rank - 1, 0, ref data2D[1]);//接收数据
                }
                else//中间块两边交互
                {
                    //右边交互                    
                    comm.Send(data2D[NX - 1], comm.Rank + 1, 0);//发送数据
                    comm.Receive(comm.Rank + 1, 0, ref data2D[NX]);//接收数据                    
                    //左边交互                   
                    comm.Send(data2D[2], comm.Rank - 1, 0);//发送数据
                    comm.Receive(comm.Rank - 1, 0, ref data2D[1]);//接收数据                 

                }
            }

        }

        /// <summary>
        /// 三维数据交互
        /// </summary>
        /// <param name="comm"></param>
        /// <param name="data3D"></param>
        /// <param name="NX"></param>
        /// <param name="NY"></param>
        public static void Sendreceive3D(Intracommunicator comm, ref double[][][] data3D, int NX, int NY)
        {
            if (comm.Size > 1)
            {
                if (comm.Rank == 0)//第一块右边交互
                {
                    comm.Send(data3D[NX - 1], 1, 0);//发送数据
                    comm.Receive(1, 0, ref data3D[NX]);//接收数据
                }
                else if (comm.Rank == comm.Size - 1)//最后一块左边交互
                {
                    comm.Send(data3D[2], comm.Rank - 1, 0);//发送数据
                    comm.Receive(comm.Rank - 1, 0, ref data3D[1]);//接收数据
                }
                else//中间块两边交互
                {
                    //右边交互                    
                    comm.Send(data3D[NX - 1], comm.Rank + 1, 0);//发送数据
                    comm.Receive(comm.Rank + 1, 0, ref data3D[NX]);//接收数据                    
                    //左边交互                   
                    comm.Send(data3D[2], comm.Rank - 1, 0);//发送数据
                    comm.Receive(comm.Rank - 1, 0, ref data3D[1]);//接收数据                 

                }
            }
        }


    }
}
