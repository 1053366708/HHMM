﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//GreenAmpt 分层入渗变量
namespace HHMM
{
    public class GMIMvar
    {
        public int NXCELL, NYCELL, NZCELL;//网格数目
        public double[][] surfaceinfil; //垂面总入渗
        public double[][] bottomflow;//渗漏

        public GMIMvar(HHMMvar HHvar)
        {
            NXCELL = HHvar.NXCELL;
            NYCELL = HHvar.NYCELL;
            NZCELL = HHvar.NZCELL;
            GMIMvardefine();
        }
        public void GMIMvardefine()
        {
            surfaceinfil = new double[NXCELL][];
            bottomflow = new double[NXCELL][];
            for (int i = 0; i < NXCELL; i++)
            {
                surfaceinfil[i] = new double[NYCELL];
                bottomflow[i] = new double[NYCELL];
            }
        }
    }
}
