﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HHMM
{
    public class SVCSconst
    {
        public const double HE_CA = 1E-12;
        public const double VE_CA = 1E-12;
        public const double TOL = 1E-13;
        public const double EPSILON = 1E-13;
        public const double GRAV = 9.81;
        public const double Maxiter = 1000;
        public const double Fri = 0.5;
    }
}
