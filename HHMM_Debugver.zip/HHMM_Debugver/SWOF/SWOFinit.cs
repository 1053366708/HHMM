﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Globalization;

namespace HHMM
{
    public class SVCSinit
    {
        public static void SVinit(SVCSvar SVvar, HHMMvar HHvar, string SVdatapath)
        {
            topoinit(SVvar.NXCELL, SVvar.NYCELL, SVvar.z, SVvar.Fri_tab, HHvar);
            SVCSinit.boundschemeinit(SVvar.NXCELL, SVvar.NYCELL, SVvar.LBcscheme, SVvar.RBcscheme, SVvar.TBcscheme, SVvar.BBcscheme);//初始化边界类型
            Bccal.boundzcal(SVvar.NXCELL, SVvar.NYCELL, SVvar.LBcscheme, SVvar.RBcscheme, SVvar.TBcscheme, SVvar.BBcscheme, SVvar.z);//初始化虚拟网格地形
            if (SVvar.ORDER == 1)
            {
                Recon.deltazcalO(SVvar.NXCELL, SVvar.NYCELL, SVvar.z, SVvar.delz1, SVvar.delz2, SVvar.delzc1, SVvar.delzc2);
            }
            else
            {
                Recon.deltazcalT(SVvar.NXCELL, SVvar.NYCELL, SVvar.z, SVvar.delz1, SVvar.delz2, SVvar.z1r, SVvar.z1l, SVvar.z2r, SVvar.z2l, SVvar.som_z1, SVvar.som_z2);//地形高程计算
            }
            SVCSinit.huvinit(SVvar, HHvar);
        }

        /// <summary>
        /// 初始化地形
        /// </summary>
        /// <param name="NXCELL">横轴坐标数</param>
        /// <param name="NYCELL">纵轴坐标数</param>
        /// <param name="z">网格地形</param>
        /// <param name="datapath">文件路径</param>
        public static void topoinit(int NXCELL, int NYCELL, double[][] z, double[][] Fri_tab, HHMMvar HHvar)
        {
            for (int i = 1; i < NXCELL + 1; i++)
            {
                for (int j = 1; j < NYCELL + 1; j++)
                {
                    if (HHvar.upfaceid[i - 1][j - 1] <= HHvar.Novalue + 10)
                    {
                        z[i][j] = HHvar.Tdemvalue[i - 1][j - 1] + 1000.0;
                        Fri_tab[i][j] = SVCSconst.Fri;
                    }
                    else
                    {
                        z[i][j] = HHvar.Tdemvalue[i - 1][j - 1];
                        Fri_tab[i][j] = SVCSconst.Fri;
                    }
                }
            }

            /*
            string topofile = System.IO.Path.Combine(datapath, "topography.txt");
            StreamReader basinattf = File.OpenText(topofile);
            char[] spi = new char[] { ' ', ',', '\t' };
            String topos = basinattf.ReadLine();
             */
            /*
           for (int i = 1; i < NXCELL + 1; i++)
           {
               for (int j = 1; j < NYCELL + 1; j++)
               {
                   topos = basinattf.ReadLine();
                   z[i][j] = Convert.ToDouble(topos.Split(spi, StringSplitOptions.RemoveEmptyEntries)[2]);
               }
           }*/
            /*
            for (int j = 1; j < NYCELL + 1; j++)
            {
                for (int i = 1; i <= NXCELL / 2 - 1; i++)
                {
                    z[i][j] = 11.6 - i * 0.1;
                    z[i + 17][j] = 10.0 + i * 0.1;
                }
                z[16][j] = 10.0;
                z[17][j] = 10.0;

            }
             * */
            /*
            double zmax = 13.0;
            double zmin = zmax - 0.1 * (NYCELL / 2 - 1);
            for (int i = 1; i < NXCELL+1; i++)
            {
                for (int j = 1; j <= NYCELL / 2 - 1; j++)
                {
                    z[i][j] = (zmax+0.1) - j * 0.1;
                    z[i][j + (NYCELL) / 2 + 1] = zmin + j * 0.1;
                }
                z[i][(NYCELL + 2) / 2 - 1] = zmin;
                z[i][(NYCELL + 2) / 2] = zmin;
            }
             * */
            /*
            for (int i = 1; i < NXCELL + 1; i++)
            {
                for (int j = 1; j < NYCELL + 1; j++)
                {
                    double x = 0.5 + (i - 1) * 1.0;
                    double y = 0.5 + (j - 1) * 1.0;
                    z[i][j]=Math.Max(0,1.0-1.0/8.0*Math.Sqrt(Math.Pow((x-30.0),2.0)+Math.Pow((y-6.0),2.0)));
                    z[i][j] = Math.Max(z[i][j], 1.0 - 1.0 / 8.0 * Math.Sqrt(Math.Pow((x - 30.0), 2.0) + Math.Pow((y - 24.0), 2.0)));
                    z[i][j] = Math.Max(z[i][j], 3.0 - 3.0 / 10.0 * Math.Sqrt(Math.Pow((x - 47.5), 2.0) + Math.Pow((y - 15.0), 2.0)));
                }
            }
            basinattf.Close();*/
        }
        /// <summary>
        /// /// 初始化边界类型1：固壁，2：通量，3：定水位，4：定流量，并给出初始信息
        /// </summary>
        /// <param name="NXCELL">横向网格数</param>
        /// <param name="NYCELL">纵向网格数</param>
        /// <param name="LBcscheme">左边界类型</param>
        /// <param name="RBcscheme">右边界类型</param>
        /// <param name="TBcscheme">上边界类型</param>
        /// <param name="BBcscheme">下边界类型</param>
        public static void boundschemeinit(int NXCELL, int NYCELL, int[] LBcscheme, int[] RBcscheme, int[] TBcscheme, int[] BBcscheme)
        {
            for (int i = 1; i < NYCELL + 1; i++)
            {
                LBcscheme[i] = 1;
                RBcscheme[i] = 1;
                /*
                if ((i<=5)||(i>=26))
                {
                    RBcscheme[i] = 2;
                }
                else
                {
                    RBcscheme[i] = 1;
                }
                 */
            }

            for (int i = 1; i < NXCELL + 1; i++)
            {
                TBcscheme[i] = 1;
                BBcscheme[i] = 2;
            }
        }
        /// </summary>
        /// <param name="t">当前时间</param>
        /// <param name="NXCELL">横向网格数</param>
        /// <param name="NYCELL">纵向网格数</param>
        /// <param name="Lqfix">左边界流量</param>
        /// <param name="Rqfix">右边界流量</param>
        /// <param name="Tqfix">上边界流量</param>
        /// <param name="Bqfix">下边界流量</param>
        /// <param name="Lhfix">左边界水位</param>
        /// <param name="Rhfix">右边界水位</param>
        /// <param name="Thfix">上边界水位</param>
        /// <param name="Bhfix">下边界水位</param>
        public static void boundinfo(int t, int NXCELL, int NYCELL, double[] Lqfix, double[] Rqfix, double[] Tqfix, double[] Bqfix, double[] Lhfix, double[] Rhfix, double[] Thfix, double[] Bhfix)
        {
            for (int i = 1; i < NYCELL + 1; i++)
            {
                Lqfix[i] = 0;
                Lhfix[i] = 0;
            }
            for (int i = 1; i < NXCELL; i++)
            {
                Tqfix[i] = 0;
                Thfix[i] = 0;
            }
        }


        public static void huvinit(SVCSvar SVvar, HHMMvar HHvar)
        {
            SVvar.Meanheight = 0.0;
            SVvar.Totalwatervolume = 0.0;
            for (int i = 1; i < SVvar.NXCELL + 1; i++)
            {
                for (int j = 1; j < SVvar.NYCELL + 1; j++)
                {
                    SVvar.h[i][j] = 0.0;
                    SVvar.u[i][j] = 0.0;
                    SVvar.v[i][j] = 0.0;
                    if (SVvar.h[i][j] > SVCSconst.HE_CA)
                    {
                        SVvar.Meanheight += SVvar.h[i][j];
                    }
                    /*
                    if (HHvar.upfaceid[i-1][j-1] > HHvar.Novalue + 10)
                    {
                        SVvar.h[i][j] = 0.1;
                        SVvar.u[i][j] = 0.0;
                        SVvar.v[i][j] = 0.0;
                        if (SVvar.h[i][j] > SVCSconst.HE_CA)
                        {
                            SVvar.Meanheight += SVvar.h[i][j];
                        }
                    }*/
                }
            }
            SVvar.Totalwatervolume = SVvar.Meanheight * SVvar.Cellx * SVvar.Celly;
            SVvar.Meanheight /= HHvar.globalvd;
        }
    }
}
