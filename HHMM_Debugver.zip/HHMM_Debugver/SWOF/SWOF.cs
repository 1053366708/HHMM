﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MPI;

namespace HHMM
{
    public class SWOF
    {
        public static void SVCSrun(SVCSvar SVvar, HHMMvar HHvar, GMIMvar GMvar, SHAWvar TVvar, Intracommunicator comm)
        {
            double T = Convert.ToDouble(HHvar.Dtcal / HHvar.innernum);
            double Step_outflow = 0;
            if (HHvar.tn % HHvar.innernum == 0)
            { //水动力循环的第一步，水量平衡累计
                SVvar.fluxy0_cum_T = 0.0;
                SVvar.fluxNycell_cum_T = 0.0;
                SVvar.fluxx0_cum_T = 0.0;
                SVvar.fluxNxcell_cum_T = 0.0;
                //SVvar.Total_volume_outflow = 0.0;
                //SVvar.Totalrain = 0.0;
                //SVvar.Totalinfil = 0.0;
                //SVvar.Totalrecharge = 0.0;

            }
            if (HHvar.tn % HHvar.calpout == 1 || HHvar.calpout == 1)
            {
                SVvar.Total_volume_outflow = 0.0;
                for (int i = 0; i < HHvar.NXCELL; i++)
                {
                    for (int j = 0; j < HHvar.NYCELL; j++)
                    {
                        GMvar.surfaceinfil[i][j] = 0.0;
                        GMvar.bottomflow[i][j] = 0.0;
                    }
                }
            }

            SVvar.cur_time = 0.0;
            if (SVvar.ORDER == 1)
            {
                //SVvar.Total_volume_outflow = 0.0;
                #region
                while ((SVvar.cur_time < T))
                {

                    SVvar.dt1 = SVvar.dt_max;
                    if (HHvar.SFM > 0)
                    {


                        Bccal.Boundarycal(SVvar.NXCELL, SVvar.NYCELL, SVvar.LBcscheme, SVvar.RBcscheme, SVvar.TBcscheme, SVvar.BBcscheme, SVvar.Lqfix, SVvar.Rqfix, SVvar.Tqfix, SVvar.Bqfix, SVvar.Lhfix, SVvar.Rhfix, SVvar.Thfix, SVvar.Bhfix, SVvar.h, SVvar.u, SVvar.v);

                        //Parallel.For(0, SVvar.NXCELL + 1, new ParallelOptions() { MaxDegreeOfParallelism = HHvar.EnvPro }, i =>

                        for (int i = 0; i < SVvar.NXCELL + 1; i++)
                        {
                            for (int j = 1; j < SVvar.NYCELL + 1; j++)
                            {
                                SVvar.h1r[i][j] = SVvar.h[i][j];
                                SVvar.u1r[i][j] = SVvar.u[i][j];
                                SVvar.v1r[i][j] = SVvar.v[i][j];
                                SVvar.h1l[i + 1][j] = SVvar.h[i + 1][j];
                                SVvar.u1l[i + 1][j] = SVvar.u[i + 1][j];
                                SVvar.v1l[i + 1][j] = SVvar.v[i + 1][j];
                            }//end for j
                        }
                        // );

                        //Parallel.For(1, SVvar.NXCELL + 1, new ParallelOptions() { MaxDegreeOfParallelism = HHvar.EnvPro }, i =>
                        for (int i = 1; i < SVvar.NXCELL + 1; i++)
                        {
                            for (int j = 0; j < SVvar.NYCELL + 1; j++)
                            {
                                SVvar.h2r[i][j] = SVvar.h[i][j];
                                SVvar.u2r[i][j] = SVvar.u[i][j];
                                SVvar.v2r[i][j] = SVvar.v[i][j];
                                SVvar.h2l[i][j + 1] = SVvar.h[i][j + 1];
                                SVvar.u2l[i][j + 1] = SVvar.u[i][j + 1];
                                SVvar.v2l[i][j + 1] = SVvar.v[i][j + 1];
                            }//end for j
                        }
                        // );
                        Fluxclass.Calcflux(HHvar.EnvPro, SVvar.NXCELL, SVvar.NYCELL, SVvar.SCHEME_TYPE, SVvar.fluxmethod, SVvar.CFL_FIX, SVvar.DT_FIX, SVvar.dt_max, SVvar.Cellx, SVvar.Celly, SVvar.delz1, SVvar.h1l, SVvar.h1r, SVvar.u1l, SVvar.u1r, SVvar.v1l, SVvar.v1r, SVvar.h1left, SVvar.h1right, SVvar.delz2, SVvar.h2l, SVvar.h2r, SVvar.u2l, SVvar.u2r, SVvar.v2l, SVvar.v2r, SVvar.h2left, SVvar.h2right, SVvar.f1, SVvar.f2, SVvar.f3, SVvar.g1, SVvar.g2, SVvar.g3, ref SVvar.dt1);
                        SVvar.dt1 = Math.Min(T - SVvar.cur_time, SVvar.dt1);

                        if (comm.Size > 1)
                        {
                            SVvar.dt1 = comm.Reduce(SVvar.dt1, Operation<double>.Min, 0);
                            comm.Broadcast(ref SVvar.dt1, 0);
                        }

                        SVvar.tx = SVvar.dt1 / SVvar.Cellx;
                        SVvar.ty = SVvar.dt1 / SVvar.Celly;
                        Huvclass.Huvcal(HHvar.startcol, HHvar.endcol, HHvar.EnvPro, SVvar.verif, SVvar.ORDER, SVvar.NXCELL, SVvar.NYCELL, SVvar.fricmethod, SVvar.dt1, SVvar.Cellx, SVvar.Celly, SVvar.dt_first, HHvar.Demmax, SVvar.z, SVvar.LBcscheme, SVvar.RBcscheme, SVvar.TBcscheme, SVvar.BBcscheme, SVvar.Fri_tab, SVvar.h, SVvar.u, SVvar.v, SVvar.hs, SVvar.us, SVvar.vs, SVvar.delzc1, SVvar.h1l, SVvar.h1r, SVvar.h1left, SVvar.h1right, SVvar.delzc2, SVvar.h2l, SVvar.h2r, SVvar.h2left, SVvar.h2right, SVvar.f1, SVvar.f2, SVvar.f3, SVvar.g1, SVvar.g2, SVvar.g3, HHvar.regionpara.RAIN, GMvar.surfaceinfil, SVvar.qs1, SVvar.qs2, ref SVvar.fluxy0_cum_T, ref SVvar.fluxNycell_cum_T, ref SVvar.fluxx0_cum_T, ref SVvar.fluxNxcell_cum_T, out Step_outflow);//????

                        //Parallel.For(1, SVvar.NXCELL + 1, new ParallelOptions() { MaxDegreeOfParallelism = HHvar.EnvPro }, i =>
                        for (int i = 1; i < SVvar.NXCELL + 1; i++)
                        {
                            for (int j = 1; j < SVvar.NYCELL + 1; j++)
                            {
                                SVvar.h[i][j] = SVvar.hs[i][j];
                                SVvar.u[i][j] = SVvar.us[i][j];
                                SVvar.v[i][j] = SVvar.vs[i][j];
                                SVvar.q1[i][j] = SVvar.h[i][j] * SVvar.us[i][j];
                                SVvar.q2[i][j] = SVvar.h[i][j] * SVvar.vs[i][j];

                                if (SVvar.h[i][j] <= SVCSconst.HE_CA)
                                {
                                    SVvar.h[i][j] = 0.0;
                                    SVvar.u[i][j] = 0.0;
                                    SVvar.v[i][j] = 0.0;
                                }
                                if (Math.Abs(SVvar.u[i][j]) <= SVCSconst.VE_CA)
                                {
                                    SVvar.u[i][j] = 0.0;
                                    SVvar.q1[i][j] = 0.0;
                                }
                                if (Math.Abs(SVvar.v[i][j]) <= SVCSconst.VE_CA)
                                {
                                    SVvar.v[i][j] = 0.0;
                                    SVvar.q2[i][j] = 0.0;
                                }
                                /*
                                int ni = 0;
                                if (HHvar.upfaceid[i-1][j-1] > HHvar.Novalue + 10)
                                {
                                    if (GMvar.surfaceinfil[i - 1][j - 1] > 0)
                                    {
                                        //SVvar.Totalinfil += GMvar.surfaceinfil[i - 1][j - 1];
                                        SVvar.Totalinfil += GMvar.surfaceinfil[i - 1][j - 1] * SVvar.Cellx * SVvar.Celly* SVvar.dt1 / HHvar.Dtcal ;
                                        //SVvar.Totalrain += HHvar.regionpara.RAIN * SVvar.Cellx * SVvar.Celly * SVvar.dt1;
                                        //SVvar.Meanheight += SVvar.h[i][j];
                                        ni++;
                                    }
                                //    if (HHvar.regionpara.RAIN > 0)
                                //    {
                               //         SVvar.Totalrain += HHvar.regionpara.RAIN * SVvar.Cellx * SVvar.Celly * SVvar.dt1 / HHvar.Dtcal;
                               //     }
                                }*/
                            }
                        }
                    }
                    else
                    {
                        SVvar.dt1 = Math.Min(T - SVvar.cur_time, SVvar.dt1);
                        for (int i = 1; i < SVvar.NXCELL + 1; i++)
                        {
                            for (int j = 1; j < SVvar.NYCELL + 1; j++)
                            {
                                SVvar.h[i][j] = SVvar.h[i][j] + HHvar.regionpara.RAIN * SVvar.dt1;
                            }
                        }
                    }
                    SVvar.cur_time = SVvar.cur_time + SVvar.dt1;

                    if (comm.Size > 1)
                    {
                        HHMMtool.Sendreceive2D(comm, ref SVvar.h, HHvar.NXCELL, HHvar.NYCELL);
                        HHMMtool.Sendreceive2D(comm, ref SVvar.u, HHvar.NXCELL, HHvar.NYCELL);
                        HHMMtool.Sendreceive2D(comm, ref SVvar.v, HHvar.NXCELL, HHvar.NYCELL);
                    }

                    if (HHvar.IFM > 0) GMIM.GMIMrun(HHvar, SVvar, TVvar, GMvar);
                }
                SVvar.Total_volume_outflow += Step_outflow;
                #endregion
            }
            else
            {
                #region

                while ((SVvar.cur_time < T))
                {
                    if (SVvar.verif == 1)
                    {
                        SVvar.dt1 = SVvar.dt_max;
                        Bccal.Boundarycal(SVvar.NXCELL, SVvar.NYCELL, SVvar.LBcscheme, SVvar.RBcscheme, SVvar.TBcscheme, SVvar.BBcscheme, SVvar.Lqfix, SVvar.Rqfix, SVvar.Tqfix, SVvar.Bqfix, SVvar.Lhfix, SVvar.Rhfix, SVvar.Thfix, SVvar.Bhfix, SVvar.h, SVvar.u, SVvar.v);
                        for (int i = 1; i < SVvar.NXCELL + 1; i++)
                        {
                            for (int j = 1; j < SVvar.NYCELL + 1; j++)
                            {
                                if (SVvar.h[i][j] <= SVCSconst.HE_CA)
                                {
                                    SVvar.h[i][j] = 0.0;
                                    SVvar.u[i][j] = 0.0;
                                    SVvar.v[i][j] = 0.0;
                                }
                                if (Math.Abs(SVvar.u[i][j]) <= SVCSconst.VE_CA)
                                {
                                    SVvar.u[i][j] = 0.0;
                                    SVvar.q1[i][j] = 0.0;
                                }
                                if (Math.Abs(SVvar.v[i][j]) <= SVCSconst.VE_CA)
                                {
                                    SVvar.v[i][j] = 0.0;
                                    SVvar.q2[i][j] = 0.0;
                                }
                            }
                        }
                        Recon.Reconstrution(HHvar.EnvPro, SVvar.NXCELL, SVvar.NYCELL, SVvar.reconstrumethod, SVvar.AMORTENO, SVvar.MODIFENO, SVvar.Limitermethod, SVvar.z, SVvar.h, SVvar.u, SVvar.v, SVvar.delz1, SVvar.delz2, SVvar.som_z1, SVvar.som_z2, SVvar.z1r, SVvar.z1l, SVvar.h1r, SVvar.h1l, SVvar.u1r, SVvar.u1l, SVvar.v1r, SVvar.v1l, SVvar.z2r, SVvar.z2l, SVvar.h2r, SVvar.h2l, SVvar.u2r, SVvar.u2l, SVvar.v2r, SVvar.v2l, SVvar.delz1, SVvar.delz2, SVvar.delzc1, SVvar.delzc2);
                    }

                    Fluxclass.Calcflux(HHvar.EnvPro, SVvar.NXCELL, SVvar.NYCELL, SVvar.SCHEME_TYPE, SVvar.fluxmethod, SVvar.CFL_FIX, SVvar.DT_FIX, SVvar.dt_max, SVvar.Cellx, SVvar.Celly, SVvar.delz1, SVvar.h1l, SVvar.h1r, SVvar.u1l, SVvar.u1r, SVvar.v1l, SVvar.v1r, SVvar.h1left, SVvar.h1right, SVvar.delz2, SVvar.h2l, SVvar.h2r, SVvar.u2l, SVvar.u2r, SVvar.v2l, SVvar.v2r, SVvar.h2left, SVvar.h2right, SVvar.f1, SVvar.f2, SVvar.f3, SVvar.g1, SVvar.g2, SVvar.g3, ref SVvar.dt1);
                    SVvar.dt1 = Math.Min(T - SVvar.cur_time, SVvar.dt1);
                    SVvar.tx = SVvar.dt1 / SVvar.Cellx;
                    SVvar.ty = SVvar.dt1 / SVvar.Celly;
                    Huvclass.Huvcal(HHvar.startcol, HHvar.endcol, HHvar.EnvPro, SVvar.verif, SVvar.ORDER, SVvar.NXCELL, SVvar.NYCELL, SVvar.fricmethod, SVvar.dt1, SVvar.Cellx, SVvar.Celly, SVvar.dt_first, HHvar.Demmax, SVvar.z, SVvar.LBcscheme, SVvar.RBcscheme, SVvar.TBcscheme, SVvar.BBcscheme, SVvar.Fri_tab, SVvar.h, SVvar.u, SVvar.v, SVvar.hs, SVvar.us, SVvar.vs, SVvar.delzc1, SVvar.h1l, SVvar.h1r, SVvar.h1left, SVvar.h1right, SVvar.delzc2, SVvar.h2l, SVvar.h2r, SVvar.h2left, SVvar.h2right, SVvar.f1, SVvar.f2, SVvar.f3, SVvar.g1, SVvar.g2, SVvar.g3, HHvar.regionpara.RAIN, GMvar.surfaceinfil, SVvar.qs1, SVvar.qs2, ref SVvar.fluxy0_cum_T, ref SVvar.fluxNycell_cum_T, ref SVvar.fluxx0_cum_T, ref SVvar.fluxNxcell_cum_T, out SVvar.Total_volume_outflow);
                    SVvar.dt2 = SVvar.dt1;
                    Bccal.Boundarycal(SVvar.NXCELL, SVvar.NYCELL, SVvar.LBcscheme, SVvar.RBcscheme, SVvar.TBcscheme, SVvar.BBcscheme, SVvar.Lqfix, SVvar.Rqfix, SVvar.Tqfix, SVvar.Bqfix, SVvar.Lhfix, SVvar.Rhfix, SVvar.Thfix, SVvar.Bhfix, SVvar.hs, SVvar.us, SVvar.vs);
                    for (int i = 1; i < SVvar.NXCELL + 1; i++)
                    {
                        for (int j = 1; j < SVvar.NYCELL + 1; j++)
                        {
                            if (SVvar.hs[i][j] <= SVCSconst.HE_CA)
                            {
                                SVvar.hs[i][j] = 0.0;
                                SVvar.us[i][j] = 0.0;
                                SVvar.vs[i][j] = 0.0;
                                SVvar.qs1[i][j] = 0.0;
                                SVvar.qs2[i][j] = 0.0;
                            }
                            if (Math.Abs(SVvar.us[i][j]) <= SVCSconst.VE_CA)
                            {
                                SVvar.us[i][j] = 0.0;
                                SVvar.qs1[i][j] = 0.0;
                            }
                            if (Math.Abs(SVvar.vs[i][j]) <= SVCSconst.VE_CA)
                            {
                                SVvar.vs[i][j] = 0.0;
                                SVvar.qs2[i][j] = 0.0;
                            }
                        }
                    }
                    Recon.Reconstrution(HHvar.EnvPro, SVvar.NXCELL, SVvar.NYCELL, SVvar.reconstrumethod, SVvar.AMORTENO, SVvar.MODIFENO, SVvar.Limitermethod, SVvar.z, SVvar.hs, SVvar.us, SVvar.vs, SVvar.delz1, SVvar.delz2, SVvar.som_z1, SVvar.som_z2, SVvar.z1r, SVvar.z1l, SVvar.h1r, SVvar.h1l, SVvar.u1r, SVvar.u1l, SVvar.v1r, SVvar.v1l, SVvar.z2r, SVvar.z2l, SVvar.h2r, SVvar.h2l, SVvar.u2r, SVvar.u2l, SVvar.v2r, SVvar.v2l, SVvar.delz1, SVvar.delz2, SVvar.delzc1, SVvar.delzc2);
                    Fluxclass.Calcflux(HHvar.EnvPro, SVvar.NXCELL, SVvar.NYCELL, SVvar.SCHEME_TYPE, SVvar.fluxmethod, SVvar.CFL_FIX, SVvar.DT_FIX, SVvar.dt_max, SVvar.Cellx, SVvar.Celly, SVvar.delz1, SVvar.h1l, SVvar.h1r, SVvar.u1l, SVvar.u1r, SVvar.v1l, SVvar.v1r, SVvar.h1left, SVvar.h1right, SVvar.delz2, SVvar.h2l, SVvar.h2r, SVvar.u2l, SVvar.u2r, SVvar.v2l, SVvar.v2r, SVvar.h2left, SVvar.h2right, SVvar.f1, SVvar.f2, SVvar.f3, SVvar.g1, SVvar.g2, SVvar.g3, ref SVvar.dt2);

                    if (SVvar.dt2 < SVvar.dt1)
                    {
                        SVvar.verif = 0;
                        SVvar.dt1 = SVvar.dt2;
                        SVvar.tx = SVvar.dt1 / SVvar.Cellx;
                        SVvar.ty = SVvar.dt1 / SVvar.Celly;
                    }
                    else
                    {
                        SVvar.verif = 1;
                        Huvclass.Huvcal(HHvar.startcol, HHvar.endcol, HHvar.EnvPro, SVvar.verif, SVvar.ORDER, SVvar.NXCELL, SVvar.NYCELL, SVvar.fricmethod, SVvar.dt1, SVvar.Cellx, SVvar.Celly, SVvar.dt_first, HHvar.Demmax, SVvar.z, SVvar.LBcscheme, SVvar.RBcscheme, SVvar.TBcscheme, SVvar.BBcscheme, SVvar.Fri_tab, SVvar.hs, SVvar.us, SVvar.vs, SVvar.hsa, SVvar.usa, SVvar.vsa, SVvar.delzc1, SVvar.h1l, SVvar.h1r, SVvar.h1left, SVvar.h1right, SVvar.delzc2, SVvar.h2l, SVvar.h2r, SVvar.h2left, SVvar.h2right, SVvar.f1, SVvar.f2, SVvar.f3, SVvar.g1, SVvar.g2, SVvar.g3, HHvar.regionpara.RAIN, GMvar.surfaceinfil, SVvar.qs1, SVvar.qs2, ref SVvar.fluxy0_cum_T, ref SVvar.fluxNycell_cum_T, ref SVvar.fluxx0_cum_T, ref SVvar.fluxNxcell_cum_T, out SVvar.Total_volume_outflow);
                        for (int i = 1; i < SVvar.NXCELL + 1; i++)
                        {
                            for (int j = 1; j < SVvar.NYCELL + 1; j++)
                            {
                                if (SVvar.hsa[i][j] <= SVCSconst.HE_CA)
                                {
                                    SVvar.hsa[i][j] = 0.0;
                                }
                                if (Math.Abs(SVvar.usa[i][j]) <= SVCSconst.VE_CA)
                                {
                                    SVvar.usa[i][j] = 0.0;
                                }
                                if (Math.Abs(SVvar.vsa[i][j]) <= SVCSconst.VE_CA)
                                {
                                    SVvar.vsa[i][j] = 0.0;
                                }
                                double tmp = 0.5 * (SVvar.h[i][j] + SVvar.hsa[i][j]);
                                if (tmp >= SVCSconst.HE_CA)
                                {
                                    SVvar.q1[i][j] = 0.5 * (SVvar.h[i][j] * SVvar.u[i][j] + SVvar.hsa[i][j] * SVvar.usa[i][j]);
                                    SVvar.u[i][j] = SVvar.q1[i][j] / tmp;
                                    SVvar.q2[i][j] = 0.5 * (SVvar.h[i][j] * SVvar.v[i][j] + SVvar.hsa[i][j] * SVvar.vsa[i][j]);
                                    SVvar.v[i][j] = SVvar.q2[i][j] / tmp;
                                    SVvar.h[i][j] = tmp;
                                }
                                else
                                {
                                    SVvar.u[i][j] = 0.0;
                                    SVvar.q1[i][j] = 0.0;
                                    SVvar.v[i][j] = 0.0;
                                    SVvar.q2[i][j] = 0.0;
                                    SVvar.h[i][j] = 0.0;
                                }
                                if (HHvar.upfaceid[i - 1][j - 1] > HHvar.Novalue + 10)
                                {
                                    if (GMvar.surfaceinfil[i - 1][j - 1] > 0)
                                    {
                                        SVvar.Totalinfil += GMvar.surfaceinfil[i - 1][j - 1] * SVvar.Cellx * SVvar.Celly * SVvar.dt1;
                                    }
                                }
                            }
                        }
                        SVvar.cur_time = SVvar.cur_time + SVvar.dt1;
                    }
                }
                #endregion
            }


        }
    }
}
