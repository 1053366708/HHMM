﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHMM
{
    public class SVCSvar
    {
        //dt_max = Math.Min(DX * CFL_FIX, DY * CFL_FIX)
        public double CFL_FIX = 1, DT_FIX = 0.1;//相关参数
        public double AMORTENO = 0.25, MODIFENO = 0.9; //相关参数
        //计算次数及时间设置
        public double cur_time = 0.0, dt1 = 0, dt2 = 0.0, tx = 0.0, ty = 0.0, dt_first = 0.0, dt_max, Tout = 1;//时间变量设置
        public int verif = 1;//是否重新计算
        //方法设置             
        public int reconstrumethod = 1, Limitermethod = 1, SCHEME_TYPE = 1, fluxmethod = 1, ORDER = 1, fricmethod = 1; //不同过程中采用的计算方法          
        public StreamWriter SVresultfile;
        public int NXCELL, NYCELL, NZCELL;
        public double Cellx, Celly;
        public double fluxy0_cum_T = 0, fluxNycell_cum_T = 0, fluxx0_cum_T = 0, fluxNxcell_cum_T = 0, Total_volume_outflow = 0;
        public double Totalrain = 0, Meanheight = 0, Totalinfil = 0, Totalwatervolume = 0, Totalrecharge = 0, Totalinterflow = 0;
        public double Totalrainall = 0, Meanheightall = 0, Totalinfilall = 0, Totalwatervolumeall = 0, Totalrechargeall = 0, Total_volume_outflowall = 0;
        public int[] LBcscheme, RBcscheme, TBcscheme, BBcscheme;
        public double[] Lqfix, Rqfix, Tqfix, Bqfix, Lhfix, Rhfix, Thfix, Bhfix;
        public double[][] h, hs, hsa, h1r, h1l, h1right, h1left, h2r, h2l, h2right, h2left;
        public double[][] u, us, usa, u1r, u1l, u2r, u2l;
        public double[][] v, vs, vsa, v1r, v1l, v2r, v2l;
        public double[][] z, delz1, delz2, delzc1, delzc2, som_z1, som_z2, z1r, z1l, z2r, z2l;
        public double[][] Fri_tab, q1, q2, qs1, qs2, g1, g2, g3, f1, f2, f3;
        public SVCSvar(HHMMvar HHvar)
        {
            NXCELL = HHvar.NXCELL;
            NYCELL = HHvar.NYCELL;
            NZCELL = HHvar.NZCELL;
            Cellx = HHvar.DX;
            Celly = HHvar.DY;
            Svvardefine();
        }

        public void Svvardefine()
        {
            dt_max = Math.Min(Cellx * CFL_FIX, Celly * CFL_FIX);
            Fri_tab = new double[NXCELL + 2][];
            z = new double[NXCELL + 2][]; h = new double[NXCELL + 2][]; u = new double[NXCELL + 2][]; v = new double[NXCELL + 2][];
            delz1 = new double[NXCELL + 2][]; delz2 = new double[NXCELL + 2][]; som_z1 = new double[NXCELL + 2][]; som_z2 = new double[NXCELL + 2][];

            z1r = new double[NXCELL + 2][]; z1l = new double[NXCELL + 2][]; h1r = new double[NXCELL + 2][]; h1l = new double[NXCELL + 2][];
            h1right = new double[NXCELL + 2][]; h1left = new double[NXCELL + 2][]; h2right = new double[NXCELL + 2][]; h2left = new double[NXCELL + 2][];
            u1r = new double[NXCELL + 2][]; u1l = new double[NXCELL + 2][]; v1r = new double[NXCELL + 2][]; v1l = new double[NXCELL + 2][];
            z2r = new double[NXCELL + 2][]; z2l = new double[NXCELL + 2][]; h2r = new double[NXCELL + 2][]; h2l = new double[NXCELL + 2][];
            u2r = new double[NXCELL + 2][]; u2l = new double[NXCELL + 2][]; v2r = new double[NXCELL + 2][]; v2l = new double[NXCELL + 2][];
            delz1 = new double[NXCELL + 2][]; delz2 = new double[NXCELL + 2][]; delzc1 = new double[NXCELL + 2][]; delzc2 = new double[NXCELL + 2][];

            g1 = new double[NXCELL + 2][]; g2 = new double[NXCELL + 2][]; g3 = new double[NXCELL + 2][];
            f1 = new double[NXCELL + 2][]; f2 = new double[NXCELL + 2][]; f3 = new double[NXCELL + 2][];

            hs = new double[NXCELL + 2][]; us = new double[NXCELL + 2][]; vs = new double[NXCELL + 2][];
            hsa = new double[NXCELL + 2][]; usa = new double[NXCELL + 2][]; vsa = new double[NXCELL + 2][];
            q1 = new double[NXCELL + 2][]; q2 = new double[NXCELL + 2][];
            qs1 = new double[NXCELL + 2][]; qs2 = new double[NXCELL + 2][];

            for (int i = 0; i <= NXCELL + 1; i++)
            {
                Fri_tab[i] = new double[NYCELL + 2];
                z[i] = new double[NYCELL + 2]; h[i] = new double[NYCELL + 2]; u[i] = new double[NYCELL + 2]; v[i] = new double[NYCELL + 2];
                delz1[i] = new double[NYCELL + 2]; delz2[i] = new double[NYCELL + 2]; som_z1[i] = new double[NYCELL + 2]; som_z2[i] = new double[NYCELL + 2];

                z1r[i] = new double[NYCELL + 2]; z1l[i] = new double[NYCELL + 2]; h1r[i] = new double[NYCELL + 2]; h1l[i] = new double[NYCELL + 2];
                h1right[i] = new double[NYCELL + 2]; h1left[i] = new double[NYCELL + 2]; h2right[i] = new double[NYCELL + 2]; h2left[i] = new double[NYCELL + 2];
                u1r[i] = new double[NYCELL + 2]; u1l[i] = new double[NYCELL + 2]; v1r[i] = new double[NYCELL + 2]; v1l[i] = new double[NYCELL + 2];
                z2r[i] = new double[NYCELL + 2]; z2l[i] = new double[NYCELL + 2]; h2r[i] = new double[NYCELL + 2]; h2l[i] = new double[NYCELL + 2];
                u2r[i] = new double[NYCELL + 2]; u2l[i] = new double[NYCELL + 2]; v2r[i] = new double[NYCELL + 2]; v2l[i] = new double[NYCELL + 2];
                delz1[i] = new double[NYCELL + 2]; delz2[i] = new double[NYCELL + 2]; delzc1[i] = new double[NYCELL + 2]; delzc2[i] = new double[NYCELL + 2];
                g1[i] = new double[NYCELL + 2]; g2[i] = new double[NYCELL + 2]; g3[i] = new double[NYCELL + 2];
                f1[i] = new double[NYCELL + 2]; f2[i] = new double[NYCELL + 2]; f3[i] = new double[NYCELL + 2];

                hs[i] = new double[NYCELL + 2]; us[i] = new double[NYCELL + 2]; vs[i] = new double[NYCELL + 2];
                hsa[i] = new double[NYCELL + 2]; usa[i] = new double[NYCELL + 2]; vsa[i] = new double[NYCELL + 2];
                q1[i] = new double[NYCELL + 2]; q2[i] = new double[NYCELL + 2];
                qs1[i] = new double[NYCELL + 2]; qs2[i] = new double[NYCELL + 2];
            }
            LBcscheme = new int[NYCELL + 2]; RBcscheme = new int[NYCELL + 2]; TBcscheme = new int[NXCELL + 2]; BBcscheme = new int[NXCELL + 2];
            Lqfix = new double[NYCELL + 2]; Rqfix = new double[NYCELL + 2]; Tqfix = new double[NXCELL + 2]; Bqfix = new double[NXCELL + 2];
            Lhfix = new double[NYCELL + 2]; Rhfix = new double[NYCELL + 2]; Thfix = new double[NXCELL + 2]; Bhfix = new double[NXCELL + 2];

        }
    }


}
