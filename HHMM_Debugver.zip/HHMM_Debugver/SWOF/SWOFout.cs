﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHMM
{
    public class SVCSout
    {
        public static void WaEnbalance(SVCSvar SVvar, GMIMvar GMvar, HHMMvar HHvar)
        {
            //if (HHvar.tn % HHvar.innernum == (HHvar.innernum - 1))
            //{ //地表水动力的最后一步，输出节点水位
            SVvar.Meanheight = 0.0;
            SVvar.Totalwatervolume = 0.0;
            SVvar.Totalrain = 0.0;
            SVvar.Totalinfil = 0.0;
            SVvar.Totalrecharge = 0.0;
            int gwpointi = 0;
            for (int nxi = 1; nxi <= SVvar.NXCELL; nxi++)
            {
                for (int nyj = 1; nyj <= SVvar.NYCELL; nyj++)
                {
                    if (HHvar.upfaceid[nxi - 1][nyj - 1] >= 0)
                    {
                        HHvar.validwaterdepth[gwpointi] = SVvar.h[nxi][nyj];
                        gwpointi += 1;
                    }
                }

            }
            for (int nxi = HHvar.startcol + 1; nxi <= HHvar.endcol; nxi++)
            {
                for (int nyj = 1; nyj <= SVvar.NYCELL; nyj++)
                {
                    if (HHvar.upfaceid[nxi - 1][nyj - 1] >= 0)
                    {
                        SVvar.Meanheight += SVvar.h[nxi][nyj];
                        SVvar.Totalinfil += GMvar.surfaceinfil[nxi - 1][nyj - 1] * SVvar.Cellx * SVvar.Celly;
                        SVvar.Totalrecharge += GMvar.bottomflow[nxi - 1][nyj - 1] * SVvar.Cellx * SVvar.Celly;
                    }
                }

            }

            //SVvar.Totalrain = HHvar.regionpara.RAIN * HHvar.Dtcal * HHvar.globalvdself * SVvar.Cellx * SVvar.Celly;//m3
            //SVvar.Totalrain = HHvar.regionpara.RAIN * HHMMconst.SecondPerHour * HHvar.globalvdself * SVvar.Cellx * SVvar.Celly;
            SVvar.Totalrain = HHvar.regionpara.Precipitation * HHvar.Dtout * HHvar.globalvdself * SVvar.Cellx * SVvar.Celly;
            SVvar.Totalwatervolume = SVvar.Meanheight * SVvar.Cellx * SVvar.Celly;
            SVvar.Meanheight /= HHvar.globalvdself;

            //}
        }
        public static void vtkout(string filedir, string varname, int n, int NXCELL, int NYCELL, double DX, double DY, double[][] z, double[][] hvar, double[][] uvar, double[][] vvar)
        {
            StreamWriter fvtk = new StreamWriter(filedir + "huv" + Convert.ToString(n) + ".vtk");
            fvtk.WriteLine("# vtk DataFile Version 2.0");
            fvtk.WriteLine("{0}", varname);
            fvtk.WriteLine("ASCII");
            fvtk.WriteLine("DATASET RECTILINEAR_GRID");
            fvtk.Write("DIMENSIONS ");
            fvtk.WriteLine("{0} {1} 1", NXCELL + 1, NYCELL + 1);
            fvtk.WriteLine("X_COORDINATES {0} float", NXCELL + 1);
            for (int i = 0; i < NXCELL + 1; i++)
            {

                fvtk.Write(i * DX + "\t");
            }
            fvtk.Write("\n");

            fvtk.WriteLine("Y_COORDINATES {0} float", NYCELL + 1);
            for (int i = 0; i < NYCELL + 1; i++)
            {

                fvtk.Write(i * DY + "\t");
            }
            fvtk.Write("\n");
            fvtk.WriteLine("Z_COORDINATES 1 float");
            fvtk.WriteLine("0.0");
            fvtk.WriteLine("CELL_DATA {0}", NXCELL * NYCELL);
            fvtk.WriteLine("SCALARS z float");
            fvtk.WriteLine("LOOKUP_TABLE z");
            for (int i = 1; i < NYCELL + 1; i++)
            {
                for (int j = 1; j < NXCELL + 1; j++)
                {
                    fvtk.Write(z[j][i] + "\t");
                }
                fvtk.Write("\n");
            }
            fvtk.WriteLine("SCALARS heith float");
            fvtk.WriteLine("LOOKUP_TABLE heigh");
            for (int i = 1; i < NYCELL + 1; i++)
            {
                for (int j = 1; j < NXCELL + 1; j++)
                {
                    fvtk.Write(hvar[j][i] + "\t");
                }
                fvtk.Write("\n");
            }
            fvtk.WriteLine("VECTORS Velocity float");
            for (int i = 1; i < NYCELL + 1; i++)
            {
                for (int j = 1; j < NXCELL + 1; j++)
                {
                    fvtk.Write(uvar[j][i] + "\t" + vvar[j][i] + "\t" + "0" + "\t");
                }
                fvtk.Write("\n");
            }
            fvtk.Flush();
            fvtk.Close();
        }
    }
}
