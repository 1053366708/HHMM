﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text;

namespace HHMM
{
    public class Fluxclass
    {
        public static void Calcflux(int EnvPro, int NXCELL, int NYCELL, int SCHEME_TYPE, int fluxmethod, double cflfix, double DT_FIX, double dt_max, double DX, double DY, double[][] delz1, double[][] h1l, double[][] h1r, double[][] u1l, double[][] u1r, double[][] v1l, double[][] v1r, double[][] h1left, double[][] h1right, double[][] delz2, double[][] h2l, double[][] h2r, double[][] u2l, double[][] u2r, double[][] v2l, double[][] v2r, double[][] h2left, double[][] h2right, double[][] f1, double[][] f2, double[][] f3, double[][] g1, double[][] g2, double[][] g3, ref double dt_cal2)
        {
            double dt_tmp, dtx, dty;
            double velocity_max_x, velocity_max_y;
            double cfl;
            double dt_cal = dt_cal2;
            dtx = dt_max;
            dty = dt_max;
            velocity_max_x = -SVCSconst.VE_CA;
            velocity_max_y = -SVCSconst.VE_CA;

            Parallel.For(1, NXCELL + 2, new ParallelOptions() { MaxDegreeOfParallelism = EnvPro }, i =>
            //   for (int i = 1; i <= NXCELL + 1; i++)
            {
                for (int j = 1; j < NYCELL + 1; j++)
                {
                    Hydrostaticcal(h1r[i - 1][j], h1l[i][j], delz1[i - 1][j], out h1right[i - 1][j], out h1left[i][j]);
                    Fluxcal(fluxmethod, h1right[i - 1][j], h1left[i][j], u1r[i - 1][j], u1l[i][j], v1r[i - 1][j], v1l[i][j], out f1[i][j], out f2[i][j], out f3[i][j], out cfl);
                    if (Math.Abs(cfl * dt_cal / DX) < SVCSconst.EPSILON)
                    {
                        dt_tmp = dt_max;
                    }
                    else
                    {
                        dt_tmp = cflfix * DX / cfl;
                    }
                    dtx = Math.Min(Math.Min(dt_cal, dt_tmp), dtx);
                    velocity_max_x = Math.Max(velocity_max_x, cfl);
                }
            });

            //for (int i = 1; i < NXCELL + 1; i++)
            Parallel.For(1, NXCELL + 1, new ParallelOptions() { MaxDegreeOfParallelism = EnvPro }, i =>
            {
                for (int j = 1; j <= NYCELL + 1; j++)
                {
                    Hydrostaticcal(h2r[i][j - 1], h2l[i][j], delz2[i][j - 1], out h2right[i][j - 1], out h2left[i][j]);
                    Fluxcal(fluxmethod, h2right[i][j - 1], h2left[i][j], v2r[i][j - 1], v2l[i][j], u2r[i][j - 1], u2l[i][j], out g1[i][j], out g3[i][j], out g2[i][j], out cfl);
                    if (Math.Abs(cfl * dt_cal / DY) < SVCSconst.EPSILON)
                    {
                        dt_tmp = dt_max;
                    }
                    else
                    {
                        dt_tmp = cflfix * DY / cfl;
                    }
                    dty = Math.Min(Math.Min(dt_cal, dt_tmp), dty);
                    velocity_max_y = Math.Max(velocity_max_y, cfl);
                }
            });

            if (SCHEME_TYPE == 1)
            {
                dt_cal = Math.Min(dtx, dty);
            }
            else
            {
                if ((velocity_max_x * DT_FIX / DX > cflfix) || (velocity_max_y * DT_FIX / DY > cflfix))
                {
                    Console.WriteLine(" the CFL condition is not satisfied: {0}", cflfix);
                    Environment.Exit(0);
                }
                dt_cal = DT_FIX;
            }
            dt_cal2 = dt_cal;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="h_L">边界左侧网格水位</param>
        /// <param name="h_R">边界右侧网格水位</param>
        /// <param name="dz">相邻网格的地形差</param>
        /// <param name="hl_rec"></param>
        /// <param name="hr_rec"></param>
        public static void Hydrostaticcal(double h_L, double h_R, double dz, out double hl_rec, out double hr_rec)
        {
            hl_rec = 0.0;
            hr_rec = 0.0;
            hl_rec = Math.Max(0.0, h_L - Math.Max(0.0, dz));
            hr_rec = Math.Max(0.0, h_R - Math.Max(0.0, -dz));
        }

        /// <summary>
        /// 通量计算
        /// </summary>
        /// <param name="fluxmethod">通量计算方法</param>
        /// <param name="h_L">界面左侧水位</param>
        /// <param name="h_R">界面右侧水位</param>
        /// <param name="u_L">界面左侧法向速度</param>
        /// <param name="u_R">界面右侧法向速度</param>
        /// <param name="v_L">界面左侧切向速度</param>
        /// <param name="v_R">界面右侧切向速度</param>
        /// <param name="f1">通量计算的第一部分</param>
        /// <param name="f2">通量计算的第二部分</param>
        /// <param name="f3">通量计算的第三部分</param>
        /// <param name="cfl">CFL值</param>
        public static void Fluxcal(int fluxmethod, double h_L, double h_R, double u_L, double u_R, double v_L, double v_R, out double f1, out double f2, out double f3, out double cfl)
        {
            f1 = 0.0;
            f2 = 0.0;
            f3 = 0.0;
            cfl = 0.0;
            switch (fluxmethod)
            {
                case 1:
                    FluxHLLC(h_L, h_R, u_L, u_R, v_L, v_R, out f1, out f2, out f3, out cfl);
                    break;
                case 2:
                    FluxHLLC2(h_L, h_R, u_L, u_R, v_L, v_R, out f1, out f2, out f3, out cfl);
                    break;
                case 3:
                    FluxRusanov(h_L, h_R, u_L, u_R, v_L, v_R, out f1, out f2, out f3, out cfl);
                    break;
                case 4:
                    FluxHLL(h_L, h_R, u_L, u_R, v_L, v_R, out f1, out f2, out f3, out cfl);
                    break;
                case 5:
                    FluxHLL2(h_L, h_R, u_L, u_R, v_L, v_R, out f1, out f2, out f3, out cfl);
                    break;
            }
        }
        public static void FluxHLLC(double h_L, double h_R, double u_L, double u_R, double v_L, double v_R, out double f1, out double f2, out double f3, out double cfl)
        {
            f1 = 0.0;
            f2 = 0.0;
            f3 = 0.0;
            cfl = 0.0;
            if ((h_L < SVCSconst.HE_CA) & (h_R < SVCSconst.HE_CA))
            {
                f1 = 0.0;
                f2 = 0.0;
                f3 = 0.0;
                cfl = 0.0;
            }
            else
            {
                double grav_h_L = SVCSconst.GRAV * h_L;
                double grav_h_R = SVCSconst.GRAV * h_R;
                double q_L = u_L * h_L;
                double q_R = u_R * h_R;
                double c1, c2;
                if (h_L < SVCSconst.HE_CA)
                {
                    c1 = u_R - 2 * Math.Sqrt(SVCSconst.GRAV * h_R);
                }
                else
                {
                    c1 = Math.Min(u_L - Math.Sqrt(grav_h_L), u_R - Math.Sqrt(grav_h_R));
                }
                if (h_R < SVCSconst.HE_CA)
                {
                    c2 = u_L + 2 * Math.Sqrt(SVCSconst.GRAV * h_L);
                }
                else
                {
                    c2 = Math.Max(u_L + Math.Sqrt(grav_h_L), u_R + Math.Sqrt(grav_h_R));
                }

                if (Math.Abs(c1) < SVCSconst.EPSILON && Math.Abs(c2) < SVCSconst.EPSILON)
                {              //dry state
                    f1 = 0.0;
                    f2 = 0.0;
                    f3 = 0.0;
                    cfl = 0.0;
                }
                else if (c1 >= SVCSconst.EPSILON)
                { //supercritical flow, from left to right : we have max(abs(c1),abs(c2))=c2>0
                    f1 = q_L;
                    f2 = q_L * u_L + SVCSconst.GRAV * h_L * h_L * 0.5;
                    f3 = q_L * v_L;
                    cfl = c2; //max(fabs(c1),fabs(c2))=c2>0
                }
                else if (c2 <= -SVCSconst.EPSILON)
                { //supercritical flow, from right to left : we have max(abs(c1),abs(c2))=-c1>0
                    f1 = q_R;
                    f2 = q_R * u_R + SVCSconst.GRAV * h_R * h_R * 0.5;
                    f3 = q_R * v_R;
                    cfl = Math.Abs(c1); //max(fabs(c1),fabs(c2))=fabs(c1)
                }
                else
                { //subcritical flow
                    double c_star = (c1 * h_R * (u_R - c2) - c2 * h_L * (u_L - c1)) / (h_R * (u_R - c2) - h_L * (u_L - c1));
                    double tmp = 1.0 / (c2 - c1);
                    f1 = (c2 * q_L - c1 * q_R) * tmp + c1 * c2 * (h_R - h_L) * tmp;// long double are used locally to avoid numerical approximations                    
                    f2 = (c2 * (q_L * u_L + SVCSconst.GRAV * h_L * h_L * 0.5) - c1 * (q_R * u_R + SVCSconst.GRAV * h_R * h_R * 0.5)) * tmp + c1 * c2 * (q_R - q_L) * tmp;
                    if (c_star > SVCSconst.EPSILON)
                    {
                        f3 = f1 * v_L;
                    }
                    else
                    {
                        f3 = f1 * v_R;
                    }
                    cfl = Math.Max(Math.Abs(c1), Math.Abs(c2));
                }
            }
        }
        public static void FluxHLLC2(double h_L, double h_R, double u_L, double u_R, double v_L, double v_R, out double f1, out double f2, out double f3, out double cfl)
        {
            if (h_L < SVCSconst.HE_CA && h_R < SVCSconst.HE_CA)
            {
                f1 = 0.0;
                f2 = 0.0;
                f3 = 0.0;
                cfl = 0.0;
            }
            else
            {
                double grav_h_L = SVCSconst.GRAV * h_L;
                double grav_h_R = SVCSconst.GRAV * h_R;
                double sqrt_grav_h_L = Math.Sqrt(grav_h_L);
                double sqrt_grav_h_R = Math.Sqrt(grav_h_R);
                double q_R = u_R * h_R;
                double q_L = u_L * h_L;
                double c1, c2;

                if (h_L < SVCSconst.HE_CA)
                {
                    c1 = u_R - 2 * Math.Sqrt(SVCSconst.GRAV * h_R);
                }
                else
                {
                    c1 = Math.Min(u_L - Math.Sqrt(grav_h_L), u_R - Math.Sqrt(grav_h_R)); // as u-sqrt(grav_h) <= u+sqrt(grav_h)    
                }
                if (h_R < SVCSconst.HE_CA)
                {
                    c2 = u_L + 2 * Math.Sqrt(SVCSconst.GRAV * h_L);
                }
                else
                {
                    c2 = Math.Max(u_L + Math.Sqrt(grav_h_L), u_R + Math.Sqrt(grav_h_R)); // as u+sqrt(grav_h) >= u-sqrt(grav_h)
                }
                double tmp = 1.0 / (c2 - c1);
                double t1 = (Math.Min(c2, 0.0) - Math.Min(c1, 0.0)) * tmp;
                double t2 = 1.0 - t1;
                double t3 = (c2 * Math.Abs(c1) - c1 * Math.Abs(c2)) * 0.5 * tmp;
                double c_star = (c1 * h_R * (u_R - c2) - c2 * h_L * (u_L - c1)) / (h_R * (u_R - c2) - h_L * (u_L - c1));

                f1 = t1 * q_R + t2 * q_L - t3 * (h_R - h_L);
                f2 = t1 * (q_R * u_R + grav_h_R * h_R * 0.5) + t2 * (q_L * u_L + grav_h_L * h_L * 0.5) - t3 * (q_R - q_L);
                if (c_star > SVCSconst.EPSILON)
                {
                    f3 = f1 * v_L;
                }
                else
                {
                    f3 = f1 * v_R;
                }
                cfl = Math.Max(Math.Abs(c1), Math.Abs(c2)); //cfl is the velocity to compute the cfl condition max(fabs(c1),fabs(c2))*tx with tx=dt/dx
            }
        }
        public static void FluxRusanov(double h_L, double h_R, double u_L, double u_R, double v_L, double v_R, out double f1, out double f2, out double f3, out double cfl)
        {
            double c;
            if (h_L < SVCSconst.HE_CA && h_R < SVCSconst.HE_CA)
            {
                c = 0.0;
                f1 = 0.0;
                f2 = 0.0;
                f3 = 0.0;
                cfl = 0.0;
            }
            else
            {
                c = Math.Max(Math.Abs(u_L) + Math.Sqrt(SVCSconst.GRAV * h_L), Math.Abs(u_R) + Math.Sqrt(SVCSconst.GRAV * h_R));
                double cd = c * 0.5;
                double q_R = u_R * h_R;
                double q_L = u_L * h_L;
                f1 = (q_L + q_R) * 0.5 - cd * (h_R - h_L);
                f2 = ((u_L * q_L) + (SVCSconst.GRAV / 2.0 * h_L * h_L) + (u_R * q_R) + (SVCSconst.GRAV / 2.0 * h_R * h_R)) * 0.5 - cd * (q_R - q_L);
                f3 = (q_L * v_L + q_R * v_R) * 0.5 - cd * (h_R * v_R - h_L * v_L);
                cfl = c;//*tx;
            }
        }
        public static void FluxHLL(double h_L, double h_R, double u_L, double u_R, double v_L, double v_R, out double f1, out double f2, out double f3, out double cfl)
        {
            if (h_L < SVCSconst.HE_CA && h_R < SVCSconst.HE_CA)
            {
                f1 = 0.0;
                f2 = 0.0;
                f3 = 0.0;
                cfl = 0.0;
            }
            else
            {
                double grav_h_L = SVCSconst.GRAV * h_L;
                double grav_h_R = SVCSconst.GRAV * h_R;
                double q_R = u_R * h_R;
                double q_L = u_L * h_L;
                double c1 = Math.Min(u_L - Math.Sqrt(grav_h_L), u_R - Math.Sqrt(grav_h_R));
                double c2 = Math.Max(u_L + Math.Sqrt(grav_h_L), u_R + Math.Sqrt(grav_h_R));

                if (Math.Abs(c1) < SVCSconst.EPSILON && Math.Abs(c2) < SVCSconst.EPSILON)
                {
                    f1 = 0.0;
                    f2 = 0.0;
                    f3 = 0.0;
                    cfl = 0.0;
                }
                else if (c1 >= SVCSconst.EPSILON)
                {
                    f1 = q_L;
                    f2 = q_L * u_L + SVCSconst.GRAV * h_L * h_L * 0.5;
                    f3 = q_L * v_L;
                    cfl = c2;
                }
                else if (c2 <= -SVCSconst.EPSILON)
                {
                    f1 = q_R;
                    f2 = q_R * u_R + SVCSconst.GRAV * h_R * h_R * 0.5;
                    f3 = q_R * v_R;
                    cfl = Math.Abs(c1);
                }
                else
                {
                    double tmp = 1.0 / (c2 - c1);
                    f1 = (c2 * q_L - c1 * q_R) * tmp + c1 * c2 * (h_R - h_L) * tmp;
                    f2 = (c2 * (q_L * u_L + SVCSconst.GRAV * h_L * h_L * 0.5) - c1 * (q_R * u_R + SVCSconst.GRAV * h_R * h_R * 0.5)) * tmp + c1 * c2 * (q_R - q_L) * tmp;
                    f3 = (c2 * (q_L * v_L) - c1 * (q_R * v_R)) * tmp + c1 * c2 * (h_R * v_R - h_L * v_L) * tmp;
                    cfl = Math.Max(Math.Abs(c1), Math.Abs(c2));
                }
            }
        }
        public static void FluxHLL2(double h_L, double h_R, double u_L, double u_R, double v_L, double v_R, out double f1, out double f2, out double f3, out double cfl)
        {
            if (h_L < SVCSconst.HE_CA && h_R < SVCSconst.HE_CA)
            {
                f1 = 0.0;
                f2 = 0.0;
                f3 = 0.0;
                cfl = 0.0;
            }
            else
            {
                double grav_h_L = SVCSconst.GRAV * h_L;
                double grav_h_R = SVCSconst.GRAV * h_R;
                double sqrt_grav_h_L = Math.Sqrt(grav_h_L);
                double sqrt_grav_h_R = Math.Sqrt(grav_h_R);
                double q_R = u_R * h_R;
                double q_L = u_L * h_L;
                double c1 = Math.Min(u_L - sqrt_grav_h_L, u_R - sqrt_grav_h_R);   // as u-sqrt(grav_h) <= u+sqrt(grav_h)
                double c2 = Math.Max(u_L + sqrt_grav_h_L, u_R + sqrt_grav_h_R);   // as u+sqrt(grav_h) >= u-sqrt(grav_h)
                double tmp = 1.0 / (c2 - c1);
                double t1 = (Math.Min(c2, 0.0) - Math.Min(c1, 0.0)) * tmp;
                double t2 = 1.0 - t1;
                double t3 = (c2 * Math.Abs(c1) - c1 * Math.Abs(c2)) * 0.5 * tmp;

                f1 = t1 * q_R + t2 * q_L - t3 * (h_R - h_L);
                f2 = t1 * (q_R * u_R + grav_h_R * h_R * 0.5) + t2 * (q_L * u_L + grav_h_L * h_L * 0.5) - t3 * (q_R - q_L);
                f3 = t1 * q_R * v_R + t2 * q_L * v_L - t3 * (h_R * v_R - h_L * v_L);
                cfl = Math.Max(Math.Abs(c1), Math.Abs(c2));
            }
        }
    }
}
